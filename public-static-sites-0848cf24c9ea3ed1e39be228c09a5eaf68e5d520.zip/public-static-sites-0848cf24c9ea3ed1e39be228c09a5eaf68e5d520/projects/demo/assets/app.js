const action = document.querySelector("#action");
const status = document.querySelector("#status");

action.addEventListener("click", () => {
  status.textContent = "JavaScript loaded successfully.";
});
