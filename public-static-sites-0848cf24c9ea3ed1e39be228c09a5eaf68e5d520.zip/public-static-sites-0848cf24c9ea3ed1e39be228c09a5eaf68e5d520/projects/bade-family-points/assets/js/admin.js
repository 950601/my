(() => {
  const navEl = document.getElementById("nav");
  const content = document.getElementById("content");
  const titleEl = document.getElementById("page-title");
  const descEl = document.getElementById("page-desc");
  const drawer = document.getElementById("drawer");
  const drawerMask = document.getElementById("drawer-mask");
  const drawerTitle = document.getElementById("drawer-title");
  const drawerBody = document.getElementById("drawer-body");
  const drawerFoot = document.getElementById("drawer-foot");
  const toastEl = document.getElementById("toast");

  const state = {
    page: "reports",
    adminRole: "super",
    reportFilter: "pending",
    reportKeyword: "",
    ownerKeyword: "",
    orderFilter: "全部",
    rbFilter: "全部",
  };

  const ALL_MENUS = [
    { group: "一期核心" },
    { id: "reports", ico: "审", label: "行为审核", desc: "八德行为申报审核与代录入" },
    { id: "points", ico: "分", label: "积分管理", desc: "流水查询、规则配置与手动调整" },
    { id: "mall", ico: "商", label: "商城管理", desc: "商品上下架、库存与价格模式" },
    { id: "orders", ico: "核", label: "订单核销", desc: "订单筛选、核销与导出（交易流）" },
    { group: "档案与运营" },
    { id: "owners", ico: "档", label: "业主档案", desc: "一户一档、标签与批量导入" },
    { id: "reimburse", ico: "报", label: "报销审核", desc: "活动经费两级审核与结算台账" },
    { group: "系统权限" },
    { id: "roles", ico: "权", label: "权限管理", desc: "后台角色、账号权限与菜单隔离" },
  ];

  function currentRole() {
    return ADMIN_ROLES[state.adminRole] || ADMIN_ROLES.super;
  }

  function visibleMenus() {
    const allow = new Set(currentRole().menus);
    const out = [];
    let pendingGroup = null;
    ALL_MENUS.forEach((m) => {
      if (m.group) {
        pendingGroup = m;
        return;
      }
      if (!allow.has(m.id)) return;
      if (pendingGroup) {
        out.push(pendingGroup);
        pendingGroup = null;
      }
      out.push(m);
    });
    return out;
  }

  function syncRoleChrome() {
    const role = currentRole();
    const pill = document.getElementById("current-role-pill");
    const user = document.getElementById("current-role-user");
    if (pill) pill.textContent = role.label;
    if (user) user.textContent = role.user;
    document.querySelectorAll("#admin-role-switch [data-admin-role]").forEach((btn) => {
      btn.classList.toggle("active", btn.getAttribute("data-admin-role") === state.adminRole);
    });
  }

  function toast(msg) {
    toastEl.hidden = false;
    toastEl.textContent = msg;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
      toastEl.hidden = true;
    }, 1800);
  }

  function tag(status) {
    const s = ADMIN_STATUS[status] || { text: status, cls: "muted" };
    return `<span class="tag ${s.cls}">${s.text}</span>`;
  }

  function openDrawer(title, bodyHtml, footHtml = "") {
    drawerTitle.textContent = title;
    drawerBody.innerHTML = bodyHtml;
    drawerFoot.innerHTML = footHtml;
    drawer.hidden = false;
    drawerMask.hidden = false;
  }

  function closeDrawer() {
    drawer.hidden = true;
    drawerMask.hidden = true;
  }

  function renderNav() {
    const menus = visibleMenus();
    navEl.innerHTML = menus
      .map((m) => {
        if (m.group) return `<div class="nav-group">${m.group}</div>`;
        return `<button type="button" data-page="${m.id}" class="${state.page === m.id ? "active" : ""}"><span class="ico">${m.ico}</span>${m.label}</button>`;
      })
      .join("");
  }

  function setPage(id) {
    const allow = new Set(currentRole().menus);
    if (!allow.has(id)) {
      id = currentRole().menus[0] || "reports";
      toast("当前角色无此菜单权限");
    }
    state.page = id;
    const meta = ALL_MENUS.find((m) => m.id === id);
    titleEl.textContent = meta?.label || "";
    descEl.textContent = meta?.desc || "";
    syncRoleChrome();
    renderNav();
    renderPage();
    closeDrawer();
  }

  function applyAdminRole(roleId, { silent } = {}) {
    if (!ADMIN_ROLES[roleId]) return;
    state.adminRole = roleId;
    syncRoleChrome();
    if (!silent) toast(`已切换为${ADMIN_ROLES[roleId].label}`);
    const allow = new Set(ADMIN_ROLES[roleId].menus);
    setPage(allow.has(state.page) ? state.page : ADMIN_ROLES[roleId].menus[0]);
  }

  /* ---------------- pages ---------------- */

  function pageReports() {
    const filters = [
      ["pending", "待审核"],
      ["passed", "已通过"],
      ["rejected", "已驳回"],
      ["all", "全部"],
    ];
    const list = ADMIN_DATA.reports.filter((r) => {
      const okStatus = state.reportFilter === "all" || r.status === state.reportFilter;
      const kw = state.reportKeyword.trim();
      const okKw = !kw || [r.id, r.owner, r.room, r.virtue, r.desc].join(" ").includes(kw);
      return okStatus && okKw;
    });

    return `
      <div class="toolbar">
        <input class="search" id="report-kw" placeholder="搜索业主 / 房号 / 单号" value="${state.reportKeyword}" />
        <select class="select" id="report-filter">
          ${filters.map(([v, t]) => `<option value="${v}" ${state.reportFilter === v ? "selected" : ""}>${t}</option>`).join("")}
        </select>
        <button class="btn ghost" type="button" id="proxy-entry">代录入线下事迹</button>
      </div>
      <section class="panel">
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>单号</th><th>申报人</th><th>角色</th><th>八德</th><th>公益项目</th><th>申报积分</th><th>描述</th><th>提交时间</th><th>状态</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              ${
                list.length
                  ? list
                      .map(
                        (r) => `
                <tr>
                  <td>${r.id}</td>
                  <td>${r.owner}<div style="font-size:11px;color:var(--muted)">${r.room}</div></td>
                  <td>${r.role === "volunteer" ? '<span class="tag gold">义工</span>' : '<span class="tag teal">业主</span>'}</td>
                  <td><span class="tag teal">${r.virtue}</span></td>
                  <td>${r.projectName || "—"}</td>
                  <td style="font-weight:700;color:${r.role === "volunteer" ? "var(--gold)" : "inherit"}">${r.claimedScore ?? r.score}</td>
                  <td class="wrap">${r.desc}</td>
                  <td>${r.time}</td>
                  <td>${tag(r.status)}</td>
                  <td>
                    <div class="ops">
                      <button class="btn ghost sm" data-view-report="${r.id}">查看</button>
                      ${
                        r.status === "pending"
                          ? `<button class="btn ok sm" data-pass-report="${r.id}">通过</button>
                             <button class="btn danger sm" data-reject-report="${r.id}">驳回</button>`
                          : ""
                      }
                    </div>
                  </td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="10"><div class="empty">暂无申报</div></td></tr>`
              }
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function pagePoints() {
    return `
      <div class="grid-2">
        <section class="panel">
          <div class="panel-head">
            <h3>积分流水</h3>
            <button class="btn ghost sm" type="button" id="adjust-points">手动调整</button>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>业主</th><th>房号</th><th>来源</th><th>变动</th><th>时间</th><th>关联单</th></tr></thead>
              <tbody>
                ${ADMIN_DATA.flows
                  .map(
                    (f) => `
                  <tr>
                    <td>${f.owner}</td>
                    <td>${f.room}</td>
                    <td>${f.source}</td>
                    <td style="font-weight:700;color:${f.amount > 0 ? "var(--ok)" : "var(--ink)"}">${f.amount > 0 ? "+" : ""}${f.amount}</td>
                    <td>${f.time}</td>
                    <td>${f.ref}</td>
                  </tr>`
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>
        <section class="panel">
          <div class="panel-head"><h3>积分规则配置</h3><span style="font-size:12px;color:var(--muted)">每类行为对应分值</span></div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>八德分类</th><th>分值</th><th>操作</th></tr></thead>
              <tbody>
                ${ADMIN_DATA.pointRules
                  .map(
                    (r, i) => `
                  <tr>
                    <td>${r.virtue}</td>
                    <td><input class="input" style="width:80px;padding:6px 8px" data-rule-score="${i}" value="${r.score}" /></td>
                    <td><button class="btn ghost sm" data-save-rule="${i}">保存</button></td>
                  </tr>`
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    `;
  }

  function pageMall() {
    return `
      <div class="toolbar">
        <button class="btn primary" type="button" id="add-product">新建商品</button>
        <span style="font-size:12px;color:var(--muted)">支持纯积分 / 积分+现金 / 纯现金；物业费抵扣券需关联物业台账</span>
      </div>
      <section class="panel">
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>商品</th><th>分类</th><th>价格模式</th><th>积分</th><th>现金</th><th>库存</th><th>状态</th><th>操作</th></tr>
            </thead>
            <tbody>
              ${ADMIN_DATA.products
                .map(
                  (p) => `
                <tr>
                  <td>${p.name}</td>
                  <td>${p.cate}</td>
                  <td>${ADMIN_MODE[p.mode]}</td>
                  <td>${p.points || "-"}</td>
                  <td>${p.cash ? "¥" + p.cash : "-"}</td>
                  <td>${p.stock}</td>
                  <td>${tag(p.status)}</td>
                  <td>
                    <div class="ops">
                      <button class="btn ghost sm" data-toggle-product="${p.id}">${p.status === "on" ? "下架" : "上架"}</button>
                      <button class="btn ghost sm" data-edit-product="${p.id}">编辑</button>
                    </div>
                  </td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function pageOrders() {
    const filters = ["全部", "待发货", "待核销", "已完成"];
    const map = { 待发货: "pending_ship", 待核销: "pending_verify", 已完成: "done" };
    const list = ADMIN_DATA.orders.filter((o) => state.orderFilter === "全部" || o.status === map[state.orderFilter]);
    return `
      <div class="toolbar">
        <select class="select" id="order-filter">
          ${filters.map((f) => `<option ${state.orderFilter === f ? "selected" : ""}>${f}</option>`).join("")}
        </select>
        <button class="btn ghost" type="button" id="export-orders">导出订单</button>
      </div>
      <section class="panel">
        <div class="table-wrap">
          <table>
            <thead><tr><th>订单号</th><th>业主</th><th>商品</th><th>支付</th><th>服务商</th><th>状态</th><th>下单时间</th><th>操作</th></tr></thead>
            <tbody>
              ${list
                .map(
                  (o) => `
                <tr>
                  <td>${o.id}</td>
                  <td>${o.owner}<div style="font-size:11px;color:var(--muted)">${o.room}</div></td>
                  <td>${o.product}</td>
                  <td>${o.points ? o.points + "分" : ""}${o.points && o.cash ? " + " : ""}${o.cash ? "¥" + o.cash : ""}</td>
                  <td>${o.vendor}</td>
                  <td>${tag(o.status)}</td>
                  <td>${o.time}</td>
                  <td>
                    ${
                      o.status === "pending_verify"
                        ? `<button class="btn ok sm" data-verify-order="${o.id}">扫码核销</button>`
                        : o.status === "pending_ship"
                          ? `<button class="btn ghost sm" data-ship-order="${o.id}">标记发货</button>`
                          : `<button class="btn ghost sm" disabled>已完成</button>`
                    }
                  </td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function pageOwners() {
    const kw = state.ownerKeyword.trim();
    const list = ADMIN_DATA.owners.filter(
      (o) => !kw || [o.name, o.room, o.phone, ...(o.tags || [])].join(" ").includes(kw)
    );
    return `
      <div class="toolbar">
        <input class="search" id="owner-kw" placeholder="搜索姓名 / 房号 / 标签" value="${state.ownerKeyword}" />
        <button class="btn ghost" type="button" id="import-owners">Excel 批量导入</button>
        <span style="font-size:12px;color:var(--muted)">普通账号禁止批量导出手机号</span>
      </div>
      <section class="panel">
        <div class="table-wrap">
          <table>
            <thead><tr><th>业主</th><th>房号</th><th>手机</th><th>成员</th><th>积分</th><th>标签</th><th>申报/订单</th><th>操作</th></tr></thead>
            <tbody>
              ${list
                .map(
                  (o) => `
                <tr>
                  <td>${o.name}</td>
                  <td>${o.room}</td>
                  <td>${o.phone}</td>
                  <td>${o.members}</td>
                  <td style="font-weight:700">${o.points}</td>
                  <td>${o.tags.length ? o.tags.map((t) => `<span class="tag gold" style="margin-right:4px">${t}</span>`).join("") : '<span class="tag muted">无</span>'}</td>
                  <td>${o.reports} / ${o.orders}</td>
                  <td><button class="btn ghost sm" data-view-owner="${o.id}">一户一档</button></td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function pageReimburse() {
    const filters = ["全部", "一级审核中", "二级终审中", "已结算"];
    const map = { 一级审核中: "l1", 二级终审中: "l2", 已结算: "settled" };
    const list = ADMIN_DATA.reimbursements.filter(
      (r) => state.rbFilter === "全部" || r.status === map[state.rbFilter]
    );
    return `
      <div class="toolbar">
        <select class="select" id="rb-filter">
          ${filters.map((f) => `<option ${state.rbFilter === f ? "selected" : ""}>${f}</option>`).join("")}
        </select>
        <button class="btn primary" type="button" id="new-rb">提交报销单</button>
        <button class="btn ghost" type="button" id="export-rb">导出台账</button>
      </div>
      <section class="panel">
        <div class="table-wrap">
          <table>
            <thead><tr><th>单号</th><th>申请人</th><th>活动</th><th>金额</th><th>状态</th><th>提交时间</th><th>操作</th></tr></thead>
            <tbody>
              ${list
                .map(
                  (r) => `
                <tr>
                  <td>${r.id}</td>
                  <td>${r.applicant}</td>
                  <td>${r.activity}</td>
                  <td style="font-weight:700">¥${r.amount.toFixed(2)}</td>
                  <td>${tag(r.status)}</td>
                  <td>${r.time}</td>
                  <td>
                    <div class="ops">
                      <button class="btn ghost sm" data-view-rb="${r.id}">查看</button>
                      ${r.status === "l1" ? `<button class="btn ok sm" data-rb-l1="${r.id}">一级通过</button>` : ""}
                      ${r.status === "l2" ? `<button class="btn ok sm" data-rb-l2="${r.id}">终审通过</button>` : ""}
                      ${r.status === "l2" ? `<button class="btn primary sm" data-rb-settle="${r.id}">标记结算</button>` : ""}
                    </div>
                  </td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function pageRoles() {
    const rows = [
      ["行为审核", "✓", "✓", "✓"],
      ["积分管理", "✓", "—", "✓"],
      ["商城管理", "✓", "✓", "—"],
      ["订单核销", "✓", "✓", "—"],
      ["业主档案", "✓", "查看", "查看"],
      ["报销审核", "✓", "提交/审核", "提交/审核"],
      ["权限管理", "✓", "—", "—"],
      ["数据导出", "✓", "部分", "部分"],
    ];
    return `
      <div class="kpi-grid" style="grid-template-columns:repeat(3,1fr)">
        ${Object.values(ADMIN_ROLES)
          .map(
            (r) => `
          <div class="kpi">
            <div class="label">${r.label}</div>
            <div class="value" style="font-size:18px;margin-top:10px">${r.short}</div>
            <div class="hint" style="color:var(--muted)">${r.menus.length} 个菜单权限</div>
          </div>`
          )
          .join("")}
      </div>
      <section class="panel" style="margin-bottom:14px">
        <div class="panel-head">
          <h3>角色权限矩阵</h3>
          <span style="font-size:12px;color:var(--muted)">一期仅 3 种后台角色</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>功能模块</th><th>超级管理员</th><th>物业管理</th><th>公益协会管理</th></tr>
            </thead>
            <tbody>
              ${rows.map((r) => `<tr>${r.map((c, i) => `<td ${i === 0 ? 'style="font-weight:600"' : ""}>${c}</td>`).join("")}</tr>`).join("")}
            </tbody>
          </table>
        </div>
        <div class="panel-body">
          <p style="font-size:13px;color:var(--muted);line-height:1.6">
            超级管理员拥有全部菜单与导出权限；物业管理侧重商城、订单核销与物业相关运营；公益协会管理侧重行为审核、积分与公益活动报销。普通角色禁止批量导出业主手机号。
          </p>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head">
          <h3>后台账号</h3>
          <button class="btn ghost sm" type="button" id="add-admin-account">新建账号</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>账号</th><th>姓名/标识</th><th>角色</th><th>所属组织</th><th>手机</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              ${ADMIN_ACCOUNTS.map((a) => {
                const role = ADMIN_ROLES[a.role];
                return `
                <tr>
                  <td>${a.id}</td>
                  <td>${a.name}</td>
                  <td><span class="tag ${a.role === "super" ? "gold" : "teal"}">${role?.label || a.role}</span></td>
                  <td>${a.org}</td>
                  <td>${a.phone}</td>
                  <td>${tag(a.status)}</td>
                  <td>
                    <div class="ops">
                      <button class="btn ghost sm" data-edit-account="${a.id}">编辑</button>
                      <button class="btn ghost sm" data-toggle-account="${a.id}">${a.status === "on" ? "停用" : "启用"}</button>
                    </div>
                  </td>
                </tr>`;
              }).join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  const pages = {
    reports: pageReports,
    points: pagePoints,
    mall: pageMall,
    orders: pageOrders,
    owners: pageOwners,
    reimburse: pageReimburse,
    roles: pageRoles,
  };

  function renderPage() {
    content.innerHTML = (pages[state.page] || pageReports)();
    bindPageEvents();
  }

  /* ---------------- drawers / actions ---------------- */

  function viewReport(id) {
    const r = ADMIN_DATA.reports.find((x) => x.id === id);
    if (!r) return;
    const isVol = r.role === "volunteer";
    const claim = r.claimedScore ?? r.score;
    openDrawer(
      "申报详情",
      `
      <div class="kv">
        <div class="k">单号</div><div class="v">${r.id}</div>
        <div class="k">申报人</div><div class="v">${r.owner} · ${r.room}</div>
        <div class="k">角色</div><div class="v">${isVol ? '<span class="tag gold">义工</span>' : '<span class="tag teal">业主</span>'}</div>
        <div class="k">八德</div><div class="v">${r.virtue}</div>
        ${isVol ? `<div class="k">公益项目</div><div class="v">${r.projectName || "—"}</div>` : ""}
        ${
          isVol
            ? `<div class="k">申报积分</div><div class="v" style="font-weight:700;color:var(--gold)">${claim} 分<span style="color:var(--muted);font-weight:400;margin-left:6px">（义工自填）</span></div>`
            : `<div class="k">规则积分</div><div class="v">${r.score} 分</div>`
        }
        <div class="k">状态</div><div class="v">${tag(r.status)}</div>
        <div class="k">时间</div><div class="v">${r.time}</div>
        <div class="k">描述</div><div class="v">${r.desc}</div>
        ${r.reason ? `<div class="k">驳回原因</div><div class="v" style="color:var(--danger)">${r.reason}</div>` : ""}
        ${r.reviewer ? `<div class="k">审核人</div><div class="v">${r.reviewer}</div>` : ""}
      </div>
      ${
        r.status === "pending"
          ? `<div class="field" style="margin-bottom:14px">
              <label>发放积分${isVol ? "（可按申报积分调整）" : ""}</label>
              <input class="input" id="grant-score" type="number" min="0" step="1" value="${claim}" />
            </div>`
          : ""
      }
      <div style="font-size:12px;color:var(--muted);margin-bottom:8px">现场照片</div>
      <div class="photo-row">${(r.photos || []).map((p) => `<div class="photo">${p}</div>`).join("")}</div>
      `,
      r.status === "pending"
        ? `<button class="btn danger" data-reject-report="${r.id}">驳回</button><button class="btn ok" data-pass-report="${r.id}">审核通过并发放积分</button>`
        : `<button class="btn ghost" id="drawer-close-2">关闭</button>`
    );
  }

  function viewOwner(id) {
    const o = ADMIN_DATA.owners.find((x) => x.id === id);
    if (!o) return;
    openDrawer(
      "一户一档",
      `
      <div class="kv">
        <div class="k">姓名</div><div class="v">${o.name}</div>
        <div class="k">房号</div><div class="v">${o.room}</div>
        <div class="k">手机</div><div class="v">${o.phone}</div>
        <div class="k">家庭成员</div><div class="v">${o.members} 人</div>
        <div class="k">积分余额</div><div class="v" style="font-family:var(--serif);font-size:22px">${o.points}</div>
        <div class="k">标签</div><div class="v">${o.tags.length ? o.tags.map((t) => `<span class="tag gold" style="margin:0 4px 4px 0">${t}</span>`).join("") : "暂无"}</div>
        <div class="k">申报/订单</div><div class="v">${o.reports} 次申报 · ${o.orders} 笔订单</div>
      </div>
      <div class="field" style="margin-top:8px">
        <label>打标签</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${["独居老人", "康养需求", "家政需求", "孝亲先锋"]
            .map((t) => `<button class="btn ghost sm" data-tag-owner="${o.id}" data-tag="${t}">${t}</button>`)
            .join("")}
        </div>
      </div>
      `,
      `<button class="btn ghost" id="drawer-close-2">关闭</button>`
    );
  }

  function viewRb(id) {
    const r = ADMIN_DATA.reimbursements.find((x) => x.id === id);
    if (!r) return;
    openDrawer(
      "报销单详情",
      `
      <div class="kv">
        <div class="k">单号</div><div class="v">${r.id}</div>
        <div class="k">申请人</div><div class="v">${r.applicant}</div>
        <div class="k">活动</div><div class="v">${r.activity}</div>
        <div class="k">金额</div><div class="v">¥${r.amount.toFixed(2)}</div>
        <div class="k">明细</div><div class="v">${r.detail}</div>
        <div class="k">状态</div><div class="v">${tag(r.status)}</div>
        ${r.l1 ? `<div class="k">一级意见</div><div class="v">${r.l1}</div>` : ""}
        ${r.l2 ? `<div class="k">终审意见</div><div class="v">${r.l2}</div>` : ""}
      </div>
      <div class="photo-row">${(r.invoice || []).map((p) => `<div class="photo">${p}</div>`).join("")}</div>
      `,
      `<button class="btn ghost" id="drawer-close-2">关闭</button>`
    );
  }

  function passReport(id) {
    const r = ADMIN_DATA.reports.find((x) => x.id === id);
    if (!r || r.status !== "pending") return;
    const grantInput = document.getElementById("grant-score");
    const grant = grantInput ? Number(grantInput.value) : Number(r.claimedScore ?? r.score);
    if (Number.isNaN(grant) || grant < 0) {
      toast("请填写有效发放积分");
      return;
    }
    r.status = "passed";
    r.score = grant;
    r.reviewer = currentRole().label;
    ADMIN_DATA.flows.unshift({
      id: "F" + Date.now(),
      owner: r.owner,
      room: r.room,
      type: "gain",
      source: "审核奖励",
      amount: grant,
      time: "刚刚",
      ref: r.id,
    });
    ADMIN_DATA.kpis.pointsIssued += grant;
    toast(`已通过，发放 ${grant} 积分`);
    closeDrawer();
    renderPage();
  }

  function rejectReport(id) {
    const r = ADMIN_DATA.reports.find((x) => x.id === id);
    if (!r || r.status !== "pending") return;
    openDrawer(
      "驳回申报",
      `
      <p style="font-size:13px;margin-bottom:10px;color:var(--muted)">单号 ${r.id} · ${r.owner}</p>
      <div class="field">
        <label>驳回原因</label>
        <textarea class="textarea" id="reject-reason" placeholder="请填写驳回原因，将通知业主补充材料">材料不足，请补充现场照片</textarea>
      </div>
      `,
      `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn danger" id="confirm-reject" data-id="${r.id}">确认驳回</button>`
    );
  }

  function bindPageEvents() {
    const reportKw = document.getElementById("report-kw");
    reportKw?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        state.reportKeyword = reportKw.value;
        renderPage();
      }
    });
    reportKw?.addEventListener("change", () => {
      state.reportKeyword = reportKw.value;
      renderPage();
    });

    document.getElementById("report-filter")?.addEventListener("change", (e) => {
      state.reportFilter = e.target.value;
      renderPage();
    });

    document.getElementById("owner-kw")?.addEventListener("change", (e) => {
      state.ownerKeyword = e.target.value;
      renderPage();
    });
    document.getElementById("owner-kw")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        state.ownerKeyword = e.target.value;
        renderPage();
      }
    });

    document.getElementById("order-filter")?.addEventListener("change", (e) => {
      state.orderFilter = e.target.value;
      renderPage();
    });
    document.getElementById("rb-filter")?.addEventListener("change", (e) => {
      state.rbFilter = e.target.value;
      renderPage();
    });

    content.querySelectorAll("[data-view-report]").forEach((el) =>
      el.addEventListener("click", () => viewReport(el.getAttribute("data-view-report")))
    );
    content.querySelectorAll("[data-pass-report]").forEach((el) =>
      el.addEventListener("click", () => passReport(el.getAttribute("data-pass-report")))
    );
    content.querySelectorAll("[data-reject-report]").forEach((el) =>
      el.addEventListener("click", () => rejectReport(el.getAttribute("data-reject-report")))
    );
    content.querySelectorAll("[data-view-owner]").forEach((el) =>
      el.addEventListener("click", () => viewOwner(el.getAttribute("data-view-owner")))
    );
    content.querySelectorAll("[data-view-rb]").forEach((el) =>
      el.addEventListener("click", () => viewRb(el.getAttribute("data-view-rb")))
    );

    content.querySelectorAll("[data-toggle-product]").forEach((el) =>
      el.addEventListener("click", () => {
        const p = ADMIN_DATA.products.find((x) => x.id === el.getAttribute("data-toggle-product"));
        if (!p) return;
        p.status = p.status === "on" ? "off" : "on";
        toast(p.status === "on" ? "已上架" : "已下架");
        renderPage();
      })
    );

    content.querySelectorAll("[data-verify-order]").forEach((el) =>
      el.addEventListener("click", () => {
        const o = ADMIN_DATA.orders.find((x) => x.id === el.getAttribute("data-verify-order"));
        if (!o) return;
        o.status = "done";
        toast("核销成功，订单完成");
        renderPage();
      })
    );

    content.querySelectorAll("[data-ship-order]").forEach((el) =>
      el.addEventListener("click", () => {
        const o = ADMIN_DATA.orders.find((x) => x.id === el.getAttribute("data-ship-order"));
        if (!o) return;
        o.status = "pending_verify";
        toast("已标记发货，待核销");
        renderPage();
      })
    );

    content.querySelectorAll("[data-rb-l1]").forEach((el) =>
      el.addEventListener("click", () => {
        const r = ADMIN_DATA.reimbursements.find((x) => x.id === el.getAttribute("data-rb-l1"));
        if (!r) return;
        r.status = "l2";
        r.l1 = "一级审核通过";
        toast("一级审核通过，进入终审");
        renderPage();
      })
    );

    content.querySelectorAll("[data-rb-l2]").forEach((el) =>
      el.addEventListener("click", () => {
        const r = ADMIN_DATA.reimbursements.find((x) => x.id === el.getAttribute("data-rb-l2"));
        if (!r) return;
        r.l2 = "终审通过";
        toast("终审通过，可标记结算");
        renderPage();
      })
    );

    content.querySelectorAll("[data-rb-settle]").forEach((el) =>
      el.addEventListener("click", () => {
        const r = ADMIN_DATA.reimbursements.find((x) => x.id === el.getAttribute("data-rb-settle"));
        if (!r) return;
        r.status = "settled";
        r.l2 = r.l2 || "终审通过";
        toast("已标记结算");
        renderPage();
      })
    );

    content.querySelectorAll("[data-save-rule]").forEach((el) =>
      el.addEventListener("click", () => {
        const i = Number(el.getAttribute("data-save-rule"));
        const input = content.querySelector(`[data-rule-score="${i}"]`);
        const val = Number(input?.value || 0);
        ADMIN_DATA.pointRules[i].score = val;
        toast(`已保存：${ADMIN_DATA.pointRules[i].virtue} = ${val} 分`);
      })
    );

    document.getElementById("proxy-entry")?.addEventListener("click", () => {
      openDrawer(
        "代录入线下事迹",
        `
        <div class="form-grid">
          <div class="field"><label>业主姓名</label><input class="input" id="pe-name" placeholder="张三" /></div>
          <div class="field"><label>房号</label><input class="input" id="pe-room" placeholder="3栋1202" /></div>
          <div class="field"><label>八德分类</label>
            <select class="select" id="pe-virtue">${ADMIN_DATA.pointRules.map((r) => `<option>${r.virtue}</option>`).join("")}</select>
          </div>
          <div class="field"><label>建议积分</label><input class="input" id="pe-score" type="number" value="15" /></div>
          <div class="field full"><label>事迹描述</label><textarea class="textarea" id="pe-desc" placeholder="线下纸质申报内容"></textarea></div>
        </div>
        `,
        `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn primary" id="confirm-proxy">提交待审</button>`
      );
    });

    document.getElementById("adjust-points")?.addEventListener("click", () => {
      openDrawer(
        "手动调整积分",
        `
        <div class="form-grid">
          <div class="field"><label>业主</label><select class="select" id="adj-owner">${ADMIN_DATA.owners.map((o) => `<option value="${o.id}">${o.name} · ${o.room}</option>`).join("")}</select></div>
          <div class="field"><label>变动分值（可负）</label><input class="input" id="adj-amount" type="number" value="-10" /></div>
          <div class="field full"><label>原因（必填留痕）</label><textarea class="textarea" id="adj-reason">重复申报冲销</textarea></div>
        </div>
        `,
        `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn primary" id="confirm-adj">确认调整</button>`
      );
    });

    document.getElementById("add-product")?.addEventListener("click", () => toast("演示：打开新建商品表单"));
    document.getElementById("import-owners")?.addEventListener("click", () => toast("演示：已选择业主房号 Excel"));
    document.getElementById("export-orders")?.addEventListener("click", () => toast("订单已导出（演示）"));
    document.getElementById("export-rb")?.addEventListener("click", () => toast("报销台账已导出（演示）"));
    document.getElementById("new-rb")?.addEventListener("click", () => {
      openDrawer(
        "提交报销单",
        `
        <div class="form-grid">
          <div class="field"><label>活动名称</label><input class="input" id="rb-act" placeholder="家风主题活动" /></div>
          <div class="field"><label>金额</label><input class="input" id="rb-amt" type="number" value="500" /></div>
          <div class="field full"><label>费用明细</label><textarea class="textarea" id="rb-detail">物料采购</textarea></div>
        </div>
        `,
        `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn primary" id="confirm-rb">提交一级审核</button>`
      );
    });

    document.getElementById("add-admin-account")?.addEventListener("click", () => {
      openDrawer(
        "新建后台账号",
        `
        <div class="form-grid">
          <div class="field"><label>账号</label><input class="input" id="acc-name" placeholder="zhangsan" /></div>
          <div class="field"><label>手机</label><input class="input" id="acc-phone" placeholder="13800000000" /></div>
          <div class="field"><label>角色</label>
            <select class="select" id="acc-role">
              ${Object.values(ADMIN_ROLES).map((r) => `<option value="${r.id}">${r.label}</option>`).join("")}
            </select>
          </div>
          <div class="field"><label>所属组织</label><input class="input" id="acc-org" placeholder="物业中心" /></div>
        </div>
        `,
        `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn primary" id="confirm-acc">创建</button>`
      );
    });

    content.querySelectorAll("[data-toggle-account]").forEach((el) =>
      el.addEventListener("click", () => {
        const a = ADMIN_ACCOUNTS.find((x) => x.id === el.getAttribute("data-toggle-account"));
        if (!a) return;
        a.status = a.status === "on" ? "off" : "on";
        toast(a.status === "on" ? "已启用" : "已停用");
        renderPage();
      })
    );

    content.querySelectorAll("[data-edit-account]").forEach((el) =>
      el.addEventListener("click", () => {
        const a = ADMIN_ACCOUNTS.find((x) => x.id === el.getAttribute("data-edit-account"));
        if (!a) return;
        openDrawer(
          "编辑账号角色",
          `
          <div class="form-grid">
            <div class="field"><label>账号</label><input class="input" value="${a.name}" disabled /></div>
            <div class="field"><label>角色</label>
              <select class="select" id="edit-acc-role">
                ${Object.values(ADMIN_ROLES)
                  .map((r) => `<option value="${r.id}" ${a.role === r.id ? "selected" : ""}>${r.label}</option>`)
                  .join("")}
              </select>
            </div>
          </div>
          `,
          `<button class="btn ghost" id="drawer-close-2">取消</button><button class="btn primary" id="confirm-edit-acc" data-id="${a.id}">保存</button>`
        );
      })
    );
  }

  /* global clicks via delegation for drawer buttons that re-render */
  document.getElementById("admin-role-switch")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-admin-role]");
    if (!btn) return;
    const role = btn.getAttribute("data-admin-role");
    if (role === state.adminRole) return;
    applyAdminRole(role);
  });

  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-page]");
    if (t) {
      setPage(t.getAttribute("data-page"));
      return;
    }

    if (e.target.id === "drawer-close" || e.target.id === "drawer-close-2" || e.target === drawerMask) {
      closeDrawer();
      return;
    }

    const pass = e.target.closest("[data-pass-report]");
    if (pass && pass.closest(".drawer")) {
      passReport(pass.getAttribute("data-pass-report"));
      return;
    }
    const rej = e.target.closest("[data-reject-report]");
    if (rej && rej.closest(".drawer")) {
      rejectReport(rej.getAttribute("data-reject-report"));
      return;
    }

    if (e.target.id === "confirm-reject") {
      const id = e.target.getAttribute("data-id");
      const r = ADMIN_DATA.reports.find((x) => x.id === id);
      if (r) {
        r.status = "rejected";
        r.reason = document.getElementById("reject-reason")?.value || "材料不足";
        r.reviewer = currentRole().label;
        toast("已驳回，已通知业主");
        closeDrawer();
        renderPage();
      }
      return;
    }

    if (e.target.id === "confirm-proxy") {
      const virtue = document.getElementById("pe-virtue")?.value || "孝亲";
      const score = Number(document.getElementById("pe-score")?.value || 10);
      ADMIN_DATA.reports.unshift({
        id: "R" + Date.now().toString().slice(-11),
        owner: document.getElementById("pe-name")?.value || "未命名",
        room: document.getElementById("pe-room")?.value || "-",
        virtue,
        desc: document.getElementById("pe-desc")?.value || "线下代录入",
        time: new Date().toISOString().slice(0, 16).replace("T", " "),
        status: "pending",
        score,
        photos: ["纸质照片"],
      });
      toast("代录入成功，进入待审");
      closeDrawer();
      state.reportFilter = "pending";
      setPage("reports");
      return;
    }

    if (e.target.id === "confirm-adj") {
      const owner = ADMIN_DATA.owners.find((o) => o.id === document.getElementById("adj-owner")?.value);
      const amount = Number(document.getElementById("adj-amount")?.value || 0);
      const reason = document.getElementById("adj-reason")?.value || "";
      if (!owner || !reason) {
        toast("请填写原因");
        return;
      }
      owner.points += amount;
      ADMIN_DATA.flows.unshift({
        id: "F" + Date.now(),
        owner: owner.name,
        room: owner.room,
        type: "adjust",
        source: "手动调整",
        amount,
        time: "刚刚",
        ref: "ADJ-" + Date.now().toString().slice(-4),
        reason,
      });
      toast("积分已调整并留痕");
      closeDrawer();
      renderPage();
      return;
    }

    if (e.target.id === "confirm-rb") {
      ADMIN_DATA.reimbursements.unshift({
        id: "RB" + Date.now().toString().slice(-8),
        applicant: currentRole().label,
        activity: document.getElementById("rb-act")?.value || "未命名活动",
        amount: Number(document.getElementById("rb-amt")?.value || 0),
        status: "l1",
        invoice: ["发票1"],
        detail: document.getElementById("rb-detail")?.value || "",
        time: new Date().toISOString().slice(0, 16).replace("T", " "),
      });
      toast("报销单已提交一级审核");
      closeDrawer();
      renderPage();
      return;
    }

    if (e.target.id === "confirm-acc") {
      const name = document.getElementById("acc-name")?.value.trim();
      const role = document.getElementById("acc-role")?.value || "property";
      if (!name) {
        toast("请填写账号");
        return;
      }
      ADMIN_ACCOUNTS.unshift({
        id: "A" + Date.now().toString().slice(-4),
        name,
        role,
        org: document.getElementById("acc-org")?.value.trim() || ADMIN_ROLES[role]?.label,
        status: "on",
        phone: document.getElementById("acc-phone")?.value.trim() || "—",
      });
      toast("账号已创建");
      closeDrawer();
      renderPage();
      return;
    }

    if (e.target.id === "confirm-edit-acc") {
      const a = ADMIN_ACCOUNTS.find((x) => x.id === e.target.getAttribute("data-id"));
      if (a) {
        a.role = document.getElementById("edit-acc-role")?.value || a.role;
        toast("角色已更新");
        closeDrawer();
        renderPage();
      }
      return;
    }

    const tagBtn = e.target.closest("[data-tag-owner]");
    if (tagBtn) {
      const o = ADMIN_DATA.owners.find((x) => x.id === tagBtn.getAttribute("data-tag-owner"));
      const tagName = tagBtn.getAttribute("data-tag");
      if (o && tagName) {
        if (!o.tags.includes(tagName)) o.tags.push(tagName);
        toast(`已打标签：${tagName}`);
        viewOwner(o.id);
        renderPage();
      }
    }
  });

  document.getElementById("btn-export")?.addEventListener("click", () => toast("当前页数据导出（演示）"));
  document.getElementById("btn-refresh")?.addEventListener("click", () => {
    toast("已刷新");
    renderPage();
  });

  applyAdminRole("super", { silent: true });
})();
