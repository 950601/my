(() => {
  const app = document.getElementById("app");
  const tabbar = document.getElementById("tabbar");
  const state = {
    reportVirtue: "xiaoqin",
    reportDesc: "",
    reportTime: "",
    reportProject: "",
    reportScore: "",
    mallCate: "全部",
    reportsFilter: "全部",
    ordersFilter: "全部",
  };

  const isVolunteer = () => BADE_DATA.role === "volunteer";

  function applyRole(roleId, { silent } = {}) {
    const profile = BADE_ROLES[roleId];
    if (!profile) return;
    // persist current points back to role profile before switch
    if (BADE_DATA.user?.id && BADE_ROLES[BADE_DATA.user.id]) {
      BADE_ROLES[BADE_DATA.user.id].points = BADE_DATA.user.points;
      BADE_ROLES[BADE_DATA.user.id].monthGain = BADE_DATA.user.monthGain;
      BADE_ROLES[BADE_DATA.user.id].monthSpend = BADE_DATA.user.monthSpend;
    }
    BADE_DATA.role = roleId;
    BADE_DATA.user = { ...BADE_ROLES[roleId] };
    document.querySelectorAll("#role-switch [data-role]").forEach((btn) => {
      btn.classList.toggle("active", btn.getAttribute("data-role") === roleId);
    });
    if (!silent) toast(`已切换为${profile.label}`);
  }

  const TAB_ROUTES = new Set(["home", "report", "mall", "profile"]);

  function $(sel, root = document) {
    return root.querySelector(sel);
  }

  function parseRoute() {
    const hash = location.hash.replace(/^#\/?/, "") || "home";
    const [name, query = ""] = hash.split("?");
    const params = Object.fromEntries(new URLSearchParams(query));
    return { name, params };
  }

  function go(name, params = {}) {
    const q = new URLSearchParams(params).toString();
    location.hash = q ? `#/${name}?${q}` : `#/${name}`;
  }

  function toast(msg) {
    const old = $(".toast");
    if (old) old.remove();
    const el = document.createElement("div");
    el.className = "toast";
    el.textContent = msg;
    document.querySelector(".device").appendChild(el);
    setTimeout(() => el.remove(), 1800);
  }

  function topbar(title, { backTo, action } = {}) {
    const actionHtml = action
      ? `<button class="action" data-action="${action.key}" type="button">${action.label}</button>`
      : `<span style="width:34px"></span>`;
    return `
      <div class="topbar ${action ? "with-action" : ""}">
        <button class="back" type="button" data-back="${backTo || ""}">‹</button>
        <h1>${title}</h1>
        ${actionHtml}
      </div>
    `;
  }

  function modeText(mode, points, cash) {
    if (mode === "points") return `${points} 积分`;
    if (mode === "mix") return `${points} 积分 + ¥${cash}`;
    return `¥${cash}`;
  }

  function renderTabbar(active) {
    const items = [
      { id: "home", label: "首页", ico: "家" },
      { id: "report", label: "申报", ico: "德" },
      { id: "mall", label: "商城", ico: "兑" },
      { id: "profile", label: "我的", ico: "我" },
    ];
    tabbar.hidden = !TAB_ROUTES.has(active);
    app.classList.toggle("no-tab", !TAB_ROUTES.has(active));
    tabbar.innerHTML = items
      .map(
        (it) => `
      <button type="button" data-go="${it.id}" class="${it.id === active ? "active" : ""}">
        <span class="ico">${it.ico}</span>${it.label}
      </button>`
      )
      .join("");
  }

  function pageHome() {
    const u = BADE_DATA.user;
    return `
      <div class="page">
        <section class="hero">
          <div class="hero-brand">八德家风</div>
          <div class="hero-sub">孝亲 · 尊师 · 友学 · 立志 · 长善 · 救失 · 守法 · 循规</div>
          <div class="hero-points">
            <div class="num">${u.points}</div>
            <div class="label">我的积分</div>
          </div>
        </section>

        <section class="section">
          <div class="banner">
            ${BADE_DATA.banners
              .map(
                (b) => `
              <article class="banner-card ${b.gold ? "gold" : ""}">
                <h3>${b.title}</h3>
                <p>${b.desc}</p>
              </article>`
              )
              .join("")}
          </div>
        </section>

        <section class="section">
          <div class="section-head"><div class="section-title">便民入口</div></div>
          <div class="grid-entries">
            <button class="entry" data-go="report"><span class="entry-icon">报</span><span>行为申报</span></button>
            <button class="entry" data-go="reports"><span class="entry-icon gold">记</span><span>申报记录</span></button>
            <button class="entry" data-go="points"><span class="entry-icon">分</span><span>我的积分</span></button>
            <button class="entry" data-go="mall"><span class="entry-icon gold">商</span><span>积分商城</span></button>
            <button class="entry" data-go="orders"><span class="entry-icon gold">单</span><span>我的订单</span></button>
            <button class="entry" data-go="profile"><span class="entry-icon">档</span><span>个人中心</span></button>
          </div>
        </section>

        <section class="section">
          <div class="section-head">
            <div class="section-title">社区公告</div>
            <button class="section-more" type="button">更多</button>
          </div>
          <div class="list notice-list">
            ${BADE_DATA.notices
              .map(
                (n) => `
              <div class="list-item">
                <div class="thumb">告</div>
                <div class="body">
                  <div class="title">${n.title}</div>
                  <div class="desc">${n.time}</div>
                </div>
              </div>`
              )
              .join("")}
          </div>
        </section>
      </div>
    `;
  }

  function pageReport() {
    const chips = BADE_DATA.virtues
      .map(
        (v) => `
      <button type="button" class="chip ${state.reportVirtue === v.id ? "active" : ""}" data-virtue="${v.id}">
        ${v.name} · ${v.score}分
      </button>`
      )
      .join("");

    const volunteerFields = isVolunteer()
      ? `
            <div class="field">
              <label>公益项目 <span class="req">*</span></label>
              <select class="select" id="report-project">
                <option value="">请选择公益项目</option>
                ${BADE_DATA.welfareProjects
                  .map(
                    (p) =>
                      `<option value="${p.id}" ${state.reportProject === p.id ? "selected" : ""}>${p.name}</option>`
                  )
                  .join("")}
              </select>
            </div>
            <div class="field">
              <label>申报积分 <span class="req">*</span></label>
              <input class="input" id="report-score" type="number" min="1" step="1" placeholder="请填写本次申报积分" value="${state.reportScore}" />
            </div>`
      : "";

    return `
      <div class="page">
        ${topbar("八德行为申报", { backTo: "home" })}
        <section class="section">
          <div class="card form">
            ${volunteerFields}
            <div class="field">
              <label>八德分类 <span class="req">*</span></label>
              <div class="chips">${chips}</div>
            </div>
            <div class="field">
              <label>行为时间 <span class="req">*</span></label>
              <input class="input" id="report-time" type="datetime-local" value="${state.reportTime}" />
            </div>
            <div class="field">
              <label>行为描述 <span class="req">*</span></label>
              <textarea class="textarea" id="report-desc" placeholder="请简述行为内容与时间地点">${state.reportDesc}</textarea>
            </div>
            <div class="field">
              <label>现场照片 <span class="req">*</span></label>
              <div class="upload" id="report-upload">
                <div style="text-align:center">
                  <div class="plus">＋</div>
                  <div>上传照片（演示）</div>
                </div>
              </div>
            </div>
          </div>
          <div class="sticky-footer">
            <button class="btn primary block" type="button" id="submit-report">提交申报</button>
          </div>
        </section>
      </div>
    `;
  }

  function pageReports() {
    const filters = ["全部", "待审核", "已通过", "已驳回"];
    const map = { 待审核: "pending", 已通过: "passed", 已驳回: "rejected" };
    const list = BADE_DATA.reports.filter((r) => {
      if (state.reportsFilter === "全部") return true;
      return r.status === map[state.reportsFilter];
    });

    return `
      <div class="page">
        ${topbar("我的申报记录", { backTo: "home" })}
        <div class="tabs">
          ${filters
            .map(
              (f) => `
            <button class="tab-pill ${state.reportsFilter === f ? "active" : ""}" data-reports-filter="${f}" type="button">${f}</button>`
            )
            .join("")}
        </div>
        <section class="section list">
          ${
            list.length
              ? list
                  .map((r) => {
                    const st = BADE_STATUS[r.status];
                    return `
                <article class="list-item">
                  <div class="thumb">${r.virtue.slice(0, 1)}</div>
                  <div class="body">
                    <div class="title">${r.virtue} · ${r.id}</div>
                    ${r.projectName ? `<div class="desc" style="margin-bottom:4px"><span class="tag gold">公益项目</span> ${r.projectName}</div>` : ""}
                    <div class="desc">${r.desc}</div>
                    ${r.reason ? `<div class="desc" style="color:var(--danger);margin-top:6px">驳回原因：${r.reason}</div>` : ""}
                    <div class="meta">
                      <span class="tag ${st.cls}">${st.text}</span>
                      <span style="color:var(--gold);font-weight:600">${r.score} 分</span>
                      <span style="color:var(--muted)">${r.time}</span>
                    </div>
                    ${
                      r.status === "rejected"
                        ? `<button class="btn ghost" style="margin-top:10px;padding:8px 12px;font-size:13px" data-go="report" type="button">补充提交</button>`
                        : ""
                    }
                  </div>
                </article>`;
                  })
                  .join("")
              : `<div class="empty">暂无申报记录</div>`
          }
        </section>
      </div>
    `;
  }

  function pagePoints() {
    const u = BADE_DATA.user;
    return `
      <div class="page">
        ${topbar("我的积分", { backTo: "home" })}
        <div class="points-balance">
          <div class="label">当前积分余额</div>
          <div class="num">${u.points}</div>
          <div class="row">
            <div class="mini">本月获取<strong>+${u.monthGain}</strong></div>
            <div class="mini">本月消耗<strong>-${u.monthSpend}</strong></div>
          </div>
        </div>
        <section class="section">
          <div class="section-head"><div class="section-title">积分明细</div></div>
          <div class="card">
            ${BADE_DATA.flows
              .map(
                (f) => `
              <div class="flow-item">
                <div class="left">
                  <div class="t">${f.title}</div>
                  <div class="d">${f.source} · ${f.time}</div>
                </div>
                <div class="amt ${f.type === "gain" ? "plus" : "minus"}">
                  ${f.type === "gain" ? "+" : "-"}${f.amount}
                </div>
              </div>`
              )
              .join("")}
          </div>
        </section>
      </div>
    `;
  }

  function pageMall() {
    const cates = ["全部", "粮油生鲜", "家政维修", "康养康复", "物业费抵扣券"];
    const list = BADE_DATA.products.filter(
      (p) => state.mallCate === "全部" || p.cate === state.mallCate
    );
    return `
      <div class="page">
        ${topbar("积分商城", { backTo: "home" })}
        <div class="tabs">
          ${cates
            .map(
              (c) => `
            <button class="tab-pill ${state.mallCate === c ? "active" : ""}" data-mall-cate="${c}" type="button">${c}</button>`
            )
            .join("")}
        </div>
        <section class="section">
          <div class="product-grid">
            ${list
              .map(
                (p) => `
              <button class="product" type="button" data-go="product" data-id="${p.id}">
                <div class="cover">${p.icon}</div>
                <div class="info">
                  <div class="name">${p.name}</div>
                  <div class="price">${modeText(p.mode, p.points, p.cash)}</div>
                  <div class="mode">${BADE_MODE[p.mode]} · 库存 ${p.stock}</div>
                </div>
              </button>`
              )
              .join("")}
          </div>
        </section>
      </div>
    `;
  }

  function pageProduct(params) {
    const p = BADE_DATA.products.find((x) => x.id === params.id) || BADE_DATA.products[0];
    return `
      <div class="page">
        ${topbar("商品详情", { backTo: "mall" })}
        <section class="section">
          <div class="card" style="padding:0;overflow:hidden">
            <div class="product">
              <div class="cover" style="height:180px;font-size:56px;border-radius:0">${p.icon}</div>
            </div>
            <div style="padding:16px">
              <div style="font-size:18px;font-weight:700;margin-bottom:8px">${p.name}</div>
              <div style="color:var(--gold);font-size:20px;font-weight:700;margin-bottom:8px">${modeText(p.mode, p.points, p.cash)}</div>
              <div style="display:flex;gap:8px;margin-bottom:12px">
                <span class="tag cate">${p.cate}</span>
                <span class="tag gold">${BADE_MODE[p.mode]}</span>
              </div>
              <p style="font-size:13px;color:var(--muted);line-height:1.6">
                兑换后生成电子兑换券，商家扫码核销完成订单。积分不足时无法下单；积分加现金模式将唤起微信支付补齐差价。
              </p>
              <p style="font-size:12px;color:var(--muted);margin-top:10px">库存 ${p.stock} · 当前积分 ${BADE_DATA.user.points}</p>
            </div>
          </div>
          <div class="sticky-footer">
            <button class="btn primary block" type="button" id="buy-product" data-id="${p.id}">立即兑换</button>
          </div>
        </section>
      </div>
    `;
  }

  function pageOrders() {
    const filters = ["全部", "待发货", "待核销", "已完成"];
    const map = { 待发货: "pending_ship", 待核销: "pending_verify", 已完成: "done" };
    const list = BADE_DATA.orders.filter((o) => {
      if (state.ordersFilter === "全部") return true;
      return o.status === map[state.ordersFilter];
    });
    return `
      <div class="page">
        ${topbar("我的订单", { backTo: "profile" })}
        <div class="tabs">
          ${filters
            .map(
              (f) => `
            <button class="tab-pill ${state.ordersFilter === f ? "active" : ""}" data-orders-filter="${f}" type="button">${f}</button>`
            )
            .join("")}
        </div>
        <section class="section list">
          ${list
            .map((o) => {
              const st = BADE_STATUS[o.status];
              return `
              <article class="list-item" style="cursor:pointer" data-go="order" data-id="${o.id}">
                <div class="thumb">兑</div>
                <div class="body">
                  <div class="title">${o.name}</div>
                  <div class="desc">${o.id} · ${o.time}</div>
                  <div class="meta">
                    <span class="tag ${st.cls}">${st.text}</span>
                    <span style="color:var(--gold);font-weight:600">${modeText(o.cash ? (o.points ? "mix" : "cash") : "points", o.points, o.cash)}</span>
                  </div>
                </div>
              </article>`;
            })
            .join("")}
        </section>
      </div>
    `;
  }

  function pageOrder(params) {
    const o = BADE_DATA.orders.find((x) => x.id === params.id) || BADE_DATA.orders[0];
    const st = BADE_STATUS[o.status];
    return `
      <div class="page">
        ${topbar("订单详情", { backTo: "orders" })}
        <section class="section">
          <div class="card" style="text-align:center;padding:22px 16px">
            <div class="tag ${st.cls}" style="margin-bottom:12px">${st.text}</div>
            <div style="font-size:16px;font-weight:600">${o.name}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:6px">${o.id}</div>
            <div class="qr-box" title="兑换券二维码"></div>
            <div style="font-family:var(--serif);letter-spacing:.12em;font-size:18px">${o.code}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:8px">请向服务商出示二维码核销</div>
          </div>
          <div class="card" style="margin-top:12px">
            <div class="flow-item"><div class="left"><div class="t">支付方式</div></div><div>${modeText(o.cash ? (o.points ? "mix" : "cash") : "points", o.points, o.cash)}</div></div>
            <div class="flow-item"><div class="left"><div class="t">下单时间</div></div><div>${o.time}</div></div>
            <div class="flow-item"><div class="left"><div class="t">房号</div></div><div>${BADE_DATA.user.room}</div></div>
          </div>
        </section>
      </div>
    `;
  }

  function pageProfile() {
    const u = BADE_DATA.user;
    return `
      <div class="page">
        <div class="profile-head">
          <div class="avatar">${u.name.slice(0, 1)}</div>
          <div>
            <div class="name">${u.name} <span class="tag cate">${isVolunteer() ? "义工" : "业主"}</span></div>
            <div class="sub">${u.room} · ${u.members} 名家庭成员</div>
            <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
              ${(u.tags || []).map((t) => `<span class="tag gold">${t}</span>`).join("")}
            </div>
          </div>
        </div>
        <div class="section">
          <div class="card" style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-size:12px;color:var(--muted)">我的积分</div>
              <div style="font-family:var(--serif);font-size:28px;margin-top:2px">${u.points}</div>
            </div>
            <button class="btn ghost" style="padding:8px 12px;font-size:13px" data-go="points" type="button">明细</button>
          </div>
        </div>
        <div class="menu">
          <button type="button" data-go="reports"><span>我的申报</span><span class="arrow">›</span></button>
          <button type="button" data-go="orders"><span>我的订单</span><span class="arrow">›</span></button>
          <button type="button" data-go="mall"><span>积分商城</span><span class="arrow">›</span></button>
          <button type="button" data-go="bind"><span>绑定房号</span><span class="arrow">›</span></button>
          <button type="button" id="privacy"><span>隐私协议</span><span class="arrow">›</span></button>
        </div>
        <p style="text-align:center;color:var(--muted);font-size:11px;margin:18px 14px">右上角可切换角色测试 · 数据均为本地 mock</p>
      </div>
    `;
  }

  function pageBind() {
    return `
      <div class="page">
        ${topbar("绑定房号", { backTo: "profile" })}
        <section class="section">
          <div class="card form">
            <div class="field"><label>楼栋</label><input class="input" value="3栋" /></div>
            <div class="field"><label>房号</label><input class="input" value="1202" /></div>
            <div class="field"><label>业主姓名</label><input class="input" value="张明德" /></div>
            <div class="field"><label>手机号</label><input class="input" value="13866886821" /></div>
            <p style="font-size:12px;color:var(--muted);line-height:1.5">提交后需后台审核通过方可生效，支持一户多成员绑定。</p>
            <button class="btn primary block" type="button" id="submit-bind">提交绑定申请</button>
          </div>
        </section>
      </div>
    `;
  }

  const pages = {
    home: pageHome,
    report: pageReport,
    reports: pageReports,
    points: pagePoints,
    mall: pageMall,
    product: pageProduct,
    orders: pageOrders,
    order: pageOrder,
    profile: pageProfile,
    bind: pageBind,
  };

  function render() {
    const route = parseRoute();
    // 物业工单评价、问卷活动已挪至二期
    if (route.name === "evaluate" || route.name === "survey") {
      go("home");
      return;
    }
    const page = pages[route.name] || pageHome;
    const activeTab = TAB_ROUTES.has(route.name) ? route.name : "";
    renderTabbar(activeTab || (route.name === "product" ? "mall" : ""));
    app.innerHTML = page(route.params);
    bindEvents(route);
  }

  function bindEvents(route) {
    app.querySelectorAll("[data-go]").forEach((el) => {
      el.addEventListener("click", () => {
        const name = el.getAttribute("data-go");
        const id = el.getAttribute("data-id");
        go(name, id ? { id } : {});
      });
    });

    app.querySelectorAll("[data-back]").forEach((el) => {
      el.addEventListener("click", () => {
        const to = el.getAttribute("data-back");
        if (to) go(to);
        else history.back();
      });
    });

    app.querySelectorAll("[data-virtue]").forEach((el) => {
      el.addEventListener("click", () => {
        state.reportVirtue = el.getAttribute("data-virtue");
        state.reportDesc = $("#report-desc")?.value || "";
        state.reportTime = $("#report-time")?.value || "";
        state.reportProject = $("#report-project")?.value || state.reportProject;
        state.reportScore = $("#report-score")?.value || state.reportScore;
        render();
      });
    });

    $("#report-project")?.addEventListener("change", (e) => {
      state.reportProject = e.target.value;
    });
    $("#report-score")?.addEventListener("input", (e) => {
      state.reportScore = e.target.value;
    });

    $("#report-upload")?.addEventListener("click", () => toast("已选择示例照片"));
    $("#submit-report")?.addEventListener("click", () => {
      const desc = $("#report-desc")?.value.trim();
      const time = $("#report-time")?.value;
      const projectId = $("#report-project")?.value || "";
      const claimedScore = Number($("#report-score")?.value || 0);
      if (!desc || !time) {
        toast("请完善必填项");
        return;
      }
      if (isVolunteer() && !projectId) {
        toast("请选择公益项目");
        return;
      }
      if (isVolunteer() && (!claimedScore || claimedScore <= 0)) {
        toast("请填写申报积分");
        return;
      }
      const virtue = BADE_DATA.virtues.find((v) => v.id === state.reportVirtue);
      const project = BADE_DATA.welfareProjects.find((p) => p.id === projectId);
      const score = isVolunteer() ? claimedScore : virtue.score;
      BADE_DATA.reports.unshift({
        id: "R" + Date.now().toString().slice(-11),
        virtue: virtue.name,
        desc,
        time: time.replace("T", " "),
        status: "pending",
        score,
        claimedScore: isVolunteer() ? claimedScore : undefined,
        role: BADE_DATA.role,
        projectId: project?.id || "",
        projectName: project?.name || "",
      });
      state.reportDesc = "";
      state.reportTime = "";
      state.reportProject = "";
      state.reportScore = "";
      toast("已提交，等待审核");
      go("reports");
    });

    app.querySelectorAll("[data-reports-filter]").forEach((el) => {
      el.addEventListener("click", () => {
        state.reportsFilter = el.getAttribute("data-reports-filter");
        render();
      });
    });

    app.querySelectorAll("[data-mall-cate]").forEach((el) => {
      el.addEventListener("click", () => {
        state.mallCate = el.getAttribute("data-mall-cate");
        render();
      });
    });

    app.querySelectorAll("[data-orders-filter]").forEach((el) => {
      el.addEventListener("click", () => {
        state.ordersFilter = el.getAttribute("data-orders-filter");
        render();
      });
    });

    $("#buy-product")?.addEventListener("click", () => {
      const id = $("#buy-product").getAttribute("data-id");
      const p = BADE_DATA.products.find((x) => x.id === id);
      if (!p) return;
      if (p.mode !== "cash" && BADE_DATA.user.points < p.points) {
        toast("积分不足");
        return;
      }
      if (p.mode !== "cash") BADE_DATA.user.points -= p.points;
      const order = {
        id: "O" + Date.now().toString().slice(-11),
        productId: p.id,
        name: p.name,
        points: p.points,
        cash: p.cash,
        status: p.mode === "points" ? "pending_verify" : "pending_ship",
        time: new Date().toISOString().slice(0, 16).replace("T", " "),
        code: "BD-" + Math.floor(100000 + Math.random() * 900000),
      };
      BADE_DATA.orders.unshift(order);
      BADE_DATA.flows.unshift({
        id: Date.now(),
        title: `兑换${p.name}`,
        type: "spend",
        amount: p.points || 0,
        time: order.time.slice(5),
        source: "兑换扣减",
      });
      if (p.mode === "mix" || p.mode === "cash") toast("演示：已模拟微信支付");
      else toast("兑换成功");
      go("order", { id: order.id });
    });

    $("#submit-bind")?.addEventListener("click", () => toast("已提交，等待后台审核"));
    $("#privacy")?.addEventListener("click", () =>
      toast("隐私协议：禁止批量导出业主手机号等敏感信息")
    );
  }

  tabbar.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-go]");
    if (btn) go(btn.getAttribute("data-go"));
  });

  document.getElementById("role-switch")?.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-role]");
    if (!btn) return;
    const role = btn.getAttribute("data-role");
    if (role === BADE_DATA.role) return;
    applyRole(role);
    go("home");
    render();
  });

  function tickClock() {
    const el = document.getElementById("status-time");
    if (!el) return;
    const now = new Date();
    el.textContent = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  }

  window.addEventListener("hashchange", render);
  tickClock();
  setInterval(tickClock, 30000);
  applyRole(BADE_DATA.role || "owner", { silent: true });
  if (!location.hash) location.hash = "#/home";
  else render();
})();
