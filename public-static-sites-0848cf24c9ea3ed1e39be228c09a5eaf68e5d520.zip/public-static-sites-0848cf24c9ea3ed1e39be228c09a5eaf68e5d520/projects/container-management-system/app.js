/* =====================================================================
   周转箱全流程管理系统 · 高保真交互原型
   纯前端，无外部依赖。所有数据为演示用 Mock 数据。
   ===================================================================== */

/* ---------- 图标库 (SVG) ---------- */
const ICON = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
  inventory: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/></svg>',
  bom: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="currentColor"/><circle cx="15" cy="12" r="2" fill="currentColor"/><circle cx="9" cy="18" r="2" fill="currentColor"/></svg>',
  calc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="11" x2="8" y2="11"/><line x1="12" y1="11" x2="12" y2="11"/><line x1="16" y1="11" x2="16" y2="11"/><line x1="8" y1="15" x2="8" y2="15"/><line x1="12" y1="15" x2="12" y2="15"/><line x1="16" y1="15" x2="16" y2="15"/></svg>',
  flow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h6m0 0l-3-3m3 3l-3 3"/><path d="M15 12h6m0 0l-3-3m3 3l-3 3"/></svg>',
  loss: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>',
  mrp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/></svg>',
  spec: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>',
  user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.1-1l2-1.5-2-3.4-2.3 1a7 7 0 00-1.7-1L14.5 3h-5l-.4 2.6a7 7 0 00-1.7 1l-2.3-1-2 3.4 2 1.5a7 7 0 000 2l-2 1.5 2 3.4 2.3-1a7 7 0 001.7 1l.4 2.6h5l.4-2.6a7 7 0 001.7-1l2.3 1 2-3.4-2-1.5a7 7 0 00.1-1z"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16" y2="16"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/></svg>',
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  box: '📦', truck: '🚚', factory: '🏭', warn: '⚠️', check: '✅', refresh: '🔄', flag: '🚩',
  ledger: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/></svg>',
  inbound: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h11l5 5v11H4z"/><path d="M15 4v5h5"/><path d="M8 13h8M8 17h8"/></svg>',
  issue: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/></svg>',
  ret: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 11-3-6.7M21 4v4h-4"/></svg>'
};

/* ---------- Mock 数据 ---------- */
const STATE_COLOR = { blue: 'blue', green: 'green', orange: 'orange', purple: 'purple', red: 'red', cyan: 'cyan' };

const DATA = {
  specs: [
    { code: 'TBX-A1', name: '标准周转箱', size: '600×400×300', load: '20kg', status: '在用', usage: 86, idle: 120 },
    { code: 'TBX-B2', name: '加强周转箱', size: '800×600×400', load: '50kg', status: '在用', usage: 73, idle: 210 },
    { code: 'TBX-C3', name: '折叠周转箱', size: '600×400×200', load: '15kg', status: '在用', usage: 64, idle: 95 },
    { code: 'TBX-D4', name: '防静电周转箱', size: '400×300×200', load: '10kg', status: '在用', usage: 91, idle: 30 },
    { code: 'TBX-E5', name: '带盖周转箱', size: '500×350×250', load: '18kg', status: '闲置', usage: 22, idle: 380 },
    { code: 'TBX-F6', name: '欧标周转箱', size: '600×400×340', load: '25kg', status: '停用', usage: 0, idle: 60 },
  ],
  products: [
    { code: 'P-1001', name: '智能音箱 X1', specs: [{ code: 'TBX-A1', qty: 2 }, { code: 'TBX-D4', qty: 1 }] },
    { code: 'P-1002', name: '千兆路由器 R3', specs: [{ code: 'TBX-C3', qty: 1 }] },
    { code: 'P-2001', name: '曲面显示器 M7', specs: [{ code: 'TBX-B2', qty: 1 }, { code: 'TBX-A1', qty: 1 }] },
    { code: 'P-2002', name: '机顶盒 S2', specs: [{ code: 'TBX-C3', qty: 1 }, { code: 'TBX-D4', qty: 1 }] },
    { code: 'P-3001', name: '智能门锁 L9', specs: [{ code: 'TBX-A1', qty: 1 }] },
  ],
  stages: [
    { key: 'supplier', name: '供应商在制/在途来料', owner: '采购 · 王磊', color: 'blue', items: [['在制', 320], ['已完工待发', 180], ['在途来料', 150]] },
    { key: 'wip_in', name: '五产待入库来料', owner: '仓库 · 李娜', color: 'cyan', items: [['待收货核验', 85]] },
    { key: 'wip', name: '五产库存储备', owner: '仓库 · 李娜', color: 'green', items: [['可用库存', 1240], ['破损待处理', 36], ['闲置库存', 210]] },
    { key: 'transit', name: '转运顺达在途', owner: '物流 · 赵强', color: 'purple', items: [['五产→顺达在途', 230]] },
    { key: 'cust_stock', name: '客户仓库在库', owner: '客户对接 · 陈静', color: 'orange', items: [['客户在库可用', 980]] },
    { key: 'cust_use', name: '客户上线在用', owner: '客户对接 · 陈静', color: 'blue', items: [['客户在用', 760]] },
    { key: 'cust_recycle', name: '客户待回收', owner: '客户对接 · 陈静', color: 'cyan', items: [['待返程归集', 140]] },
    { key: 'return', name: '返程在途', owner: '物流 · 赵强', color: 'purple', items: [['物流返程在途', 120]] },
    { key: 'loss', name: '损耗 / 报废(累计)', owner: '质量 · 孙伟', color: 'red', items: [['累计损耗', 158]] },
  ],
  orders: [
    { id: 'SO-20260801', customer: '华东家电渠道', product: 'P-1001', qty: 500, status: '待核算' },
    { id: 'SO-20260802', customer: '南方数码连锁', product: 'P-2001', qty: 300, status: '已生成需求' },
    { id: 'SO-20260803', customer: '北方工贸', product: 'P-1002', qty: 800, status: '待核算' },
    { id: 'SO-20260804', customer: '西部电商仓', product: 'P-3001', qty: 1200, status: '缺口预警' },
    { id: 'SO-20260805', customer: '华南代工', product: 'P-2002', qty: 450, status: '已生成需求' },
  ],
  flowRecords: [
    { doc: 'IN-260805-07', type: '供应商来料入库', spec: 'TBX-A1', dept: '仓库', qty: 600, from: '供应商-宏达', to: '五产仓库', op: '李娜', time: '08-05 09:12', status: '已入库' },
    { doc: 'OUT-260804-12', type: '转运顺达出库', spec: 'TBX-B2', dept: '物流', qty: 230, from: '五产仓库', to: '顺达转运', op: '赵强', time: '08-04 14:30', status: '在途' },
    { doc: 'CIN-260804-03', type: '客户仓库入库', spec: 'TBX-A1', dept: '客户对接', qty: 400, from: '顺达转运', to: '华东客户仓', op: '陈静', time: '08-04 16:05', status: '已入库' },
    { doc: 'USE-260803-21', type: '客户领用上线', spec: 'TBX-D4', dept: '客户对接', qty: 320, from: '华东客户仓', to: '客户产线', op: '陈静', time: '08-03 10:40', status: '在用' },
    { doc: 'REC-260802-09', type: '客户回收归集', spec: 'TBX-C3', dept: '客户对接', qty: 140, from: '客户产线', to: '客户待回收', op: '陈静', time: '08-02 17:20', status: '待返程' },
    { doc: 'RET-260801-05', type: '物流返程入库', spec: 'TBX-A1', dept: '仓库', qty: 480, from: '返程在途', to: '五产仓库', op: '李娜', time: '08-01 11:00', status: '已核验' },
    { doc: 'LOS-260801-02', type: '损耗报废登记', spec: 'TBX-B2', dept: '质量', qty: 12, from: '五产仓库', to: '报废区', op: '孙伟', time: '08-01 15:30', status: '已报废' },
  ],
  lossRecords: [
    { id: 'LOS-001', node: '五产收货核验', type: '运输破损', spec: 'TBX-B2', qty: 12, reason: '装卸跌落', respLink: '质量', stockImpact: '是', status: '已报废', audit: '已确认', owner: '孙伟', dept: '质量', time: '08-01' },
    { id: 'LOS-002', node: '客户产线', type: '生产损耗', spec: 'TBX-D4', qty: 8, reason: '装配划伤', respLink: '质量', stockImpact: '是', status: '已报废', audit: '已确认', owner: '孙伟', dept: '质量', time: '07-30' },
    { id: 'LOS-003', node: '返程运输', type: '丢失', spec: 'TBX-A1', qty: 5, reason: '物流交接遗漏', respLink: '物流', stockImpact: '是', status: '已核销', audit: '已确认', owner: '赵强', dept: '物流', time: '07-29' },
    { id: 'LOS-004', node: '客户仓库', type: '老化报废', spec: 'TBX-E5', qty: 20, reason: '超期老化', respLink: '客户对接', stockImpact: '是', status: '已报废', audit: '已确认', owner: '陈静', dept: '客户对接', time: '07-28' },
    { id: 'LOS-005', node: '五产仓库', type: '周转损耗', spec: 'TBX-A1', qty: 6, reason: '卡扣断裂', respLink: '质量', stockImpact: '是', status: '已报废', audit: '已确认', owner: '孙伟', dept: '质量', time: '07-27' },
  ],
  poInbound: {
    po: 'PO-2608001',
    supplier: '供应商-宏达',
    status: '已确认',
    eta: '2026-08-06',
    factoryBase: 640,
    items: [
      { spec: 'TBX-A1', name: 'A1 标准周转箱', ordered: 1000, received: 600, inTransit: 400 },
      { spec: 'TBX-B2', name: 'B2 加固周转箱', ordered: 500, received: 500, inTransit: 0 },
    ],
    events: [
      { doc: 'PO-2608001', biz: 'PO创建并确认 (ERP)', spec: 'TBX-A1', dept: '采购', qty: 1000, dir: '+', status: '已确认', time: '07-28 10:00', owner: '王磊' },
      { doc: 'PO-2608001', biz: '形成采购在途 (本项目)', spec: 'TBX-A1', dept: '采购', qty: 1000, dir: '+', status: '在途', time: '07-28 10:01', owner: '系统' },
      { doc: 'IN-260805-07', biz: '供应商来料入库 (部分)', spec: 'TBX-A1', dept: '仓库', qty: 600, dir: '+', status: '已入库', time: '08-05 09:12', owner: '李娜' },
      { doc: 'RT-260805-01', biz: '到货不良退货冲销', spec: 'TBX-A1', dept: '质量', qty: -30, dir: '-', status: '已冲销', time: '08-05 14:00', owner: '孙伟' },
    ],
  },
  /* 完工入库倒冲规则 — 生产工单种子（暂定方向：产品完工入库触发按BOM倒冲周转箱） */
  backflushSeed: [
    { id: 'WO-20260801', mo: 'MO-20260801', product: 'P-1001', customer: '华东家电渠道', planQty: 500, finishedQty: 0, status: '草稿', reversed: false, docs: {}, events: [
        { doc: 'WO-20260801', biz: '获取有效生产工单 (MES)', spec: '—', dept: '计划', qty: 0, dir: '+', status: '有效', time: '08-01 09:00', owner: '王磊' },
      ],
      bom: [ { spec: 'TBX-A1', perUnit: 2, role: '主料' }, { spec: 'TBX-D4', perUnit: 1, role: '主料' } ] },
    { id: 'WO-20260802', mo: 'MO-20260802', product: 'P-2001', customer: '华南数码连锁', planQty: 300, finishedQty: 300, status: '已倒冲', reversed: false, docs: { bf: 'BF-2608002' }, events: [
        { doc: 'WO-20260802', biz: '获取有效生产工单 (MES)', spec: '—', dept: '计划', qty: 0, dir: '+', status: '有效', time: '07-30 09:00', owner: '王磊' },
        { doc: 'BF-2608002', biz: '完工入库倒冲 (按BOM)', spec: '多规格', dept: '仓库', qty: -600, dir: '-', status: '已倒冲', time: '08-01 16:00', owner: '李娜' },
      ],
      bom: [ { spec: 'TBX-B2', perUnit: 1, role: '主料' }, { spec: 'TBX-A1', perUnit: 1, role: '主料', alt: 'TBX-C3' } ] },
  ],
  /* 4.4.3 客户返程 — 返程登记单列表种子（含完整字段与异常闭环） */
  custReturnSeed: [
    { id: 'RR-2608001', customer: '华东家电渠道', spec: 'TBX-A1', qty: 480, eta: '2026-08-06', status: '草稿',
      carrier: '', waybill: '', fromDept: '物流部', toWh: '五产仓库', planShip: '', actShip: '', actArr: '',
      good: 0, bad: 0, short: 0, goodReason: '', badReason: '', shortReason: '', acceptBy: '', acceptTime: '', cxReason: '', reversed: false,
      dispatched: false, arrived: false, docs: {}, events: [
        { doc: 'RR-2608001', biz: '创建返程登记 (业务人员)', spec: 'TBX-A1', dept: '物流', qty: 480, dir: '+', status: '草稿', time: '08-01 13:00', owner: '赵强' },
      ] },
    { id: 'RR-2608002', customer: '华南数码连锁', spec: 'TBX-C3', qty: 260, eta: '2026-08-05', status: '已完成',
      carrier: '顺达物流', waybill: 'SF-77120934', fromDept: '物流部', toWh: '五产仓库', planShip: '2026-07-30', actShip: '2026-07-30 10:00', actArr: '2026-08-01 16:40',
      good: 252, bad: 5, short: 3, goodReason: '外观完好', badReason: '运输挤压变形', shortReason: '交接清点差异', acceptBy: '孙伟', acceptTime: '2026-08-01 17:30', cxReason: '', reversed: false,
      dispatched: true, arrived: true, docs: { ship: 'SH-2608002', accept: 'ACC-2608002', diff: 'DIF-2608002' }, events: [
        { doc: 'RR-2608002', biz: '创建返程登记 (业务人员)', spec: 'TBX-C3', dept: '物流', qty: 260, dir: '+', status: '草稿', time: '07-29 13:00', owner: '赵强' },
        { doc: 'SH-2608002', biz: '确认发运 → 形成返回在途', spec: 'TBX-C3', dept: '物流', qty: 260, dir: '+', status: '返回在途', time: '07-30 10:00', owner: '赵强' },
        { doc: 'ACC-2608002', biz: '到货验收 · 合格入工厂可用', spec: 'TBX-C3', dept: '质量', qty: 252, dir: '+', status: '工厂可用', time: '08-01 17:30', owner: '孙伟' },
        { doc: 'BAD-2608002', biz: '到货验收 · 破损入待处理', spec: 'TBX-C3', dept: '质量', qty: 5, dir: '+', status: '待处理', time: '08-01 17:30', owner: '孙伟' },
        { doc: 'DIF-2608002', biz: '短少生成差异记录', spec: 'TBX-C3', dept: '物流', qty: 3, dir: '+', status: '差异', time: '08-01 17:30', owner: '赵强' },
      ] },
  ],
  roles: [
    { role: '计划员', perm: { view: '●', inbound: '●', issue: '●', returnReg: '—', loss: '—', mrp: '●', purchase: '●', audit: '○', admin: '—' } },
    { role: '仓库管理员', perm: { view: '●', inbound: '●', issue: '●', returnReg: '—', loss: '●', mrp: '—', purchase: '—', audit: '○', admin: '—' } },
    { role: '物流专员', perm: { view: '●', inbound: '—', issue: '○', returnReg: '●', loss: '—', mrp: '—', purchase: '—', audit: '○', admin: '—' } },
    { role: '采购员', perm: { view: '●', inbound: '—', issue: '—', returnReg: '—', loss: '—', mrp: '○', purchase: '●', audit: '—', admin: '—' } },
    { role: '主数据管理员', perm: { view: '●', inbound: '—', issue: '—', returnReg: '—', loss: '—', mrp: '—', purchase: '—', audit: '—', admin: '○' } },
    { role: '审核人', perm: { view: '●', inbound: '○', issue: '○', returnReg: '○', loss: '○', mrp: '○', purchase: '○', audit: '●', admin: '—' } },
    { role: '系统管理员', perm: { view: '●', inbound: '●', issue: '●', returnReg: '●', loss: '●', mrp: '●', purchase: '●', audit: '●', admin: '●' } },
  ],
};

/* ---------- 供应商来料流程（PO → 在途 → 入库 → 反向流水） ---------- */
function buildPoState() {
  const b = JSON.parse(JSON.stringify(DATA.poInbound));
  b.factoryStock = b.factoryBase;
  b.inTransitTotal = b.items.reduce((a, i) => a + i.inTransit, 0);
  b.receivedTotal = b.items.reduce((a, i) => a + i.received, 0);
  b.orderedTotal = b.items.reduce((a, i) => a + i.ordered, 0);
  return b;
}
let poState = buildPoState();

function viewPoInbound() {
  const p = poState;
  return `
  <div class="page-head"><div><h1 class="page-title">供应商来料（PO 驱动）</h1><div class="page-desc">对照一期"数据底座 + 线上台账"：现有系统(ERP)创建/确认 PO 并执行入库，本项目读取有效 PO 与预计到货形成【采购在途】，同步 ERP 入库结果更新采购在途与工厂库存；退货/冲销生成【反向流水】。</div></div>
    <div class="row-flex"><button class="btn" onclick="poReset()">重置演示</button><button class="btn primary" onclick="toast('已生成采购在途快照')">${ICON.check} 生成在途快照</button></div>
  </div>

  <div class="card">
    <div class="stepper">
      <div class="step done"><div class="dot">1</div><div class="st-t">现有系统创建并确认 PO</div><div class="st-s">ERP · PO-2608001 已确认</div></div>
      <div class="step done"><div class="dot">2</div><div class="st-t">读取有效 PO + 预计到货</div><div class="st-s">本项目 · 形成采购在途</div></div>
      <div class="step done"><div class="dot">3</div><div class="st-t">执行全部 / 部分 PO 入库</div><div class="st-s">ERP · 已入库 ${fmt(p.receivedTotal)}</div></div>
      <div class="step done"><div class="dot">4</div><div class="st-t">同步结果 · 更新在途/库存</div><div class="st-s">本项目 · 含反向流水</div></div>
    </div>
    <svg class="chart-svg" viewBox="0 0 680 130">
      <rect x="10" y="22" width="150" height="86" rx="8" fill="var(--brand-50)" stroke="var(--brand)"/>
      <text x="85" y="52" text-anchor="middle" fill="var(--brand)" font-weight="700" font-size="13">现有系统 (ERP)</text>
      <text x="85" y="74" text-anchor="middle" fill="var(--text-2)" font-size="11">创建 / 确认 PO</text>
      <text x="85" y="92" text-anchor="middle" fill="var(--text-2)" font-size="11">执行全部 / 部分入库</text>
      <rect x="520" y="22" width="150" height="86" rx="8" fill="var(--purple-bg)" stroke="var(--purple)"/>
      <text x="595" y="52" text-anchor="middle" fill="var(--purple)" font-weight="700" font-size="13">本项目系统</text>
      <text x="595" y="74" text-anchor="middle" fill="var(--text-2)" font-size="11">读取 PO → 采购在途</text>
      <text x="595" y="92" text-anchor="middle" fill="var(--text-2)" font-size="11">同步 → 反向流水</text>
      <line x1="160" y1="48" x2="520" y2="48" stroke="var(--text-3)" stroke-dasharray="4 3"/>
      <text x="340" y="40" text-anchor="middle" fill="var(--text-3)" font-size="11">读取有效 PO + 预计到货 → 形成采购在途</text>
      <line x1="520" y1="80" x2="160" y2="80" stroke="var(--danger)" stroke-dasharray="4 3"/>
      <text x="340" y="112" text-anchor="middle" fill="var(--danger)" font-size="11">同步入库结果 → 更新在途 / 工厂库存 · 退货冲销反向流水</text>
    </svg>
  </div>

  <div class="split">
    <div class="card">
      <div class="card-head"><h3>采购订单行项目 · ${p.po}</h3><span class="sub">供应商：${p.supplier} · ETA ${p.eta} · ERP：${p.status}</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>规格</th><th>名称</th><th>订单量</th><th>已入库</th><th>采购在途</th><th>入库进度</th><th>状态</th></tr></thead>
        <tbody>${p.items.map(it => { const pct = Math.round(it.received / it.ordered * 100); const color = it.inTransit > 0 ? 'orange' : 'green'; return `<tr><td>${it.spec}</td><td>${it.name}</td><td class="num">${fmt(it.ordered)}</td><td class="num">${fmt(it.received)}</td><td class="num">${fmt(it.inTransit)}</td><td style="min-width:140px"><div class="meter ${color === 'green' ? 'green' : ''}"><span style="width:${pct}%"></span></div><div class="muted" style="font-size:11px;margin-top:2px">${pct}%</div></td><td>${badge(color, it.inTransit > 0 ? '部分在途' : '已入库')}</td></tr>`; }).join('')}</tbody>
      </table></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>采购在途 ⇄ 工厂库存 联动</h3><span class="sub">同步 ERP 入库后实时更新</span></div>
      <div class="kpi-inline">
        <div class="k">采购在途<b>${fmt(p.inTransitTotal)} 个</b></div>
        <div class="k" style="color:var(--text-3);font-size:20px">⇄</div>
        <div class="k">工厂库存(来料口径)<b>${fmt(p.factoryStock)} 个</b></div>
      </div>
      <div class="muted" style="margin-top:12px">本 PO 已入库 ${fmt(p.receivedTotal)} / 订单 ${fmt(p.orderedTotal)} 个。每次来料入库使"采购在途"等额减少、"工厂库存"等额增加；退货 / 冲销生成反向流水。</div>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>来料事件流水（含反向流水）</h3>
      <div class="row-flex">
        <button class="btn primary" ${p.inTransitTotal > 0 ? '' : 'disabled'} onclick="poReceiveRemaining()">执行剩余入库</button>
        <button class="btn danger" onclick="poReverse()">发起退货冲销</button>
        <button class="btn" onclick="poReset()">重置演示</button>
      </div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>单据 / 事件</th><th>业务环节</th><th>物料</th><th>部门</th><th class="num">数量</th><th>方向</th><th>状态</th><th>时间</th><th>责任人</th></tr></thead>
      <tbody>${p.events.slice().reverse().map(r => `<tr class="${r.dir === '-' ? 'rev' : ''}"><td>${r.doc}</td><td>${r.biz}</td><td>${r.spec}</td><td>${r.dept}</td><td class="num" style="${r.dir === '-' ? 'color:var(--danger);font-weight:600' : ''}">${r.dir === '+' ? '+' : ''}${fmt(r.qty)}</td><td>${r.dir === '+' ? badge('green', '▴ 正向') : badge('red', '▾ 反向')}</td><td>${badge(r.dir === '-' ? 'red' : 'green', r.status)}</td><td>${r.time}</td><td>${r.owner}</td></tr>`).join('')}</tbody>
    </table></div>
    <div class="muted" style="margin-top:10px">红色行为反向流水（退货 / 冲销），数量以负值计入镜像台账，与正向流水共同构成可审计的库存变动全貌。</div>
  </div>`;
}
function poReceiveRemaining() {
  const it = poState.items.find(i => i.inTransit > 0);
  if (!it) { toast('当前无采购在途数量'); return; }
  const qty = it.inTransit;
  it.received += qty; it.inTransit = 0;
  poState.factoryStock += qty;
  poState.inTransitTotal = poState.items.reduce((a, i) => a + i.inTransit, 0);
  poState.receivedTotal = poState.items.reduce((a, i) => a + i.received, 0);
  const doc = 'IN-260806-' + String(poState.events.length + 1).padStart(2, '0');
  poState.events.push({ doc, biz: '供应商来料入库 (剩余)', spec: it.spec, dept: '仓库', qty, dir: '+', status: '已入库', time: '08-06 10:30', owner: '李娜' });
  toast('已同步入库 ' + qty + ' 个：采购在途清零，工厂库存 +' + qty);
  rerender();
}
function poReverse() {
  const it = poState.items.find(i => i.received > 0) || poState.items[0];
  const qty = -20;
  poState.factoryStock += qty;
  poState.receivedTotal = poState.items.reduce((a, i) => a + i.received, 0);
  const doc = 'RT-260806-' + String(poState.events.length + 1).padStart(2, '0');
  poState.events.push({ doc, biz: '退货冲销 (反向流水)', spec: it.spec, dept: '质量', qty, dir: '-', status: '已冲销', time: '08-06 11:00', owner: '孙伟' });
  toast('已生成反向流水 ' + qty + ' 个：工厂库存 -20，已写入镜像台账');
  rerender();
}
function poReset() { poState = buildPoState(); toast('演示已重置'); rerender(); }

/* ============================ 完工入库倒冲规则（功能页 · 暂定方向待确认） ============================ */
let wiList = JSON.parse(JSON.stringify(DATA.backflushSeed));
let wiCurrent = wiList[0].id;
const wiFind = id => wiList.find(x => x.id === id);
const wiBackflushQty = w => w.finishedQty;
const wiPlanTotal = w => w.planQty;
const statusBadgeOf = s => s === '已倒冲' ? 'green' : s === '部分倒冲' ? 'orange' : 'gray';
function nowHM() { const d = new Date(); const p = n => String(n).padStart(2, '0'); return `08-07 ${p(d.getHours())}:${p(d.getMinutes())}`; }

function viewWorkIssue() {
  const w = wiFind(wiCurrent) || wiList[0];
  const finished = wiBackflushQty(w), plan = wiPlanTotal(w);
  const remain = plan - finished;
  const sb = statusBadgeOf(w.status);
  const canFlush = remain > 0 && !w.reversed;
  return `
  <div class="page-head"><div><h1 class="page-title">完工入库倒冲规则</h1><div class="page-desc"><b>暂定方向（待确认）：</b>以<b>产品完工入库</b>为触发点，系统按完工数量与包材 BOM 自动扣减周转箱库存（倒冲），而非传统手工工单领料。以下倒冲规则尚未最终确认，页面仅用于演示与对齐。${badge('orange', '待确认规则')}</div></div>
    <div class="row-flex"><button class="btn primary" onclick="wiNew()">＋ 新建生产工单</button><button class="btn" onclick="wiReset()">重置数据</button></div>
  </div>

  <div class="card" style="border-left:3px solid var(--warning)">
    <div class="card-head"><h3>待业务确认的扣减规则</h3><span class="sub">见评审 4.3</span></div>
    <ul class="todo">
      <li>库存扣减触发点：工单完工入库 / 销售发货 / 订单过账（待确认）</li>
      <li>一张工单分多次完工入库时，是否按每次入库数量分别倒冲（暂定：是）</li>
      <li>完工入库冲销后，周转箱库存是否自动恢复（暂定：是）</li>
      <li>替代料优先由系统自动扣减，还是仅提供扣减建议（待确认）</li>
      <li>替代料不足后是否继续扣减主料（待确认）</li>
      <li>主料和替代料都不足时，允许负库存 / 阻断入库 / 生成异常记录（待确认）</li>
    </ul>
  </div>

  <div class="split">
    <div class="card" style="flex:1.1">
      <div class="card-head"><h3>生产工单列表</h3><span class="sub">完工事件来自 MES（暂定）</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>工单号</th><th>产品</th><th>计划/已倒冲</th><th>状态</th><th></th></tr></thead>
        <tbody>${wiList.map(x => `<tr class="${x.id === wiCurrent ? 'row-active' : ''}" style="cursor:pointer" onclick="wiOpen('${x.id}')"><td><b>${x.id}</b></td><td>${productName(x.product)}</td><td class="num">${fmt(x.planQty)} / ${fmt(x.finishedQty)}</td><td>${badge(statusBadgeOf(x.status), x.status)}</td><td><button class="btn sm" onclick="event.stopPropagation();wiOpen('${x.id}')">处理</button></td></tr>`).join('')}</tbody>
      </table></div>
    </div>
    <div class="card" style="flex:1.4">
      <div class="card-head"><h3>当前工单 · ${w.id}</h3><span class="sub">${productName(w.product)} · ${w.customer} · ${badge(sb, w.status)}</span></div>
      <div class="stepper">
        <div class="step done"><div class="dot">1</div><div class="st-t">获取生产工单</div><div class="st-s">MES</div></div>
        <div class="step ${finished > 0 ? 'done' : ''}"><div class="dot">2</div><div class="st-t">完工入库倒冲</div><div class="st-s">按BOM扣减</div></div>
        <div class="step"><div class="dot">3</div><div class="st-t">库存扣减生效</div><div class="st-s">工厂可用↓</div></div>
        <div class="step ${w.reversed ? 'done' : ''}"><div class="dot">4</div><div class="st-t">冲销恢复</div><div class="st-s">反向流水</div></div>
      </div>
      <div class="table-wrap" style="margin-top:14px"><table class="tbl">
        <thead><tr><th>规格(物料)</th><th>单台用量</th><th>替代料</th><th>本次倒冲扣减</th><th>状态</th></tr></thead>
        <tbody>${w.bom.map(it => { const dec = remain > 0 ? remain * it.perUnit : 0; const color = it.role === '主料' ? 'blue' : 'purple'; return `<tr><td>${specName(it.spec)}</td><td class="num">×${it.perUnit}</td><td>${it.alt ? badge('purple', it.alt) : '—'}</td><td class="num" style="${dec > 0 ? 'color:var(--danger);font-weight:600' : ''}">${dec > 0 ? '−' + fmt(dec) : '已倒冲'}</td><td>${badge(color, it.role)}</td></tr>`; }).join('')}</tbody>
      </table></div>
      <div class="kpi-inline" style="margin-top:12px">
        <div class="k">计划完工<b>${fmt(plan)} 台</b></div>
        <div class="k" style="color:var(--text-3)">/</div>
        <div class="k">已倒冲<b>${fmt(finished)} 台</b></div>
        <div class="k" style="color:var(--text-3)">/</div>
        <div class="k">待倒冲<b>${fmt(remain)} 台</b></div>
      </div>
      ${canFlush ? `
      <div class="row-flex" style="margin-top:14px;align-items:flex-end;gap:12px;flex-wrap:wrap">
        <div class="field" style="min-width:160px"><label>本次完工入库数量</label><input id="wi-finish" type="number" value="${remain}"></div>
        <button class="btn primary" onclick="wiFinish()">确认完工入库并倒冲</button>
      </div>` : `<div class="muted" style="margin-top:12px">${w.reversed ? '本工单已冲销，倒冲结果已回退。' : '本工单已全部倒冲，无需再次操作。'}</div>`}
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>关联单据</h3><span class="sub">本工单生成的倒冲单据</span></div>
    <div class="doc-row">${wiDocs(w)}</div>
  </div>

  <div class="card">
    <div class="card-head"><h3>倒冲 / 冲销事件流水（含反向流水）</h3>
      <div class="row-flex">
        <button class="btn danger" ${w.reversed || finished === 0 ? 'disabled title="无已完成倒冲可冲销，或已冲销"' : ''} onclick="wiReverse()">${w.reversed ? '已冲销' : '发起完工冲销'}</button>
      </div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>单据/事件</th><th>业务环节</th><th>物料</th><th>部门</th><th class="num">数量</th><th>方向</th><th>状态</th><th>时间</th><th>责任人</th></tr></thead>
      <tbody>${w.events.slice().reverse().map(r => `<tr class="${r.dir === '-' ? 'rev' : ''}"><td>${r.doc}</td><td>${r.biz}</td><td>${r.spec}</td><td>${r.dept}</td><td class="num" style="${r.dir === '-' ? 'color:var(--danger);font-weight:600' : ''}">${r.dir === '+' ? '+' : ''}${fmt(r.qty)}</td><td>${r.dir === '+' ? badge('green', '▴ 正向') : badge('red', '▾ 反向')}</td><td>${badge(r.dir === '-' ? 'red' : 'green', r.status)}</td><td>${r.time}</td><td>${r.owner}</td></tr>`).join('')}</tbody>
    </table></div>
    <div class="muted" style="margin-top:10px">倒冲为"库存减少"动作，以反向流水（红色）记录并在台账可追溯；冲销后工厂可用库存自动恢复。</div>
  </div>`;
}
function wiDocs(w) {
  const docs = [
    { no: w.id, t: '生产工单', s: w.status, c: 'blue' },
    { no: w.mo, t: '生产订单', s: '已关联', c: 'blue' },
  ];
  if (w.docs.bf) docs.push({ no: w.docs.bf, t: '倒冲单', s: '已倒冲', c: 'orange' });
  if (w.reversed) docs.push({ no: w.docs.cx || 'CX', t: '冲销单', s: '已冲销', c: 'red' });
  return docs.map(d => `<div class="doc-chip"><div class="dc-top"><span class="dc-no">${d.no}</span>${badge(d.c, d.t)}</div><div class="dc-st">${d.s}</div></div>`).join('');
}
function wiOpen(id) { wiCurrent = id; rerender(); }
function wiFinish() {
  const w = wiFind(wiCurrent); if (!w) return;
  const remain = w.planQty - w.finishedQty;
  if (remain <= 0) { toast('本工单已全部倒冲'); return; }
  const qty = parseInt(document.getElementById('wi-finish').value, 10) || 0;
  if (qty <= 0 || qty > remain) { toast('本次完工数量需在 1~' + remain + ' 之间'); return; }
  const decSummary = w.bom.map(it => `${it.spec} −${qty * it.perUnit}`).join('、');
  confirmDialog('确认完工入库倒冲', `将按 BOM 对「${productName(w.product)}」完工 ${qty} 台执行倒冲，扣减工厂可用库存：<br><b>${decSummary}</b><br><br>该操作为库存减少动作，将生成倒冲单与反向流水。是否继续？`, () => {
    w.finishedQty += qty;
    w.status = w.finishedQty >= w.planQty ? '已倒冲' : '部分倒冲';
    const doc = 'BF-2608' + String(wiList.length + 1).padStart(2, '0');
    w.docs.bf = doc;
    const totalDec = w.bom.reduce((a, it) => a + qty * it.perUnit, 0);
    w.events.push({ doc, biz: '完工入库倒冲 (按BOM)', spec: '多规格', dept: '仓库', qty: -totalDec, dir: '-', status: '已倒冲', time: nowHM(), owner: '李娜' });
    toast('已生成倒冲单 ' + doc + '：工厂可用库存 −' + totalDec);
    rerender();
  });
}
function wiReverse() {
  const w = wiFind(wiCurrent); if (!w) return;
  if (w.finishedQty === 0) { toast('无已完成倒冲可冲销'); return; }
  if (w.reversed) { toast('本工单已冲销，不可重复冲销'); return; }
  const totalDec = w.bom.reduce((a, it) => a + w.finishedQty * it.perUnit, 0);
  confirmDialog('确认完工冲销', `将回退本工单倒冲结果，工厂可用库存恢复 +${totalDec} 个（${w.bom.map(it => it.spec + ' +' + w.finishedQty * it.perUnit).join('、')}）。是否继续？`, () => {
    w.reversed = true;
    const doc = 'CX-' + w.id.replace('WO-', '');
    w.docs.cx = doc;
    w.events.push({ doc, biz: '完工入库冲销 (反向流水，恢复库存)', spec: '多规格', dept: '仓库', qty: totalDec, dir: '+', status: '已冲销', time: nowHM(), owner: '李娜' });
    toast('已生成冲销单 ' + doc + '：工厂可用库存恢复 +' + totalDec);
    rerender();
  });
}
function wiNew() {
  const products = DATA.products.map(p => `<option value="${p.code}">${p.code} ${p.name}</option>`).join('');
  const customers = ['华东家电渠道', '华南数码连锁', '华北工贸', '西南电器'];
  const body = `
    <div class="field"><label>生产工单号<span class="req">*</span></label><input id="wi-wo" placeholder="WO-2026xxxx"></div>
    <div class="field"><label>产品<span class="req">*</span></label><select id="wi-prod">${products}</select></div>
    <div class="field"><label>客户<span class="req">*</span></label><select id="wi-cust">${customers.map(c => `<option>${c}</option>`).join('')}</select></div>
    <div class="field"><label>计划完工数量<span class="req">*</span></label><input id="wi-qty" type="number" value="300"></div>`;
  openModal('新建生产工单', body, () => {
    const wo = document.getElementById('wi-wo').value.trim();
    const prod = document.getElementById('wi-prod').value;
    const cust = document.getElementById('wi-cust').value;
    const qty = parseInt(document.getElementById('wi-qty').value, 10) || 0;
    if (!wo || !qty) { toast('请填写工单号与计划数量'); return; }
    const p = DATA.products.find(x => x.code === prod);
    const rec = {
      id: wo, mo: 'MO-' + wo.replace('WO-', ''), product: prod, customer: cust,
      planQty: qty, finishedQty: 0, status: '草稿', reversed: false, docs: {},
      bom: p.specs.map(s => ({ spec: s.code, perUnit: s.qty, role: '主料' })),
      events: [{ doc: wo, biz: '获取有效生产工单 (MES)', spec: '—', dept: '计划', qty: 0, dir: '+', status: '有效', time: nowHM(), owner: '王磊' }],
    };
    wiList.unshift(rec); wiCurrent = wo;
    toast('已创建生产工单 ' + wo + '（' + p.name + ' ×' + qty + '）');
    rerender();
  });
}
function wiReset() { wiList = JSON.parse(JSON.stringify(DATA.backflushSeed)); wiCurrent = wiList[0].id; toast('数据已重置'); rerender(); }

/* ============================ 4.4.3 客户返程（功能页） ============================ */
let crList = JSON.parse(JSON.stringify(DATA.custReturnSeed));
let crCurrent = crList[0].id;
const crFind = id => crList.find(x => x.id === id);
const crStatusColor = s => s === '已完成' ? 'green' : s === '返回在途' ? 'purple' : 'gray';

function viewCustReturn() {
  const c = crFind(crCurrent) || crList[0];
  const returned = c.dispatched ? c.qty : 0;
  return `
  <div class="page-head"><div><h1 class="page-title">客户返程</h1><div class="page-desc">对照一期 4.4.3：业务人员创建返程登记 → 确认发运形成【返回在途，禁止重复发运】 → 返厂到货验收（良品/破损/短少）→ 合格入工厂可用、破损入待处理、短少生成差异 → 完成后不可直接修改，通过冲销/更正处理。字段含物流商、运单、发运/到达时间、验收人与原因，支持异常闭环。</div></div>
    <div class="row-flex"><button class="btn primary" onclick="crNew()">＋ 新建返程登记</button><button class="btn" onclick="crReset()">重置数据</button></div>
  </div>

  <div class="split">
    <div class="card" style="flex:1.1">
      <div class="card-head"><h3>返程登记单列表</h3><span class="sub">业务人员登记 · 物流发运</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>返程单</th><th>客户</th><th>物料</th><th class="num">数量</th><th>状态</th><th></th></tr></thead>
        <tbody>${crList.map(x => `<tr class="${x.id === crCurrent ? 'row-active' : ''}" style="cursor:pointer" onclick="crOpen('${x.id}')"><td><b>${x.id}</b></td><td>${x.customer}</td><td>${x.spec}</td><td class="num">${fmt(x.qty)}</td><td>${badge(crStatusColor(x.status), x.status)}</td><td><button class="btn sm" onclick="event.stopPropagation();crOpen('${x.id}')">处理</button></td></tr>`).join('')}</tbody>
      </table></div>
    </div>
    <div class="card" style="flex:1.4">
      <div class="card-head"><h3>当前返程单 · ${c.id}</h3><span class="sub">${c.customer} · ${c.spec} · ETA ${c.eta} · ${badge(crStatusColor(c.status), c.status)}</span></div>
      <div class="stepper">
        <div class="step done"><div class="dot">1</div><div class="st-t">创建返程登记</div><div class="st-s">业务人员</div></div>
        <div class="step ${c.dispatched ? 'done' : ''}"><div class="dot">2</div><div class="st-t">确认发运</div><div class="st-s">${c.dispatched ? '返回在途' : '禁止重复发运'}</div></div>
        <div class="step ${c.arrived ? 'done' : ''}"><div class="dot">3</div><div class="st-t">返厂到货+验收</div><div class="st-s">${c.arrived ? '验收完成' : '待到货'}</div></div>
        <div class="step ${c.arrived ? 'done' : ''}"><div class="dot">4</div><div class="st-t">良品/破损/短少分流</div><div class="st-s">${c.arrived ? '已分流' : '待处理'}</div></div>
        <div class="step ${c.reversed ? 'done' : ''}"><div class="dot">5</div><div class="st-t">冲销/更正</div><div class="st-s">不可直接修改</div></div>
      </div>
      <div class="kpi-inline" style="margin-top:12px">
        <div class="k">返回在途<b>${fmt(returned)} 个</b></div>
        <div class="k" style="color:var(--text-3)">⇄</div>
        <div class="k">工厂可用(返程)<b>${fmt(1240 + c.good)} 个</b></div>
      </div>
      ${c.arrived ? `<div class="muted" style="margin-top:10px">本次验收：合格 ${fmt(c.good)} / 破损 ${fmt(c.bad)} / 短少 ${fmt(c.short)}。</div>` : ''}
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>返程单完整字段</h3><span class="sub">物流 / 时间 / 验收与差异原因</span></div>
    <div class="detail-grid" style="grid-template-columns:repeat(3,1fr)">
      <div><label>物流商</label><b>${c.carrier || '—'}</b></div>
      <div><label>运单号</label><b>${c.waybill || '—'}</b></div>
      <div><label>发出部门 → 接收仓库</label><b>${c.fromDept} → ${c.toWh}</b></div>
      <div><label>计划发运时间</label><b>${c.planShip || '—'}</b></div>
      <div><label>实际发运时间</label><b>${c.actShip || '—'}</b></div>
      <div><label>预计到达 → 实际到达</label><b>${c.eta}${c.actArr ? ' → ' + c.actArr : ''}</b></div>
      ${c.arrived ? `
      <div><label>验收人</label><b>${c.acceptBy || '—'}</b></div>
      <div><label>验收时间</label><b>${c.acceptTime || '—'}</b></div>
      <div><label>良品/破损/短少原因</label><b>${c.goodReason || '—'} / ${c.badReason || '—'} / ${c.shortReason || '—'}</b></div>` : ''}
    </div>
  </div>

  ${c.dispatched && !c.arrived ? `
  <div class="card">
    <div class="card-head"><h3>返厂到货验收</h3><span class="sub">合格 + 破损 + 短少 须等于返程数量 ${fmt(c.qty)}</span></div>
    <div class="row-flex" style="align-items:flex-end;gap:14px;flex-wrap:wrap">
      <div class="field" style="min-width:150px"><label>合格 → 工厂可用</label><input id="cr-good" type="number" value="${c.qty - 20}"></div>
      <div class="field" style="min-width:150px"><label>破损 → 待处理</label><input id="cr-bad" type="number" value="14"></div>
      <div class="field" style="min-width:150px"><label>短少 → 差异</label><input id="cr-short" type="number" value="6"></div>
      <div class="field" style="min-width:150px"><label>良品原因</label><input id="cr-gr" value="外观完好"></div>
      <div class="field" style="min-width:150px"><label>破损原因</label><input id="cr-br" value="运输挤压变形"></div>
      <div class="field" style="min-width:150px"><label>短少原因</label><input id="cr-sr" value="交接清点差异"></div>
      <div class="field" style="min-width:140px"><label>验收人</label><input id="cr-accept" value="孙伟"></div>
      <button class="btn primary" onclick="crAccept()">确认验收并分流</button>
    </div>
  </div>` : ''}

  <div class="card">
    <div class="card-head"><h3>关联单据</h3><span class="sub">本返程单生成的所有业务单据</span></div>
    <div class="doc-row">${crDocs(c)}</div>
  </div>

  <div class="card">
    <div class="card-head"><h3>返程事件流水（含反向流水）</h3>
      <div class="row-flex">
        <button class="btn primary" ${c.dispatched ? 'disabled title="已发运，禁止重复发运"' : ''} onclick="crDispatch()">确认发运</button>
        <button class="btn danger" ${c.arrived && !c.reversed ? '' : 'disabled title="须到货验收且未冲销方可冲销"'} onclick="crReverse()">${c.reversed ? '已冲销' : '发起冲销/更正'}</button>
      </div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>单据/事件</th><th>业务环节</th><th>物料</th><th>部门</th><th class="num">数量</th><th>方向</th><th>状态</th><th>时间</th><th>责任人</th></tr></thead>
      <tbody>${c.events.slice().reverse().map(r => `<tr class="${r.dir === '-' ? 'rev' : ''}"><td>${r.doc}</td><td>${r.biz}</td><td>${r.spec}</td><td>${r.dept}</td><td class="num" style="${r.dir === '-' ? 'color:var(--danger);font-weight:600' : ''}">${r.dir === '+' ? '+' : ''}${fmt(r.qty)}</td><td>${r.dir === '+' ? badge('green', '▴ 正向') : badge('red', '▾ 反向')}</td><td>${badge(r.dir === '-' ? 'red' : 'green', r.status)}</td><td>${r.time}</td><td>${r.owner}</td></tr>`).join('')}</tbody>
    </table></div>
    <div class="muted" style="margin-top:10px">${c.reversed ? '本返程单已冲销，不可重复冲销；调整请通过新开冲销/更正单。' : (c.arrived ? '返程单已完成，不可直接修改；调整请通过"冲销/更正"以反向流水处理。' : (c.dispatched ? '返程单返回在途中，可到货验收。' : '返程单草稿，可确认发运。'))}</div>
  </div>`;
}
function crDocs(c) {
  const docs = [{ no: c.id, t: '返程登记单', s: '草稿', c: 'blue' }];
  if (c.docs.ship) docs.push({ no: c.docs.ship, t: '发运单', s: '返回在途', c: 'purple' });
  if (c.docs.accept) docs.push({ no: c.docs.accept, t: '到货验收单', s: '工厂可用', c: 'green' });
  if (c.docs.diff) docs.push({ no: c.docs.diff, t: '差异记录单', s: '差异', c: 'red' });
  if (c.docs.cx) docs.push({ no: c.docs.cx, t: '冲销/更正单', s: '已冲销', c: 'red' });
  return docs.map(d => `<div class="doc-chip"><div class="dc-top"><span class="dc-no">${d.no}</span>${badge(d.c, d.t)}</div><div class="dc-st">${d.s}</div></div>`).join('');
}
function crOpen(id) { crCurrent = id; rerender(); }
function crDispatch() {
  const c = crFind(crCurrent); if (!c) return;
  if (c.dispatched) { toast('已发运，禁止重复发运'); return; }
  confirmDialog('确认发运', `将生成发运单 <b>SH-${c.id.replace('RR-', '')}</b>，登记 ${fmt(c.qty)} 个「${c.spec}」进入<b>返回在途</b>。发运后本单锁定，<b>禁止重复发运</b>。是否继续？`, () => {
    c.dispatched = true; c.status = '返回在途'; c.actShip = nowHM();
    const doc = 'SH-' + c.id.replace('RR-', '');
    c.docs.ship = doc;
    c.events.push({ doc, biz: '确认发运 → 形成返回在途', spec: c.spec, dept: '物流', qty: c.qty, dir: '+', status: '返回在途', time: nowHM(), owner: '赵强' });
    toast('已生成发运单 ' + doc + '：' + c.qty + ' 个返回在途（已锁定，禁止重复发运）');
    rerender();
  });
}
function crAccept() {
  const c = crFind(crCurrent); if (!c) return;
  if (!c.dispatched) { toast('请先确认发运'); return; }
  if (c.arrived) { toast('已验收，不可直接修改'); return; }
  const good = parseInt(document.getElementById('cr-good').value, 10) || 0;
  const bad = parseInt(document.getElementById('cr-bad').value, 10) || 0;
  const short = parseInt(document.getElementById('cr-short').value, 10) || 0;
  if (good + bad + short !== c.qty) { toast('合格+破损+短少=' + (good + bad + short) + '，应等于 ' + c.qty); return; }
  c.good = good; c.bad = bad; c.short = short; c.arrived = true; c.status = '已完成';
  c.goodReason = document.getElementById('cr-gr').value; c.badReason = document.getElementById('cr-br').value; c.shortReason = document.getElementById('cr-sr').value;
  c.acceptBy = document.getElementById('cr-accept').value; c.acceptTime = nowHM(); c.actArr = nowHM();
  const acc = 'ACC-' + c.id.replace('RR-', '');
  const t = nowHM();
  c.docs.accept = acc;
  c.events.push({ doc: acc, biz: '到货验收 · 合格入工厂可用', spec: c.spec, dept: '质量', qty: good, dir: '+', status: '工厂可用', time: t, owner: c.acceptBy });
  if (bad > 0) c.events.push({ doc: 'BAD-' + c.id.replace('RR-', ''), biz: '到货验收 · 破损入待处理 (' + c.badReason + ')', spec: c.spec, dept: '质量', qty: bad, dir: '+', status: '待处理', time: t, owner: c.acceptBy });
  if (short > 0) { const dif = 'DIF-' + c.id.replace('RR-', ''); c.docs.diff = dif; c.events.push({ doc: dif, biz: '短少生成差异记录 (' + c.shortReason + ')', spec: c.spec, dept: '物流', qty: short, dir: '+', status: '差异', time: t, owner: '赵强' }); }
  toast('验收完成：合格 ' + good + ' / 破损 ' + bad + ' / 短少 ' + short);
  rerender();
}
function crReverse() {
  const c = crFind(crCurrent); if (!c) return;
  if (!c.arrived) { toast('返程单未完成，无法冲销'); return; }
  if (c.reversed) { toast('本返程单已冲销，不可重复冲销'); return; }
  confirmDialog('确认冲销/更正', `将生成冲销/更正单，回退工厂可用库存 <b>+${fmt(c.good)}</b> 个（关联原单 ${c.docs.accept || c.id}）。冲销后本单进入"已冲销"，<b>不可再次冲销</b>。是否继续？`, () => {
    const qty = -c.good; c.good = 0; c.reversed = true;
    const doc = 'CX-' + c.id.replace('RR-', ''); c.docs.cx = doc;
    c.events.push({ doc, biz: '冲销/更正 (反向流水)', spec: c.spec, dept: '质量', qty, dir: '-', status: '已冲销', time: nowHM(), owner: '孙伟' });
    toast('已生成冲销/更正单 ' + doc + '：工厂可用回退 ' + qty);
    rerender();
  });
}
function crNew() {
  const customers = ['华东家电渠道', '华南数码连锁', '华北工贸', '西南电器'];
  const specs = DATA.specs.map(s => `<option value="${s.code}">${s.code} ${s.name}</option>`).join('');
  const body = `
    <div class="field"><label>客户<span class="req">*</span></label><select id="cr-cust">${customers.map(c => `<option>${c}</option>`).join('')}</select></div>
    <div class="field"><label>物料规格<span class="req">*</span></label><select id="cr-spec">${specs}</select></div>
    <div class="field"><label>登记数量<span class="req">*</span></label><input id="cr-qty" type="number" value="300"></div>
    <div class="field"><label>预计到货日期</label><input id="cr-eta" value="2026-08-08"></div>
    <div class="field"><label>物流商</label><input id="cr-carrier" placeholder="如 顺达物流"></div>
    <div class="field"><label>运单号</label><input id="cr-waybill" placeholder="如 SF-xxxx"></div>
    <div class="field"><label>发出部门</label><input id="cr-fd" value="物流部"></div>
    <div class="field"><label>接收仓库</label><input id="cr-tw" value="五产仓库"></div>`;
  openModal('新建返程登记', body, () => {
    const cust = document.getElementById('cr-cust').value;
    const spec = document.getElementById('cr-spec').value;
    const qty = parseInt(document.getElementById('cr-qty').value, 10) || 0;
    const eta = document.getElementById('cr-eta').value;
    if (!qty) { toast('请填写登记数量'); return; }
    const id = 'RR-' + String(crList.length + 1).padStart(4, '0');
    const rec = { id, customer: cust, spec, qty, eta, status: '草稿', dispatched: false, arrived: false, good: 0, bad: 0, short: 0,
      carrier: document.getElementById('cr-carrier').value, waybill: document.getElementById('cr-waybill').value,
      fromDept: document.getElementById('cr-fd').value, toWh: document.getElementById('cr-tw').value,
      planShip: '', actShip: '', actArr: '', goodReason: '', badReason: '', shortReason: '', acceptBy: '', acceptTime: '', cxReason: '', reversed: false,
      docs: {}, events: [
      { doc: id, biz: '创建返程登记 (业务人员)', spec, dept: '物流', qty, dir: '+', status: '草稿', time: nowHM(), owner: '赵强' },
    ] };
    crList.unshift(rec); crCurrent = id;
    toast('已创建返程登记单 ' + id + '（草稿）');
    rerender();
  });
}
function crReset() { crList = JSON.parse(JSON.stringify(DATA.custReturnSeed)); crCurrent = crList[0].id; toast('数据已重置'); rerender(); }

function rerender() { const v = VIEWS[currentView]; if (!v) return; $('#content').innerHTML = v.render(); if (v.init) v.init(); }

/* ---------- 库存溯源台账（镜像流水） ---------- */
// 每个库存数字都需可溯源至：来源单据 / 物料 / 部门 / 数量 / 状态 / 时间 / 责任人
const STAGE_DEPT = { supplier: '采购', wip_in: '仓库', wip: '仓库', transit: '物流', cust_stock: '客户对接', cust_use: '客户对接', cust_recycle: '客户对接', return: '物流', loss: '质量' };

function buildLedger() {
  const fromFlow = DATA.flowRecords.map(r => ({
    doc: r.doc, biz: r.type, spec: r.spec, dept: r.dept, qty: r.qty, status: r.status, time: r.time, owner: r.op,
  }));
  const fromLoss = DATA.lossRecords.map(r => ({
    doc: r.id, biz: '损耗报废(' + r.node + ')', spec: r.spec, dept: r.dept, qty: r.qty, status: r.status, time: r.time, owner: r.owner,
  }));
  return [...fromFlow, ...fromLoss].sort((a, b) => (b.time > a.time ? 1 : (b.time < a.time ? -1 : 0)));
}
let pendingLedgerFilter = null;
function openLedger(filter) { pendingLedgerFilter = filter || null; navigate('ledger'); }

/* ---------- 工具函数 ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
function fmt(n) { return Number(n).toLocaleString('en-US'); }
function badge(cls, txt) { return `<span class="badge ${cls}">${txt}</span>`; }
function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function productName(code) { const p = DATA.products.find(x => x.code === code); return p ? p.name : code; }
function specName(code) { const s = DATA.specs.find(x => x.code === code); return s ? `${s.code} ${s.name}` : code; }

/* ---------- SVG 图表 ---------- */
function donutChart(el, segments, centerText) {
  const size = 180, r = 70, cx = size / 2, cy = size / 2, sw = 22;
  const total = segments.reduce((a, b) => a + b.value, 0) || 1;
  let ang = -Math.PI / 2;
  let paths = '';
  segments.forEach(seg => {
    const frac = seg.value / total;
    const a2 = ang + frac * Math.PI * 2;
    const large = frac > 0.5 ? 1 : 0;
    const x1 = cx + r * Math.cos(ang), y1 = cy + r * Math.sin(ang);
    const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
    paths += `<path d="M${x1} ${y1} A${r} ${r} 0 ${large} 1 ${x2} ${y2}" fill="none" stroke="${seg.color}" stroke-width="${sw}" stroke-linecap="butt"/>`;
    ang = a2;
  });
  const ct = centerText ? `<text x="${cx}" y="${cy - 2}" text-anchor="middle" font-size="22" font-weight="700" fill="var(--text)">${centerText.v}</text><text x="${cx}" y="${cy + 16}" text-anchor="middle" font-size="11" fill="var(--text-3)">${centerText.l}</text>` : '';
  el.innerHTML = `<svg class="chart-svg" viewBox="0 0 ${size} ${size}">${paths}${ct}</svg>`;
}

function barChart(el, items, opts = {}) {
  const W = 460, H = 220, pad = 30, gap = 14;
  const max = Math.max(...items.map(i => i.value), 1);
  const bw = (W - pad * 2 - gap * (items.length - 1)) / items.length;
  const colors = opts.colors || ['#165DFF'];
  let bars = '', labels = '';
  items.forEach((it, i) => {
    const h = (it.value / max) * (H - pad * 2);
    const x = pad + i * (bw + gap);
    const y = H - pad - h;
    const c = Array.isArray(colors) ? (colors[i % colors.length] || '#165DFF') : colors;
    bars += `<rect x="${x}" y="${y}" width="${bw}" height="${h}" rx="4" fill="${c}"><title>${it.label}: ${it.value}</title></rect>`;
    bars += `<text x="${x + bw / 2}" y="${y - 5}" text-anchor="middle" font-size="11" fill="var(--text-2)">${it.value}</text>`;
    labels += `<text x="${x + bw / 2}" y="${H - 8}" text-anchor="middle" font-size="11" fill="var(--text-3)">${it.label}</text>`;
  });
  el.innerHTML = `<svg class="chart-svg" viewBox="0 0 ${W} ${H}"><line x1="${pad}" y1="${H - pad}" x2="${W - pad}" y2="${H - pad}" stroke="var(--border)"/>${bars}${labels}</svg>`;
}

function lineChart(el, series, labels) {
  const W = 480, H = 220, pad = 34;
  const all = series.flatMap(s => s.data);
  const max = Math.max(...all, 1) * 1.1;
  const min = Math.min(...all, 0);
  const span = (max - min) || 1;
  const xw = (W - pad * 2) / (labels.length - 1);
  const yOf = v => H - pad - ((v - min) / span) * (H - pad * 2);
  const xOf = i => pad + i * xw;
  let grid = '', xlab = '';
  for (let g = 0; g <= 4; g++) {
    const y = pad + g * (H - pad * 2) / 4;
    grid += `<line x1="${pad}" y1="${y}" x2="${W - pad}" y2="${y}" stroke="var(--border-2)"/>`;
  }
  labels.forEach((l, i) => { xlab += `<text x="${xOf(i)}" y="${H - 10}" text-anchor="middle" font-size="10" fill="var(--text-3)">${l}</text>`; });
  let paths = '';
  series.forEach(s => {
    const pts = s.data.map((v, i) => `${xOf(i)},${yOf(v)}`).join(' ');
    paths += `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.5"/>`;
    s.data.forEach((v, i) => { paths += `<circle cx="${xOf(i)}" cy="${yOf(v)}" r="3" fill="${s.color}"/>`; });
  });
  el.innerHTML = `<svg class="chart-svg" viewBox="0 0 ${W} ${H}">${grid}${paths}${xlab}</svg>`;
}

function hBarChart(el, items) {
  const W = 420, rowH = 34, barX = 100, max = Math.max(...items.map(i => i.value), 1);
  const H = items.length * rowH + 20;
  let rows = '';
  items.forEach((it, i) => {
    const y = 10 + i * rowH;
    const w = (it.value / max) * (W - barX - 40);
    rows += `<text x="${barX - 10}" y="${y + rowH / 2}" text-anchor="end" font-size="12" fill="var(--text-2)">${it.label}</text>`;
    rows += `<rect x="${barX}" y="${y + 4}" height="${rowH - 14}" width="${w}" rx="4" fill="${it.color || '#165DFF'}"/>`;
    rows += `<text x="${barX + w + 6}" y="${y + rowH / 2}" font-size="12" fill="var(--text-2)">${it.value}</text>`;
  });
  el.innerHTML = `<svg class="chart-svg" viewBox="0 0 ${W} ${H}">${rows}</svg>`;
}

/* ---------- 路由 / 视图 ---------- */
const VIEWS = {
  dashboard: { title: '工作台', group: '总览', phase: '总览', icon: ICON.dashboard, render: viewDashboard, init: initDashboard },
  inventory: { title: '全链路库存可视化', group: '库存与流转', phase: '一期', icon: ICON.inventory, render: viewInventory, init: initInventory },
  bom: { title: 'BOM物料管理', group: '需求与计划', phase: '一期', icon: ICON.bom, render: viewBom, init: initBom },
  order: { title: '订单需求核算', group: '需求与计划', phase: '一期', icon: ICON.calc, render: viewOrder, init: initOrder },
  flow: { title: '全生命周期流转蓝图', group: '库存与流转', phase: '一期·蓝图', icon: ICON.flow, render: viewFlow, init: initFlow },
  loss: { title: '损耗管理', group: '库存与流转', phase: '一期', icon: ICON.loss, render: viewLoss, init: initLoss },
  ledger: { title: '库存溯源台账', group: '库存与流转', phase: '一期', icon: ICON.ledger, render: viewLedger, init: initLedger },
  poInbound: { title: '供应商来料', group: '库存与流转', phase: '一期', icon: ICON.inbound, render: viewPoInbound, init: null },
  workIssue: { title: '完工入库倒冲规则', group: '库存与流转', phase: '待确认', icon: ICON.issue, render: viewWorkIssue, init: null },
  custReturn: { title: '客户返程', group: '库存与流转', phase: '一期', icon: ICON.ret, render: viewCustReturn, init: null },
  mrp: { title: '简易MRP与采购建议', group: '需求与计划', phase: '二期', icon: ICON.mrp, render: viewMrp, init: initMrp },
  analytics: { title: '数据统计分析', group: '分析与配置', phase: '二期', icon: ICON.chart, render: viewAnalytics, init: initAnalytics },
  specs: { title: '规格标准化管理', group: '分析与配置', phase: '一期', icon: ICON.spec, render: viewSpecs, init: initSpecs },
  roles: { title: '人员权责管理', group: '分析与配置', phase: '一期', icon: ICON.user, render: viewRoles, init: null },
  settings: { title: '系统设置 / 主数据', group: '分析与配置', phase: '一期', icon: ICON.settings, render: viewSettings, init: null },
};
const PHASE_CLASS = { '一期': 'green', '二期': 'blue', '待确认': 'orange', '规划中': 'purple', '总览': 'gray', '一期·蓝图': 'cyan' };
function phaseBadge(p) { return p ? `<span class="badge nav-phase ${PHASE_CLASS[p] || 'gray'}">${p}</span>` : ''; }

let currentView = 'dashboard';

function navigate(key) {
  if (!VIEWS[key]) return;
  currentView = key;
  const v = VIEWS[key];
  $('#content').innerHTML = v.render();
  const pt = $('#content .page-title');
  if (pt && v.phase) pt.insertAdjacentHTML('beforeend', ' ' + phaseBadge(v.phase));
  $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === key));
  $('.breadcrumb').innerHTML = `<span>${v.group}</span> / <b>${v.title}</b> ${phaseBadge(v.phase)}`;
  if (v.init) v.init();
  window.scrollTo(0, 0);
}

/* ============================ 视图：工作台 ============================ */
function viewDashboard() {
  const totalAvail = 1240 + 210;
  const inTransit = 150 + 230 + 120;
  const atCustomer = 980 + 760 + 140;
  return `
  <div class="proto-banner">
    <span>${ICON.flag}</span>
    <div><b>周转箱管理业务全景原型 V0.8</b> · 用于确认业务范围、数据来源与核心规则，<b>不作为最终开发验收依据</b>。左侧菜单与页面标题已标注所属阶段（一期 / 二期 / 待确认 / 规划中），正式需求口径以业务签字稿为准。所有数据为 Mock 演示数据。</div>
    <button class="close" onclick="this.parentNode.style.display='none'">×</button>
  </div>

  <div class="grid cols-4">
    <div class="stat" style="cursor:pointer" title="点击下钻至溯源台账" onclick="openLedger({dept:'仓库'})"><div class="label">五产可用库存</div><div class="value">${fmt(1240)}<small> 个</small></div><div class="trend up">▲ 较上周 +3.2%</div><div class="ico-bg ico-blue">${ICON.box}</div></div>
    <div class="stat" style="cursor:pointer" title="点击下钻至溯源台账" onclick="openLedger({dept:'物流'})"><div class="label">全链路在途</div><div class="value">${fmt(inTransit)}<small> 个</small></div><div class="trend up">▲ 在制+转运+返程</div><div class="ico-bg ico-purple">${ICON.truck}</div></div>
    <div class="stat" style="cursor:pointer" title="点击下钻至溯源台账" onclick="openLedger({dept:'客户对接'})"><div class="label">客户侧占用</div><div class="value">${fmt(atCustomer)}<small> 个</small></div><div class="trend down">▼ 待回收 140</div><div class="ico-bg ico-orange">${ICON.factory}</div></div>
    <div class="stat" style="cursor:pointer" title="点击下钻至溯源台账" onclick="openLedger({search:'损耗'})"><div class="label">累计损耗</div><div class="value">${fmt(158)}<small> 个</small></div><div class="trend down">损耗率 1.8%</div><div class="ico-bg ico-red">${ICON.warn}</div></div>
  </div>

  <div class="card">
    <div class="card-head"><h3>周转箱全生命周期流转全景</h3><span class="sub">供应商 → 五产 → 转运 → 客户 → 返程 → 复用</span></div>
    <div class="pipeline">
      ${DATA.stages.map((s, i) => `
        <div class="pipe-node">
          <div class="pn-title"><span class="pn-dot" style="background:var(--${STATE_COLOR[s.color]})"></span>${s.name}</div>
          <div class="pn-val">${fmt(s.items.reduce((a, b) => a + b[1], 0))}</div>
          <div class="pn-sub">${s.items.map(it => `${it[0]} ${it[1]}`).join(' · ')}</div>
          <div class="pn-sub" style="margin-top:6px">责任人：${s.owner}</div>
        </div>
        ${i < DATA.stages.length - 1 ? '<div class="pipe-arrow">→</div>' : ''}
      `).join('')}
    </div>
  </div>

  <div class="split">
    <div class="card">
      <div class="card-head"><h3>近10日库存与损耗趋势</h3><span class="sub">可用库存 / 在途 / 损耗</span></div>
      <div id="dash-trend"></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>库存状态构成</h3></div>
      <div id="dash-donut" style="text-align:center"></div>
      <div class="legend" style="margin-top:12px">
        <div class="li"><span class="sw" style="background:var(--success)"></span>可用库存<span class="lv">1240</span></div>
        <div class="li"><span class="sw" style="background:var(--cyan)"></span>闲置库存<span class="lv">210</span></div>
        <div class="li"><span class="sw" style="background:var(--warning)"></span>破损待处理<span class="lv">36</span></div>
        <div class="li"><span class="sw" style="background:var(--danger)"></span>累计损耗<span class="lv">158</span></div>
      </div>
    </div>
  </div>

  <div class="split">
    <div class="card">
      <div class="card-head"><h3>待办与预警</h3><span class="sub">来自各节点业务事件</span></div>
      <div class="timeline">
        <div class="tl-item"><div class="tl-time">08-05 09:12</div><div class="tl-text"><b>缺口预警：</b>订单 SO-20260804 缺 TBX-A1 共 320 个，建议发起采购。</div></div>
        <div class="tl-item"><div class="tl-time">08-04 16:05</div><div class="tl-text"><b>客户入库：</b>华东客户仓 TBX-A1 +400，状态更新为在库可用。</div></div>
        <div class="tl-item"><div class="tl-time">08-01 15:30</div><div class="tl-text"><b>损耗登记：</b>五产仓库 TBX-B2 运输破损 12 个，进入报废流程。</div></div>
        <div class="tl-item"><div class="tl-time">08-01 11:00</div><div class="tl-text"><b>返程核验：</b>RET-260801-05 合格 480 入库循环复用，破损 6 留痕。</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><h3>规格使用率 TOP</h3></div>
      <div id="dash-specs"></div>
    </div>
  </div>`;
}
function initDashboard() {
  lineChart($('#dash-trend'), [
    { name: '可用库存', color: '#00b42a', data: [1180, 1195, 1210, 1205, 1220, 1235, 1228, 1240, 1236, 1240] },
    { name: '在途', color: '#722ed1', data: [460, 472, 451, 468, 455, 449, 460, 452, 458, 500] },
    { name: '损耗', color: '#f53f3f', data: [2, 5, 3, 8, 4, 6, 5, 12, 3, 6] },
  ], ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10']);
  donutChart($('#dash-donut'), [
    { value: 1240, color: 'var(--success)' }, { value: 210, color: 'var(--cyan)' },
    { value: 36, color: 'var(--warning)' }, { value: 158, color: 'var(--danger)' },
  ], { v: '1644', l: '五产总持有' });
  hBarChart($('#dash-specs'), DATA.specs.slice(0, 5).map(s => ({ label: s.code, value: s.usage, color: 'var(--brand)' })));
}

/* ============================ 视图：全链路库存 ============================ */
function viewInventory() {
  return `
  <div class="page-head"><div><h1 class="page-title">全链路库存可视化</h1><div class="page-desc">覆盖供应商在制/在途、五产库存、转运在途、客户仓库/在用/待回收、返程在途、损耗报废等全节点数量、状态、责任人实时管控。</div></div>
    <div class="row-flex"><button class="btn" onclick="toast('已刷新全链路库存数据')">${ICON.refresh} 刷新</button><button class="btn" onclick="toast('导出功能在正式版提供')">导出</button></div>
  </div>
  <div class="card"><div class="card-head"><h3>各流转节点库存卡</h3><span class="sub">点击卡片查看明细（演示）</span></div>
    <div class="node-grid">
      ${DATA.stages.map(s => `
        <div class="node-card" onclick="openLedger({dept: STAGE_DEPT['${s.key}']})" style="cursor:pointer" title="点击下钻至溯源台账">
          <div class="nc-head"><span class="nc-stage">${s.name}</span>${badge(s.color, '实时')}</div>
          <div class="nc-qty">${fmt(s.items.reduce((a, b) => a + b[1], 0))}<span style="font-size:13px;color:var(--text-3)"> 个</span></div>
          <div class="nc-rows">${s.items.map(it => `<div><span>${it[0]}</span><b>${it[1]}</b></div>`).join('')}
            <div style="border-top:1px dashed var(--border);margin-top:6px;padding-top:6px"><span class="muted">责任人</span><b>${s.owner}</b></div>
          </div>
        </div>`).join('')}
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h3>四类候选供应（一期数据底座口径）</h3><span class="sub">现有库存 / 采购在途 / 发料未发货 / 客户端返回在途</span></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>供应类别</th><th>来源系统/单据</th><th>数量</th><th>状态口径</th><th>可用时点</th><th>责任人</th></tr></thead>
      <tbody>
        <tr><td>现有库存</td><td>WMS / 五产库存</td><td class="num">1240</td><td>${badge('green', '可用')}</td><td>实时</td><td>李娜</td></tr>
        <tr><td>采购在途</td><td>ERP 有效PO</td><td class="num">150</td><td>${badge('blue', '在途')}</td><td>预计到货后</td><td>王磊</td></tr>
        <tr><td>发料未发货</td><td>MES 工单发料</td><td class="num">320</td><td>${badge('cyan', '已发料')}</td><td>绑定工单</td><td>生产</td></tr>
        <tr><td>客户端返回在途</td><td>返程登记单</td><td class="num">120</td><td>${badge('purple', '返程在途')}</td><td>到厂核验后</td><td>赵强</td></tr>
      </tbody>
    </table></div>
  </div>`;
}
function initInventory() {}

/* ============================ 视图：BOM物料 ============================ */
function viewBom() {
  return `
  <div class="page-head"><div><h1 class="page-title">BOM物料管理</h1><div class="page-desc">将各类规格周转箱录入产品 BOM，绑定产品与订单类型，维护标配数量与规格要求，系统据订单自动匹配生成需求计划。</div></div>
    <button class="btn primary" onclick="openBomModal()">${ICON.plus} 新增BOM</button>
  </div>
  <div class="card">
    <div class="filter-bar">
      <div class="field"><input placeholder="搜索产品编码/名称"></div>
      <div class="field"><select><option>全部状态</option><option>启用</option><option>停用</option></select></div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>产品编码</th><th>产品名称</th><th>关联周转箱配置</th><th>标配合计</th><th>状态</th><th>操作</th></tr></thead>
      <tbody>
        ${DATA.products.map(p => `
          <tr><td>${p.code}</td><td>${esc(p.name)}</td>
          <td>${p.specs.map(s => `${specName(s.code)} ×${s.qty}`).join('；<br>')}</td>
          <td class="num">${p.specs.reduce((a, b) => a + b.qty, 0)}</td>
          <td>${badge('green', '启用')}</td>
          <td><span class="link" onclick="toast('查看 ${p.code} BOM 明细')">明细</span> · <span class="link" onclick="openBomModal('${p.code}')">编辑</span></td></tr>
        `).join('')}
      </tbody>
    </table></div>
  </div>`;
}
function initBom() {}
function openBomModal(code) {
  const p = code ? DATA.products.find(x => x.code === code) : null;
  openModal('BOM配置' + (p ? ` · ${p.code}` : ' · 新增'), `
    <div class="form-grid">
      <div class="field"><label>产品编码<span class="req">*</span></label><input value="${p ? p.code : 'P-'}"></div>
      <div class="field"><label>产品名称<span class="req">*</span></label><input value="${p ? esc(p.name) : ''}"></div>
      <div class="field"><label>订单类型</label><select><option>销售发货订单</option><option>生产工单</option></select></div>
      <div class="field"><label>状态</label><select><option>启用</option><option>停用</option></select></div>
    </div>
    <div class="field"><label>周转箱配置（规格 / 数量）</label>
      <div id="bom-rows">
        ${(p ? p.specs : [{ code: 'TBX-A1', qty: 1 }]).map(s => `
          <div class="row-flex" style="margin-bottom:8px">
            <select style="max-width:220px">${DATA.specs.map(x => `<option ${x.code === s.code ? 'selected' : ''}>${x.code} ${x.name}</option>`).join('')}</select>
            <input style="max-width:90px" type="number" value="${s.qty}">
            <button class="btn sm" onclick="this.parentNode.remove()">删除</button>
          </div>`).join('')}
      </div>
      <button class="btn sm" onclick="toast('演示：已追加一行配置')">+ 追加规格</button>
    </div>
  `, () => toast('演示：BOM已保存（未写入后端）'));
}

/* ============================ 视图：订单需求核算 ============================ */
function viewOrder() {
  const opts = DATA.orders.map(o => `<option value="${o.id}">${o.id} · ${o.customer}</option>`).join('');
  return `
  <div class="page-head"><div><h1 class="page-title">订单需求核算</h1><div class="page-desc">职责边界：本页仅做<b>单张订单的 BOM 毛需求预览</b>——按产品 BOM 展开"订单需要多少周转箱"。<b>不直接生成采购短缺</b>，最终短缺由简易MRP按"部门+物料+日期"统一汇总计算，避免同一供应被多张订单重复占用。</div></div></div>
  <div class="card">
    <div class="card-head"><h3>选择订单 · 展开 BOM 毛需求</h3><span class="sub">仅预览，不触发采购</span></div>
    <div class="filter-bar">
      <div class="field" style="flex:1;min-width:280px"><label>选择订单</label><select id="order-sel" onchange="calcOrder()">${opts}</select></div>
      <div class="field"><label>&nbsp;</label><button class="btn primary" onclick="calcOrder()">${ICON.calc} 核算需求</button></div>
    </div>
    <div id="order-result"></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>订单需求列表</h3><span class="sub">状态含缺口预警（预警来自MRP，非本页计算）</span></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>订单号</th><th>客户</th><th>产品</th><th>数量</th><th>状态</th><th>操作</th></tr></thead>
      <tbody>
        ${DATA.orders.map(o => `<tr><td>${o.id}</td><td>${o.customer}</td><td>${productName(o.product)}</td><td class="num">${fmt(o.qty)}</td><td>${statusBadge(o.status)}</td><td><span class="link" onclick="document.getElementById('order-sel').value='${o.id}';calcOrder()">核算</span></td></tr>`).join('')}
      </tbody>
    </table></div>
    <div class="muted" style="margin-top:10px">提示：同一张 BOM 物料的可用供应须由 MRP 按日期统一分配，本页不把全节点供应合计重复套用到多个物料。如需计算短缺并生成采购建议，请前往「简易MRP与采购建议」。</div>
  </div>`;
}
function statusBadge(st) {
  if (st === '缺口预警') return badge('red', st);
  if (st === '已生成需求') return badge('green', st);
  return badge('orange', st);
}
function initOrder() { calcOrder(); }
function calcOrder() {
  const id = $('#order-sel').value;
  const o = DATA.orders.find(x => x.id === id);
  const p = DATA.products.find(x => x.code === o.product);
  let rows = '', total = 0;
  p.specs.forEach(s => {
    const gross = o.qty * s.qty;
    total += gross;
    rows += `<tr><td>${specName(s.code)}</td><td class="num">×${s.qty}</td><td class="num">${fmt(o.qty)}</td><td class="num">${fmt(gross)}</td>
      <td>${badge('blue', '毛需求')}</td>
      <td><span class="link" onclick="navigate('mrp')">交由 MRP 计算 →</span></td></tr>`;
  });
  $('#order-result').innerHTML = `
    <div class="row-flex" style="margin-bottom:12px">
      <span class="badge plain gray">订单 ${o.id}</span>
      <span class="badge plain gray">${o.customer}</span>
      <span class="badge plain gray">${productName(o.product)} × ${fmt(o.qty)}</span>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>周转箱规格 (物料)</th><th>单台用量</th><th>订单数量</th><th>毛需求</th><th>口径</th><th>下一步</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>
    <div class="divider"></div>
    <div class="kpi-inline">
      <div class="k"><b style="color:var(--brand)">${fmt(total)}</b>周转箱总毛需求</div>
      <div class="k"><b style="color:var(--text-2)">${p.specs.length}</b>种规格</div>
      <div class="k" style="color:var(--text-3)">短缺由 MRP 统一计算</div>
    </div>`;
}

/* ============================ 视图：流转操作 ============================ */
function viewFlow() {
  const tabs = [
    ['in', '供应商来料入库'], ['out', '转运顺达出库'], ['cin', '客户仓库入库'],
    ['use', '客户领用上线'], ['rec', '客户回收归集'], ['ret', '物流返程入库'], ['los', '损耗报废登记'],
  ];
  return `
  <div class="page-head"><div><h1 class="page-title">全生命周期流转蓝图</h1><div class="page-desc">本页为<b>只读蓝图</b>，用于展示周转箱全生命周期各环节与表单样式（供应商来料 → 转运 → 客户入库/领用/回收 → 返程 → 损耗）。<b>正式业务操作请在各专项页面完成</b>：供应商来料、客户返程、损耗管理、库存溯源台账。</div></div></div>
  <div class="card">
    <div class="banner-info"><span>${ICON.warn}</span><div>蓝图演示：下方表单为各环节登记样式示意，提交仅作演示提示，<b>不产生真实库存变动</b>。真实入库/出库/返程/损耗请在对应专项页操作并写入镜像台账。</div></div>
    <div class="tabs" id="flow-tabs">
      ${tabs.map((t, i) => `<div class="tab ${i === 0 ? 'active' : ''}" data-tab="${t[0]}" onclick="switchFlow('${t[0]}')">${t[1]}</div>`).join('')}
    </div>
    <div id="flow-body"></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>近期流转操作记录</h3><div class="row-flex"><span class="sub">全部操作绑定责任人，可审计</span><span class="link" onclick="openLedger()" style="margin-left:8px">查看完整溯源台账 →</span></div></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>单据号</th><th>操作类型</th><th>规格(物料)</th><th>部门</th><th>数量</th><th>来源 → 去向</th><th>操作员</th><th>时间</th><th>状态</th></tr></thead>
      <tbody>${DATA.flowRecords.map(r => `<tr><td><span class="link" onclick="openLedgerDetail('${r.doc}')">${r.doc}</span></td><td>${r.type}</td><td>${r.spec}</td><td>${r.dept}</td><td class="num">${fmt(r.qty)}</td><td>${r.from} → ${r.to}</td><td>${r.op}</td><td>${r.time}</td><td>${badge('green', r.status)}</td></tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}
function initFlow() { switchFlow('in'); }
const FLOW_FORMS = {
  in: { title: '供应商来料入库登记', fields: [['供应商', 'select:宏达包装|顺达塑胶|华锐模具'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code + ' ' + s.name).join('|')], ['到货数量', 'number'], ['批次号', 'text'], ['外观完好度', 'select:完好|轻微划痕|破损'], ['备注', 'textarea']], btn: '确认收货入库' },
  out: { title: '转运顺达出库申请', fields: [['发货订单', 'text'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['出库数量', 'number'], ['责任人', 'text'], ['物流单号', 'text']], btn: '提交审核出库' },
  cin: { title: '客户仓库入库登记', fields: [['客户', 'text'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['入库数量', 'number'], ['对接人', 'text']], btn: '确认入库' },
  use: { title: '客户领用上线登记', fields: [['客户', 'text'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['领用数量', 'number'], ['使用场景', 'text']], btn: '确认领用' },
  rec: { title: '客户回收归集登记', fields: [['客户', 'text'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['回收数量', 'number'], ['归集库位', 'text']], btn: '确认归集' },
  ret: { title: '物流返程入库登记', fields: [['返程单号', 'text'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['返程数量', 'number'], ['预计到货', 'text'], ['物流商', 'text']], btn: '确认发运' },
  los: { title: '损耗报废登记', fields: [['发生节点', 'select:五产收货核验|五产仓库|客户产线|返程运输|客户仓库'], ['损耗类型', 'select:运输破损|生产损耗|丢失|老化报废|周转损耗'], ['周转箱规格', 'select:' + DATA.specs.map(s => s.code).join('|')], ['损耗数量', 'number'], ['损耗原因', 'textarea'], ['责任人', 'text']], btn: '登记损耗' },
};
function switchFlow(tab) {
  $$('#flow-tabs .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
  const f = FLOW_FORMS[tab];
  const fields = f.fields.map(fl => {
    const [label, type] = fl;
    let ctrl;
    if (type.startsWith('select:')) {
      const opts = type.slice(7).split('|').map(o => `<option>${esc(o)}</option>`).join('');
      ctrl = `<select>${opts}</select>`;
    } else if (type === 'number') ctrl = `<input type="number" placeholder="0">`;
    else if (type === 'textarea') ctrl = `<textarea placeholder="请输入"></textarea>`;
    else ctrl = `<input placeholder="请输入">`;
    return `<div class="field"><label>${label}</label>${ctrl}</div>`;
  }).join('');
  $('#flow-body').innerHTML = `
    <div class="row-flex" style="justify-content:space-between"><h3 style="margin:0">${f.title}</h3>
      <button class="btn primary" onclick="toast('演示：已提交「${f.title}」并生成流水记录')">${ICON.check} ${f.btn}</button></div>
    <div class="form-grid" style="margin-top:14px">${fields}</div>`;
}

/* ============================ 视图：损耗管理 ============================ */
function viewLoss() {
  const pending = DATA.lossRecords.filter(r => r.audit === '待审核').length;
  return `
  <div class="page-head"><div><h1 class="page-title">损耗管理</h1><div class="page-desc">一期：支持各环节损耗登记，形成闭环 <b>损耗登记 → 原因确认 → 责任环节 → 库存影响 → 审核确认 → 台账追溯 → 必要时冲销</b>。损耗是否立即扣减库存、是否需审批、是否进入 MRP 毛需求，均待业务确认。</div></div>
    <div class="row-flex"><button class="btn primary" onclick="lossRegister()">${ICON.plus} 登记损耗</button><button class="btn" onclick="toast('已导出损耗台账')">导出</button></div>
  </div>
  <div class="grid cols-4">
    <div class="stat"><div class="label">累计损耗</div><div class="value">158<small> 个</small></div><div class="trend down">损耗率 1.8%</div><div class="ico-bg ico-red">${ICON.warn}</div></div>
    <div class="stat"><div class="label">本月损耗</div><div class="value">51<small> 个</small></div><div class="trend down">▲ 环比 +6</div><div class="ico-bg ico-orange">${ICON.loss}</div></div>
    <div class="stat"><div class="label">待审核</div><div class="value">${pending}<small> 单</small></div><div class="trend">待确认</div><div class="ico-bg ico-purple">${ICON.box}</div></div>
    <div class="stat"><div class="label">维修恢复率</div><div class="value">62<small> %</small></div><div class="trend up">▲ 较上月 +4%</div><div class="ico-bg ico-green">${ICON.check}</div></div>
  </div>
  <div class="split">
    <div class="card">
      <div class="card-head"><h3>损耗记录明细</h3><span class="sub">点击编号查看闭环与审核/冲销</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>编号</th><th>发生节点</th><th>物料</th><th>部门</th><th>类型</th><th class="num">数量</th><th>审核</th><th>状态</th><th>责任人</th><th>日期</th><th>操作</th></tr></thead>
        <tbody>${DATA.lossRecords.map(r => `<tr><td><span class="link" onclick="openLossDetail('${r.id}')">${r.id}</span></td><td>${r.node}</td><td>${r.spec}</td><td>${r.dept}</td><td>${badge('red', r.type)}</td><td class="num">${r.qty}</td><td>${r.audit === '待审核' ? badge('orange', '待审核') : badge('green', '已确认')}</td><td>${badge('red', r.status)}</td><td>${r.owner}</td><td>${r.time}</td><td><span class="link" onclick="openLossDetail('${r.id}')">详情</span></td></tr>`).join('')}</tbody>
      </table></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>损耗类型分布</h3></div>
      <div id="loss-donut" style="text-align:center"></div>
      <div class="legend" style="margin-top:12px" id="loss-legend"></div>
    </div>
  </div>`;
}
function initLoss() {
  const types = {};
  DATA.lossRecords.forEach(r => types[r.type] = (types[r.type] || 0) + r.qty);
  const colors = ['#f53f3f', '#ff7d00', '#722ed1', '#165DFF', '#14c9c9'];
  const segs = Object.entries(types).map((t, i) => ({ value: t[1], color: colors[i % colors.length] }));
  donutChart($('#loss-donut'), segs, { v: String(Object.values(types).reduce((a, b) => a + b, 0)), l: '损耗合计' });
  $('#loss-legend').innerHTML = Object.entries(types).map((t, i) => `<div class="li"><span class="sw" style="background:${colors[i % colors.length]}"></span>${t[0]}<span class="lv">${t[1]}</span></div>`).join('');
}
function lossRegister() {
  const specs = DATA.specs.map(s => `<option value="${s.code}">${s.code} ${s.name}</option>`).join('');
  const body = `
    <div class="field"><label>发生节点<span class="req">*</span></label><select id="los-node"><option>五产收货核验</option><option>五产仓库</option><option>客户产线</option><option>返程运输</option><option>客户仓库</option></select></div>
    <div class="field"><label>损耗类型<span class="req">*</span></label><select id="los-type"><option>运输破损</option><option>生产损耗</option><option>丢失</option><option>老化报废</option><option>周转损耗</option></select></div>
    <div class="field"><label>周转箱规格<span class="req">*</span></label><select id="los-spec">${specs}</select></div>
    <div class="field"><label>损耗数量<span class="req">*</span></label><input id="los-qty" type="number" value="3"></div>
    <div class="field"><label>责任环节<span class="req">*</span></label><select id="los-resp"><option>质量</option><option>物流</option><option>仓库</option><option>客户对接</option></select></div>
    <div class="field"><label>是否立即扣减库存</label><select id="los-impact"><option>是</option><option>否</option></select></div>
    <div class="field" style="grid-column:1/-1"><label>损耗原因</label><textarea id="los-reason" placeholder="如：装卸跌落导致箱体开裂"></textarea></div>`;
  openModal('登记损耗', body, () => {
    const node = document.getElementById('los-node').value;
    const type = document.getElementById('los-type').value;
    const spec = document.getElementById('los-spec').value;
    const qty = parseInt(document.getElementById('los-qty').value, 10) || 0;
    const resp = document.getElementById('los-resp').value;
    const impact = document.getElementById('los-impact').value;
    const reason = document.getElementById('los-reason').value;
    if (!qty) { toast('请填写损耗数量'); return; }
    const id = 'LOS-' + String(DATA.lossRecords.length + 1).padStart(3, '0');
    const rec = { id, node, type, spec, qty, reason, respLink: resp, stockImpact: impact, status: '待审核', audit: '待审核', owner: '孙伟', dept: resp, time: '08-07' };
    DATA.lossRecords.unshift(rec);
    toast('已登记损耗 ' + id + '（待审核，已写入台账）');
    rerender();
  });
}
function openLossDetail(id) {
  const r = DATA.lossRecords.find(x => x.id === id); if (!r) return;
  const foot = r.audit === '待审核'
    ? `<button class="btn" onclick="closeModal()">关闭</button><button class="btn danger" onclick="lossReverse('${id}')">冲销</button><button class="btn primary" onclick="lossAudit('${id}')">审核确认</button>`
    : `<button class="btn" onclick="closeModal()">关闭</button><button class="btn danger" onclick="lossReverse('${id}')">冲销</button>`;
  openModal('损耗闭环 · ' + r.id, `
    <div class="detail-grid">
      <div><label>来源单据</label><b>${r.id}</b></div>
      <div><label>物料(规格)</label><b>${r.spec}</b></div>
      <div><label>发生节点</label><b>${r.node}</b></div>
      <div><label>损耗类型</label><b>${r.type}</b></div>
      <div><label>数量</label><b>${r.qty} 个</b></div>
      <div><label>责任环节</label><b>${r.respLink || r.dept}</b></div>
      <div><label>库存影响</label><b>${r.stockImpact || '—'}</b></div>
      <div><label>审核状态</label><b>${r.audit}</b></div>
      <div><label>状态</label><b>${r.status}</b></div>
      <div><label>责任人 / 时间</label><b>${r.owner} · ${r.time}</b></div>
      <div style="grid-column:1/-1"><label>原因</label><b>${r.reason || '—'}</b></div>
    </div>`, null, foot);
}
function lossAudit(id) {
  const r = DATA.lossRecords.find(x => x.id === id); if (!r) return;
  confirmDialog('审核确认损耗', `将确认损耗单 <b>${id}</b>（${r.type} ${r.qty} 个），状态置为"已报废/已核销"，并计入台账与损耗统计。是否继续？`, () => {
    r.audit = '已确认'; r.status = r.status === '已核销' ? '已核销' : '已报废';
    toast('已审核确认 ' + id);
    closeModal(); rerender();
  });
}
function lossReverse(id) {
  const r = DATA.lossRecords.find(x => x.id === id); if (!r) return;
  confirmDialog('冲销损耗', `将冲销损耗单 <b>${id}</b>（${r.qty} 个），生成反向流水并回退台账。冲销后不可再次冲销。是否继续？`, () => {
    r.audit = '已冲销'; r.status = '已冲销';
    toast('已冲销 ' + id);
    closeModal(); rerender();
  });
}

/* ============================ 视图：库存溯源台账 ============================ */
function viewLedger() {
  const all = buildLedger();
  const depts = [...new Set(all.map(r => r.dept))];
  const specs = [...new Set(all.map(r => r.spec))];
  const statuses = [...new Set(all.map(r => r.status))];
  const owners = [...new Set(all.map(r => r.owner))];
  const opt = (arr, ph) => `<option value="">${ph}</option>` + arr.map(v => `<option>${esc(v)}</option>`).join('');
  return `
  <div class="page-head"><div><h1 class="page-title">库存溯源台账（镜像流水）</h1><div class="page-desc">满足一期"线上台账 + 镜像流水"要求：每个库存数字均可溯源至来源单据，并完整携带【来源单据 / 物料 / 部门 / 数量 / 状态 / 时间 / 责任人】七要素。点击任意数字或节点可下钻到此。</div></div>
    <div class="row-flex"><button class="btn" onclick="toast('已导出溯源台账')">导出</button><button class="btn primary" onclick="toast('已生成库存水印快照')">${ICON.check} 生成水印</button></div>
  </div>
  <div class="card" style="border-left:3px solid var(--warning)">
    <div class="alert-title">${ICON.warn} 三类对象请勿混淆</div>
    <div class="tri-note">
      <div><b>库存余额</b><span>某一时点的实际在库数量（时点值），由"上一时点余额 + 增加流水 − 减少流水"滚动得出，<u>不能把流水数量直接相加</u>。</span></div>
      <div><b>库存流水</b><span>每一次状态 / 数量 / 位置变化（一行记录），含来源单据、物料、部门、数量、状态、时间、责任人七要素。</span></div>
      <div><b>业务单据</b><span>引起余额变化的来源凭证（采购入库单、发运单、到货验收单、损耗单、冲销单等），流水通过单据号追溯。</span></div>
    </div>
    <div class="muted" style="margin-top:8px">本页"库存流水"列表展示的是逐笔流水；如需查看时点余额，请到对应模块（如供应商来料、客户返程、损耗台账）的"当前在库 / 数量"卡片。</div>
  </div>
  <div class="card">
    <div class="filter-bar">
      <div class="field" style="flex:1.4;min-width:180px"><label>来源单据 / 关键词</label><input id="lg-search" placeholder="单据号、业务环节"></div>
      <div class="field"><label>物料</label><select id="lg-spec">${opt(specs, '全部')}</select></div>
      <div class="field"><label>部门</label><select id="lg-dept">${opt(depts, '全部')}</select></div>
      <div class="field"><label>状态</label><select id="lg-status">${opt(statuses, '全部')}</select></div>
      <div class="field"><label>责任人</label><select id="lg-owner">${opt(owners, '全部')}</select></div>
      <div class="field"><label>&nbsp;</label><button class="btn" onclick="renderLedger()">${ICON.search} 查询</button></div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>来源单据</th><th>业务环节</th><th>物料</th><th>部门</th><th class="num">数量</th><th>状态</th><th>时间</th><th>责任人</th><th>操作</th></tr></thead>
      <tbody id="lg-body"></tbody>
    </table></div>
    <div id="lg-count" class="muted" style="margin-top:10px"></div>
  </div>`;
}
function initLedger() {
  if (pendingLedgerFilter) {
    if (pendingLedgerFilter.dept) $('#lg-dept').value = pendingLedgerFilter.dept;
    if (pendingLedgerFilter.search) $('#lg-search').value = pendingLedgerFilter.search;
    pendingLedgerFilter = null;
  }
  renderLedger();
}
function renderLedger() {
  const all = buildLedger();
  const kw = ($('#lg-search').value || '').trim().toLowerCase();
  const spec = $('#lg-spec').value, dept = $('#lg-dept').value, status = $('#lg-status').value, owner = $('#lg-owner').value;
  const rows = all.filter(r =>
    (!kw || (r.doc + r.biz).toLowerCase().includes(kw)) &&
    (!spec || r.spec === spec) &&
    (!dept || r.dept === dept) &&
    (!status || r.status === status) &&
    (!owner || r.owner === owner)
  );
  const stColor = s => /报废|核销|破损/.test(s) ? 'red' : (/在途|待|核验/.test(s) ? 'orange' : 'green');
  $('#lg-body').innerHTML = rows.map(r => `<tr>
    <td><span class="link" onclick="openLedgerDetail('${r.doc}')">${r.doc}</span></td>
    <td>${r.biz}</td><td>${r.spec}</td><td>${r.dept}</td>
    <td class="num">${fmt(r.qty)}</td><td>${badge(stColor(r.status), r.status)}</td><td>${r.time}</td><td>${r.owner}</td>
    <td><span class="link" onclick="openLedgerDetail('${r.doc}')">明细</span></td></tr>`).join('') ||
    '<tr><td colspan="9" class="muted" style="text-align:center;padding:24px">无匹配记录</td></tr>';
  $('#lg-count').textContent = `共 ${rows.length} 条库存流水，合计数量 ${fmt(rows.reduce((a, b) => a + b.qty, 0))} 个（均为可溯源库存数字）`;
}
function openLedgerDetail(doc) {
  const r = buildLedger().find(x => x.doc === doc);
  if (!r) return;
  openModal('库存数字溯源 · ' + r.doc, `
    <div class="detail-grid">
      <div><label>来源单据</label><b>${r.doc}</b></div>
      <div><label>物料(规格)</label><b>${r.spec}</b></div>
      <div><label>部门</label><b>${r.dept}</b></div>
      <div><label>数量</label><b>${fmt(r.qty)} 个</b></div>
      <div><label>状态</label><b>${r.status}</b></div>
      <div><label>时间</label><b>${r.time}</b></div>
      <div><label>责任人</label><b>${r.owner}</b></div>
      <div><label>业务环节</label><b>${r.biz}</b></div>
    </div>
    <p class="muted" style="margin-top:14px">该库存数字可由上述七要素完整溯源，符合"每个库存数字必须具备来源单据、物料、部门、数量、状态、时间和责任人"的要求。</p>
  `);
}

/* ============================ 视图：简易MRP ============================ */
function viewMrp() {
  return `
  <div class="page-head"><div><h1 class="page-title">简易MRP与采购建议</h1><div class="page-desc">二期功能：基于一期供应数据与订单/工单/排产/BOM，按「部门+物料+日期」展开未来10天供需，输出按期短缺与采购需求建议。结果可解释、可重算、可追溯。</div></div>
    <div class="row-flex"><button class="btn" onclick="toast('已导出MRP快照')">导出快照</button><button class="btn primary" onclick="runMrp()">${ICON.mrp} 运行MRP（未来10天）</button></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>MRP运行参数</h3><span class="sub">参数真实参与计算（提前期 / 安全库存）</span></div>
    <div class="form-grid">
      <div class="field"><label>计算窗口</label><select id="mrp-window"><option>未来10天（自然日）</option><option>未来10天（工作日）</option></select></div>
      <div class="field"><label>需求日期口径</label><select id="mrp-basis"><option>排产日</option><option>开工日</option><option>完工日</option></select></div>
      <div class="field"><label>部门维度</label><select id="mrp-dept"><option>生产部门</option><option>库存组织</option><option>责任部门</option></select></div>
      <div class="field"><label>替代分配顺序</label><select id="mrp-sub"><option>先替料后主料</option><option>先主料后替料</option></select></div>
      <div class="field"><label>采购提前期（下单→到货）</label><select id="mrp-lead"><option value="0">0 天</option><option value="3">3 天</option><option value="5" selected>5 天</option><option value="7">7 天</option></select></div>
      <div class="field"><label>安全库存阈值</label><select id="mrp-safety"><option value="100">100 个</option><option value="200" selected>200 个</option><option value="300">300 个</option></select></div>
    </div>
    <div class="muted" style="margin-top:6px">计算口径：逐日滚动，未满足需求（backlog）结转下一日；供应仅在首次可用日进入一次；期末可用余额低于安全库存时额外建议补货。采购建议由结果动态生成，可追溯至需求与供应。</div>
  </div>
  <div id="mrp-result"></div>`;
}
function initMrp() { $('#mrp-result').innerHTML = `<div class="card"><div class="empty">点击右上角「运行MRP」生成未来10天供需推演与采购建议。</div></div>`; }
function runMrp() {
  const labels = ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10'];
  // 当日新增需求（毛需求）与当日首次可用的新增供应（采购到货 + 返程良品）
  const gross = [380, 420, 360, 500, 460, 300, 540, 420, 380, 460];
  const supply = [200, 260, 220, 180, 300, 240, 200, 320, 260, 300];
  const lead = parseInt($('#mrp-lead').value, 10) || 0;
  const safety = parseInt($('#mrp-safety').value, 10) || 0;

  let beginAvail = 1240;      // 期初可用余额
  let beginBacklog = 0;       // 期初累计未满足需求（backlog）
  const rows = [];
  let firstShortDay = -1;
  for (let i = 0; i < 10; i++) {
    const g = gross[i], s = supply[i];
    const allocatable = beginAvail + s;          // 当日可分配量
    const toMeeting = beginBacklog + g;          // 当日待满足量
    const allocated = Math.min(allocatable, toMeeting);
    const endAvail = allocatable - allocated;     // 期末可用余额
    const endBacklog = toMeeting - allocated;     // 期末 backlog（结转下一日）
    if (endBacklog > 0 && firstShortDay < 0) firstShortDay = i;
    const dayShort = g - Math.max(0, Math.min(beginAvail + s, toMeeting) - beginBacklog); // 当日新增净短缺
    const dayShortReal = Math.max(0, endBacklog - beginBacklog); // 当日新增 backlog（仅展示）
    rows.push({ d: labels[i], g, s, begin: beginAvail, end: endAvail, backlog: endBacklog, dayNew: dayShortReal });
    beginAvail = endAvail; beginBacklog = endBacklog;
  }
  const finalBacklog = beginBacklog;
  const finalAvail = beginAvail;
  // 安全库存补货：期末可用余额低于安全库存时，补充到安全库存
  const safetyTop = finalAvail < safety ? (safety - finalAvail) : 0;
  const totalShort = rows.reduce((a, r) => a + r.dayNew, 0);
  const endArr = rows.map(r => r.end);
  const shortArr = rows.map(r => r.backlog);
  const backlogArr = rows.map(r => r.backlog);

  // 动态生成采购建议：补累计欠料（finalBacklog）+ 安全库存补货
  const recQty = finalBacklog + safetyTop;
  const recArrive = firstShortDay >= 0 ? labels[firstShortDay] : '—';
  const recOrderDay = lead > 0 && firstShortDay >= 0 ? labels[Math.max(0, firstShortDay - lead)] : '今日';

  const detailRows = rows.map(r => `<tr>
    <td>${r.d}</td>
    <td class="num">${r.g}</td>
    <td class="num">${r.s}</td>
    <td class="num">${fmt(r.begin)}</td>
    <td class="num">${fmt(r.end)}</td>
    <td class="num">${r.backlog > 0 ? badge('red', fmt(r.backlog)) : badge('green', '0')}</td>
    <td>${r.dayNew > 0 ? badge('orange', '当日新增 ' + fmt(r.dayNew)) : '—'}</td>
  </tr>`).join('');

  const purchaseRows = [];
  if (finalBacklog > 0) purchaseRows.push(`<tr><td>TBX-A1 标准周转箱</td><td>${badge('red', '补累计欠料')}</td><td>累计至 ${recArrive}</td><td class="num">${fmt(finalBacklog)}</td><td class="num">${recOrderDay}</td><td>${badge('orange', '待采购确认')}</td></tr>`);
  if (safetyTop > 0) purchaseRows.push(`<tr><td>TBX-A1 标准周转箱</td><td>${badge('purple', '安全库存补货')}</td><td>周期末前</td><td class="num">${fmt(safetyTop)}</td><td class="num">${recOrderDay}</td><td>${badge('orange', '待采购确认')}</td></tr>`);
  if (!purchaseRows.length) purchaseRows.push(`<tr><td colspan="6" class="muted" style="text-align:center;padding:18px">当前参数下无短缺，无需采购建议</td></tr>`);

  $('#mrp-result').innerHTML = `
    <div class="grid cols-4">
      <div class="stat"><div class="label">周期毛需求</div><div class="value">${fmt(gross.reduce((a, b) => a + b, 0))}</div><div class="ico-bg ico-blue">${ICON.calc}</div></div>
      <div class="stat"><div class="label">周期末可用余额</div><div class="value">${fmt(finalAvail)}</div><div class="ico-bg ico-green">${ICON.box}</div></div>
      <div class="stat"><div class="label">累计未满足 (backlog)</div><div class="value">${fmt(finalBacklog)}</div><div class="ico-bg ico-red">${ICON.warn}</div></div>
      <div class="stat"><div class="label">采购建议合计</div><div class="value">${fmt(recQty)}</div><div class="ico-bg ico-orange">${ICON.truck}</div></div>
    </div>
    <div class="card"><div class="card-head"><h3>逐日供需推演（含 backlog 结转）</h3><span class="sub">期末 backlog 转入下一日期初</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>日期</th><th>当日新增需求</th><th>当日新增供应</th><th>期初可用余额</th><th>期末可用余额</th><th>期末 backlog</th><th>当日新增短缺</th></tr></thead>
        <tbody>${detailRows}</tbody>
      </table></div>
      <div class="muted" style="margin-top:8px">示例：D7 短缺 120、D8 再短缺 100 → 期末 backlog 累计 220（而非仅显示 100），符合"未满足需求结转"规则。</div>
    </div>
    <div class="split">
      <div class="card"><div class="card-head"><h3>期末可用余额 与 backlog 走势</h3></div><div id="mrp-line"></div></div>
      <div class="card"><div class="card-head"><h3>采购需求建议清单</h3><span class="sub">由计算结果动态生成 · 人工确认/调整/忽略</span></div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>物料</th><th>建议类型</th><th>最迟到货日</th><th>建议数量</th><th>建议下单日</th><th>状态</th></tr></thead>
          <tbody>${purchaseRows.join('')}</tbody>
        </table></div>
        <div class="row-flex" style="margin-top:12px;justify-content:flex-end"><button class="btn" onclick="toast('已忽略选中建议')">忽略</button><button class="btn primary" onclick="confirmDialog('确认采购建议','将把建议数量回写为人工采购需求，由采购人员开单（本项目不自动回写ERP）。是否继续？',()=>toast('已生成采购需求，请采购人员开单'))">确认并生成采购需求</button></div>
      </div>
    </div>`;
  lineChart($('#mrp-line'), [
    { name: '期末可用余额', color: '#00b42a', data: endArr },
    { name: '累计 backlog', color: '#f53f3f', data: backlogArr },
  ], labels);
}

/* ============================ 视图：数据统计分析 ============================ */
function viewAnalytics() {
  return `
  <div class="page-head"><div><h1 class="page-title">数据统计分析</h1><div class="page-desc">统计周转效率、损耗、闲置与采购等指标，支持按日/周/月/季度生成报表，作为成本与流程优化依据。<b>单箱级指标需箱码/RFID 数据支持，一期仅管理物料级汇总，已标记为远期规划。</b></div></div></div>
  <div class="grid cols-4">
    <div class="stat" style="border-left:3px solid var(--purple)"><div class="label">单箱平均周转次数 ${badge('purple', '远期')}</div><div class="value">8.6<small> 次</small></div><div class="trend up">▲ 月环比 +0.4</div><div class="ico-bg ico-blue">${ICON.chart}</div></div>
    <div class="stat" style="border-left:3px solid var(--purple)"><div class="label">平均周转周期 ${badge('purple', '远期')}</div><div class="value">18.2<small> 天</small></div><div class="trend down">▼ 缩短 1.3天</div><div class="ico-bg ico-cyan">${ICON.refresh}</div></div>
    <div class="stat"><div class="label">整体利用率（物料级）</div><div class="value">74<small> %</small></div><div class="trend up">▲ +2%</div><div class="ico-bg ico-green">${ICON.check}</div></div>
    <div class="stat"><div class="label">闲置占比（物料级）</div><div class="value">11<small> %</small></div><div class="trend down">▼ -1.5%</div><div class="ico-bg ico-orange">${ICON.box}</div></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>指标定义与数据基础</h3><span class="sub">所有指标须有公式、数据来源与统计周期</span></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>指标</th><th>定义</th><th>计算公式</th><th>数据来源</th><th>统计周期</th><th>阶段</th></tr></thead>
      <tbody>
        <tr><td>整体利用率</td><td>在用数量占可用总量比</td><td>在用 / (可用+闲置)</td><td>库存余额快照</td><td>周</td><td>${badge('green', '一期')}</td></tr>
        <tr><td>闲置占比</td><td>闲置库存占可用总量比</td><td>闲置 / (可用+闲置)</td><td>库存余额快照</td><td>周</td><td>${badge('green', '一期')}</td></tr>
        <tr><td>损耗率</td><td>损耗数量占流转总量比</td><td>损耗 / 流转量</td><td>损耗台账</td><td>月</td><td>${badge('green', '一期')}</td></tr>
        <tr><td>按客户返程周期</td><td>发运到实际到厂天数</td><td>到厂日 − 发运日</td><td>返程单字段</td><td>月</td><td>${badge('green', '一期')}</td></tr>
        <tr><td>单箱平均周转次数</td><td>单箱全生命周期循环次数</td><td>需箱码累计出入库次数</td><td>箱码/RFID（待建设）</td><td>—</td><td>${badge('purple', '远期')}</td></tr>
        <tr><td>平均周转周期</td><td>单箱两次使用间隔</td><td>需箱码事件间隔</td><td>箱码/RFID（待建设）</td><td>—</td><td>${badge('purple', '远期')}</td></tr>
      </tbody>
    </table></div>
    <div class="muted" style="margin-top:8px">说明：一期仅物料级汇总，单箱级指标需唯一箱身份（箱码/二维码/RFID）与逐次出入库事件，列为远期规划；当前先用"按批次/订单/客户"维度统计周转与返程周期。</div>
  </div>
  <div class="split">
    <div class="card"><div class="card-head"><h3>各规格损耗数量（物料级）</h3></div><div id="an-bar"></div></div>
    <div class="card"><div class="card-head"><h3>规格使用率分布</h3></div><div id="an-hbar"></div></div>
  </div>
  <div class="card"><div class="card-head"><h3>月度损耗与采购分析</h3><span class="sub">近6个月</span></div><div id="an-line"></div></div>`;
}
function initAnalytics() {
  barChart($('#an-bar'), DATA.specs.map(s => ({ label: s.code.replace('TBX-', ''), value: Math.round(s.idle / 10) + 3 })), { colors: ['#ff7d00'] });
  hBarChart($('#an-hbar'), DATA.specs.map(s => ({ label: s.code, value: s.usage, color: 'var(--brand)' })));
  lineChart($('#an-line'), [
    { name: '损耗', color: '#f53f3f', data: [42, 38, 51, 47, 44, 51] },
    { name: '采购补充', color: '#165DFF', data: [300, 200, 450, 380, 260, 320] },
  ], ['1月', '2月', '3月', '4月', '5月', '6月']);
}

/* ============================ 视图：规格标准化 ============================ */
function viewSpecs() {
  return `
  <div class="page-head"><div><h1 class="page-title">规格标准化管理</h1><div class="page-desc">建立周转箱规格档案，统一型号、尺寸、承重、适配产品与状态，统计使用率/闲置率，为规格优化淘汰提供数据支撑。</div></div>
    <button class="btn primary" onclick="toast('演示：打开新增规格')">${ICON.plus} 新增规格</button></div>
  <div class="card">
    <div class="filter-bar">
      <div class="field"><input placeholder="搜索规格编码/名称"></div>
      <div class="field"><select><option>全部状态</option><option>在用</option><option>闲置</option><option>停用</option></select></div>
    </div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>规格编码</th><th>名称</th><th>尺寸(mm)</th><th>承重</th><th>状态</th><th>使用率</th><th>闲置数量</th><th>操作</th></tr></thead>
      <tbody>${DATA.specs.map(s => `<tr><td>${s.code}</td><td>${s.name}</td><td>${s.size}</td><td>${s.load}</td><td>${specStatus(s.status)}</td>
        <td><div class="row-flex" style="gap:8px"><div class="meter ${s.usage > 60 ? 'green' : s.usage > 30 ? 'orange' : 'red'}" style="width:80px"><span style="width:${s.usage}%"></span></div><span class="num">${s.usage}%</span></div></td>
        <td class="num">${s.idle}</td><td><span class="link" onclick="toast('查看 ${s.code} 档案')">档案</span></td></tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}
function specStatus(st) { return st === '在用' ? badge('green', st) : st === '闲置' ? badge('orange', st) : badge('gray', st); }
function initSpecs() {}

/* ============================ 视图：人员权责 ============================ */
function viewRoles() {
  const perms = [
    ['view', '查询'], ['inbound', '来料/入库'], ['issue', '发料/出库'], ['returnReg', '返程登记'],
    ['loss', '损耗登记'], ['mrp', 'MRP运行'], ['purchase', '采购确认'], ['audit', '审核/冲销'], ['admin', '系统管理'],
  ];
  const mark = v => v === '●' ? '<span class="dot-yes">●</span>' : v === '○' ? '<span class="dot-part">○</span>' : '<span class="dot-no">—</span>';
  return `
  <div class="page-head"><div><h1 class="page-title">人员权责管理</h1><div class="page-desc">为各流转节点配置操作责任人与审核人，所有操作绑定账号全程留痕；支持权限分级，不同岗位对应不同操作/查询权限。</div></div></div>
  <div class="card">
    <div class="card-head"><h3>角色权限矩阵</h3><span class="sub">● 完全 · ○ 部分/申请 · — 无</span></div>
    <div class="table-wrap"><table class="tbl matrix-table">
      <thead><tr><th class="role-col">角色 \\ 权限</th>${perms.map(p => `<th>${p[1]}</th>`).join('')}</tr></thead>
      <tbody>${DATA.roles.map(r => `<tr><td class="role-col"><b>${r.role}</b></td>${perms.map(p => `<td>${mark(r.perm[p[0]])}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>节点责任人配置</h3></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>流转节点</th><th>操作责任人</th><th>审核人</th><th>状态</th></tr></thead>
      <tbody>
        <tr><td>供应商来料入库</td><td>李娜（仓库）</td><td>张敏（审核）</td><td>${badge('green', '已配置')}</td></tr>
        <tr><td>转运顺达出库</td><td>赵强（物流）</td><td>王磊（采购）</td><td>${badge('green', '已配置')}</td></tr>
        <tr><td>客户仓库/领用/回收</td><td>陈静（客户对接）</td><td>王磊（采购）</td><td>${badge('green', '已配置')}</td></tr>
        <tr><td>返程入库核验</td><td>李娜（仓库）</td><td>张敏（审核）</td><td>${badge('green', '已配置')}</td></tr>
        <tr><td>损耗报废登记</td><td>孙伟（质量）</td><td>张敏（审核）</td><td>${badge('orange', '待补录')}</td></tr>
      </tbody>
    </table></div>
  </div>`;
}
function initRoles() {}

/* ============================ 视图：系统设置 ============================ */
function viewSettings() {
  const src = [
    { s: 'ERP（PO/库存/过账）', m: '定时同步', f: '每15分钟', last: '08-07 09:40', st: '开发联调中', cls: 'orange', owner: '王磊(采购)', contact: 'IT-张工' },
    { s: 'MES（工单/完工事件）', m: '消息', f: '实时', last: '—', st: '计划接入', cls: 'gray', owner: '待定', contact: 'IT-李工' },
    { s: 'WMS（库存）', m: '数据库视图', f: '每5分钟', last: '—', st: '接入评估中', cls: 'purple', owner: '待定', contact: '仓储-周主管' },
    { s: '主数据（物料/BOM）', m: 'API', f: '每日', last: '08-07 02:00', st: '已接通', cls: 'green', owner: '主数据管理员', contact: '数据治理组' },
    { s: '客户库存文件', m: '文件导入', f: '每周', last: '08-03', st: '待人工导入', cls: 'orange', owner: '陈静(客户对接)', contact: '客户运营' },
    { s: '供应商在制/待发', m: '待确认', f: '待确认', last: '—', st: '待确认', cls: 'gray', owner: '待定', contact: '采购' },
  ];
  return `
  <div class="page-head"><div><h1 class="page-title">系统设置 / 主数据</h1><div class="page-desc">主数据接入、接口清单、状态口径、数据时效与待确认问题跟踪（对照需求方案第七章）。<b>未落地的接口不得展示为"正常"</b>，须区分 计划接入 / 接入评估中 / 开发联调中 / 已接通，并标注最近同步时间与数据负责人。</div></div></div>
  <div class="split">
    <div class="card">
      <div class="card-head"><h3>外部数据源接入状态</h3><span class="sub">区分接入阶段，非"正常"表达</span></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>数据源</th><th>接口方式</th><th>同步频率</th><th>最近成功同步</th><th>数据负责人</th><th>异常联系人</th><th>状态</th></tr></thead>
        <tbody>${src.map(r => `<tr><td>${r.s}</td><td>${r.m}</td><td>${r.f}</td><td>${r.last}</td><td>${r.owner}</td><td>${r.contact}</td><td>${badge(r.cls, r.st)}</td></tr>`).join('')}</tbody>
      </table></div>
      <div class="muted" style="margin-top:8px">说明：ERP/WMS/MES 的职责边界与接口能力尚在评估中；客户周库存来自每周文件导入；供应商在制/待发数据来源待确认。请勿将"计划接入/评估中"误读为已上线。</div>
    </div>
    <div class="card">
      <div class="card-head"><h3>待业务确认问题（抽样）</h3><span class="sub">见需求方案第7章</span></div>
      <div class="timeline">
        <div class="tl-item"><div class="tl-time">Q-BIZ-001</div><div class="tl-text"><b>需求去重：</b>销售订单生成工单后是否完全由工单替代？<span class="badge orange">待确认</span></div></div>
        <div class="tl-item"><div class="tl-time">Q-DATA-005</div><div class="tl-text"><b>库存状态：</b>现有系统能否区分可用/预占/待检/破损/报废？<span class="badge orange">待确认</span></div></div>
        <div class="tl-item"><div class="tl-time">Q-P1-004</div><div class="tl-text"><b>返程可用时点：</b>到厂后何时转可用？<span class="badge orange">待确认</span></div></div>
        <div class="tl-item"><div class="tl-time">Q-MRP-002</div><div class="tl-text"><b>供应有效性：</b>四类供应满足何种条件参与MRP？<span class="badge orange">待确认</span></div></div>
      </div>
      <button class="btn sm" onclick="toast('演示：打开完整待确认清单(40+)')">查看全部待确认问题</button>
    </div>
  </div>`;
}
function initSettings() {}

/* ============================ 弹窗 / Toast ============================ */
function openModal(title, bodyHtml, onOk, footerHtml) {
  const ov = $('#overlay');
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHtml;
  const foot = $('#modal-foot');
  if (footerHtml != null) {
    foot.innerHTML = footerHtml;
    foot.style.display = '';
  } else {
    foot.innerHTML = '<button class="btn" onclick="closeModal()">取消</button><button class="btn primary" id="modal-ok">确定</button>';
    $('#modal-ok').onclick = () => { if (onOk) onOk(); ov.classList.remove('open'); };
  }
  ov.classList.add('open');
  const f = ov.querySelector('.modal');
  if (f) { f.setAttribute('tabindex', '-1'); f.focus(); }
}
/* 二次确认对话框：说明将影响的库存/单据/状态 */
function confirmDialog(title, bodyHtml, onOk) {
  const footer = `<button class="btn" onclick="closeModal()">取消</button><button class="btn primary" id="modal-ok">确认执行</button>`;
  openModal(title, `<div class="confirm-box">${bodyHtml}</div>`, onOk, footer);
}
function closeModal() { $('#overlay').classList.remove('open'); }
let toastTimer;
function toast(msg) {
  let t = $('#toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); t.style.cssText = 'position:fixed;left:50%;bottom:32px;transform:translateX(-50%);background:rgba(29,33,41,.92);color:#fff;padding:10px 18px;border-radius:8px;font-size:13px;z-index:200;box-shadow:var(--shadow-lg);transition:opacity .2s'; document.body.appendChild(t); }
  t.textContent = msg; t.style.opacity = '1';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.style.opacity = '0'; }, 2200);
}

/* ============================ 初始化 ============================ */
function buildSidebar() {
  const groups = {};
  Object.entries(VIEWS).forEach(([k, v]) => { (groups[v.group] = groups[v.group] || []).push([k, v]); });
  let html = '';
  Object.entries(groups).forEach(([g, items]) => {
    html += `<div class="nav-group-title">${g}</div>`;
    items.forEach(([k, v]) => {
      html += `<div class="nav-item ${k === currentView ? 'active' : ''}" data-view="${k}" onclick="navigate('${k}')">
        <span class="ico">${v.icon}</span><span class="label">${v.title}</span>${v.phase ? `<span class="nav-phase-tag ${PHASE_CLASS[v.phase] || 'gray'}">${v.phase}</span>` : ''}</div>`;
    });
  });
  $('#nav').innerHTML = html;
}
function initApp() {
  buildSidebar();
  $('#toggle').onclick = () => $('.sidebar').classList.toggle('collapsed');
  const syncThemeIcon = () => { $('#theme').innerHTML = document.documentElement.getAttribute('data-theme') === 'dark' ? ICON.sun : ICON.moon; };
  syncThemeIcon();
  $('#theme').onclick = () => {
    const d = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', d ? 'light' : 'dark');
    $('#theme').innerHTML = d ? ICON.moon : ICON.sun;
    syncThemeIcon();
  };
  navigate('dashboard');
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#overlay').classList.contains('open')) closeModal(); });
}
document.addEventListener('DOMContentLoaded', initApp);
