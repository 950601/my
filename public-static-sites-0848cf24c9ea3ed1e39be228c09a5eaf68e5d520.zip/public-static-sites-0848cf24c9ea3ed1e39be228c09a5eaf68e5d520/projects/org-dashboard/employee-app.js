(() => {
  "use strict";

  const data = window.EMPLOYEE_DATA;
  const resultLimit = 80;
  const state = { query: "", selectedAccount: null, departmentFilter: null };
  const elements = {
    snapshot: document.querySelector("#employee-snapshot-label"),
    search: document.querySelector("#employee-search"),
    summary: document.querySelector("#directory-summary"),
    coverage: document.querySelector("#directory-coverage"),
    results: document.querySelector("#employee-results"),
    detail: document.querySelector("#employee-detail"),
  };

  if (!data || !Array.isArray(data.employees)) {
    elements.snapshot.textContent = "Snapshot unavailable";
    elements.results.innerHTML = '<div class="error-banner">The local employee snapshot is missing. Run scripts/export_employee_data.py and reload this page.</div>';
    return;
  }

  const employees = data.employees.map((employee) => ({
    ...employee,
    searchText: [employee.account, employee.email, employee.name, employee.jobTitle, employee.department]
      .join(" ")
      .toLocaleLowerCase("zh-CN"),
  }));
  const employeeByAccount = new Map(employees.map((employee) => [employee.account, employee]));
  const numberFormatter = new Intl.NumberFormat("en-US");

  function initialize() {
    const generatedAt = new Date(data.meta.generatedAt);
    elements.snapshot.textContent = Number.isNaN(generatedAt.getTime())
      ? "Local snapshot"
      : `Generated ${generatedAt.toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}`;
    const jobTitleCount = data.meta.jobTitleCount ?? employees.filter((employee) => employee.jobTitle).length;
    elements.coverage.textContent = `${numberFormatter.format(data.meta.employeeCount)} employees · ${numberFormatter.format(data.meta.emailCount)} emails · ${numberFormatter.format(jobTitleCount)} job titles · ${numberFormatter.format(data.meta.responsibilityEmployeeCount)} with mapped responsibilities`;
    bindEvents();
    applyDirectoryLink();
  }

  function renderResults() {
    const query = state.query.trim().toLocaleLowerCase("zh-CN");
    if (!query && !state.departmentFilter) {
      elements.summary.textContent = "Enter a search term to begin.";
      elements.results.innerHTML = '<div class="empty-state compact-empty"><span class="empty-icon">⌕</span><p>Search the local snapshot to see matching employees.</p></div>';
      return;
    }

    const matches = state.departmentFilter
      ? employees.filter((employee) => state.departmentFilter.ids.has(employee.departmentId))
      : employees.filter((employee) => employee.searchText.includes(query));
    const visible = matches.slice(0, resultLimit);
    const matchSummary = matches.length > resultLimit
      ? `${numberFormatter.format(matches.length)} matches · showing the first ${resultLimit}`
      : `${numberFormatter.format(matches.length)} ${matches.length === 1 ? "match" : "matches"}`;
    elements.summary.textContent = state.departmentFilter
      ? `${matchSummary} · ${state.departmentFilter.description}`
      : matchSummary;

    if (!visible.length) {
      elements.results.innerHTML = '<div class="empty-state compact-empty"><p>No employee matches this search.</p></div>';
      return;
    }

    elements.results.innerHTML = visible.map((employee) => `
      <button class="employee-result ${state.selectedAccount === employee.account ? "selected" : ""}" type="button" data-account="${escapeHtml(employee.account)}">
        <span class="employee-avatar" aria-hidden="true">${escapeHtml(employee.name.slice(-1))}</span>
        <span class="employee-result-copy">
          <strong>${escapeHtml(employee.name)}</strong>
          <span>${escapeHtml([employee.jobTitle, employee.department].filter(Boolean).join(" · "))}</span>
        </span>
        <span class="employee-account">${escapeHtml(employee.account)}</span>
      </button>
    `).join("");
  }

  function renderDetail(employee) {
    const responsibilityGroups = groupResponsibilities(employee.responsibilities);
    elements.detail.innerHTML = `
      <div class="employee-detail-heading">
        <span class="employee-avatar large" aria-hidden="true">${escapeHtml(employee.name.slice(-1))}</span>
        <div>
          <h2 class="detail-title">${escapeHtml(employee.name)}</h2>
          <p class="detail-path">${escapeHtml([employee.jobTitle, employee.department].filter(Boolean).join(" · "))}</p>
        </div>
      </div>
      <dl class="employee-fields">
        ${fieldRow("Account", employee.account)}
        ${fieldRow("Email", employee.email)}
        ${fieldRow("Name", employee.name)}
        ${fieldRow("Gender", employee.gender)}
        ${fieldRow("Job title", employee.jobTitle)}
        <div class="department-field">
          <dt>Department</dt>
          <dd>
            <span>${escapeHtml(employee.department)}</span>
            ${employee.department ? `<a href="./index.html?department=${encodeURIComponent(employee.department)}">View in organization <span aria-hidden="true">→</span></a>` : ""}
          </dd>
        </div>
      </dl>
      <section class="responsibility-section">
        <div class="responsibility-heading">
          <h3>Work responsibilities</h3>
          ${employee.responsibilities.length ? `<span>${numberFormatter.format(employee.responsibilities.length)}</span>` : ""}
        </div>
        ${responsibilityGroups.length ? `
          <div class="responsibility-table-wrap">
            <table class="responsibility-table">
              <thead>
                <tr><th>Category</th><th>Role</th><th>Work scope</th></tr>
              </thead>
              <tbody>
                ${responsibilityGroups.map((group) => group.items.map((item, index) => `
                  <tr>
                    ${index === 0 ? `
                      <th class="responsibility-category category-${slugify(group.category)}" rowspan="${group.items.length}" scope="rowgroup">
                        <span class="category-label"><span class="category-mark" aria-hidden="true"></span>${escapeHtml(group.category)}</span>
                        <small>${numberFormatter.format(group.items.length)} ${group.items.length === 1 ? "item" : "items"}</small>
                      </th>
                    ` : ""}
                    <td class="responsibility-role">${item.role ? `<span class="role-pill">${escapeHtml(item.role)}</span>` : ""}</td>
                    <td><div class="work-path">${renderWorkPath(item.work)}</div></td>
                  </tr>
                `).join("")).join("")}
              </tbody>
            </table>
          </div>
        ` : ""}
      </section>
    `;
  }

  function groupResponsibilities(responsibilities) {
    const order = [
      "Demand overview",
      "Demand",
      "Operations",
      "Development",
      "Platform delivery",
      "Data & AI",
      "IT services",
      "Product compliance",
      "TV ownership",
    ];
    const groups = new Map();
    responsibilities.forEach((item) => {
      if (!groups.has(item.category)) groups.set(item.category, []);
      groups.get(item.category).push(item);
    });
    return [...groups.entries()]
      .map(([category, items]) => ({ category, items }))
      .sort((a, b) => order.indexOf(a.category) - order.indexOf(b.category));
  }

  function renderWorkPath(work) {
    return String(work ?? "").split(" / ").map((part, index) => `
      ${index ? '<span class="path-arrow" aria-hidden="true">›</span>' : ""}
      <span>${escapeHtml(part)}</span>
    `).join("");
  }

  function slugify(value) {
    return String(value ?? "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  }

  function fieldRow(label, value) {
    return `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`;
  }

  function bindEvents() {
    elements.search.addEventListener("input", () => {
      state.departmentFilter = null;
      state.query = elements.search.value;
      renderResults();
    });

    elements.results.addEventListener("click", (event) => {
      const button = event.target.closest("[data-account]");
      if (!button) return;
      const employee = employeeByAccount.get(button.dataset.account);
      if (!employee) return;
      state.selectedAccount = employee.account;
      renderResults();
      renderDetail(employee);
    });

    document.addEventListener("keydown", (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        elements.search.focus();
      }
    });
  }

  function applyDirectoryLink() {
    const params = new URLSearchParams(window.location.search);
    const departmentId = params.get("departmentId");
    const scope = params.get("scope") === "subtree" ? "subtree" : "direct";
    const organization = window.ORG_DATA;
    const organizationDepartments = new Map(
      Array.isArray(organization?.departments)
        ? organization.departments
          .filter((department) => !String(department.path || "").split("-").some((part) => part.trim() === "历史数据"))
          .map((department) => [department.id, department])
        : [],
    );
    const linkedDepartment = organizationDepartments.get(departmentId);
    if (linkedDepartment) {
      const ids = new Set([linkedDepartment.id]);
      if (scope === "subtree") {
        const childrenByParent = new Map();
        organizationDepartments.forEach((department) => {
          if (!childrenByParent.has(department.parentId)) childrenByParent.set(department.parentId, []);
          childrenByParent.get(department.parentId).push(department);
        });
        const pending = [...(childrenByParent.get(linkedDepartment.id) || [])];
        const visited = new Set([linkedDepartment.id]);
        while (pending.length) {
          const department = pending.pop();
          if (visited.has(department.id)) continue;
          visited.add(department.id);
          ids.add(department.id);
          pending.push(...(childrenByParent.get(department.id) || []));
        }
      }
      state.departmentFilter = {
        ids,
        description: scope === "subtree"
          ? `${linkedDepartment.name} and subdepartments`
          : linkedDepartment.name,
      };
      elements.search.value = scope === "subtree"
        ? `${linkedDepartment.name} · including subdepartments`
        : linkedDepartment.name;
      renderResults();
      return;
    }

    const query = params.get("department") || params.get("query");
    if (!query?.trim()) return;
    elements.search.value = query.trim();
    state.query = query.trim();
    renderResults();
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  initialize();
})();
