(() => {
  "use strict";

  const data = window.ORG_DATA;
  const numberFormatter = new Intl.NumberFormat("en-US");
  const state = {
    selectedId: null,
    expanded: new Set(),
    query: "",
  };

  const elements = {
    peopleTotal: document.querySelector("#people-total"),
    departmentTotal: document.querySelector("#department-total"),
    legalEntityTotal: document.querySelector("#legal-entity-total"),
    snapshotLabel: document.querySelector("#snapshot-label"),
    tree: document.querySelector("#organization-tree"),
    detail: document.querySelector("#department-detail"),
    search: document.querySelector("#department-search"),
    searchSummary: document.querySelector("#search-summary"),
    collapseAll: document.querySelector("#collapse-all"),
  };

  if (!data || !Array.isArray(data.departments)) {
    showFatalError("The local organization snapshot is missing. Run scripts/export_org_data.py and reload this page.");
    return;
  }

  const visibleDepartments = data.departments.filter((department) => !isHistoricalDepartment(department));
  const departments = new Map(visibleDepartments.map((department) => [department.id, {
    ...department,
    children: [],
    subtreePeople: null,
  }]));

  function isHistoricalDepartment(department) {
    return String(department.path || "").split("-").some((part) => part.trim() === "历史数据");
  }

  const roots = [];
  departments.forEach((department) => {
    const parent = departments.get(department.parentId);
    if (parent && parent.id !== department.id) {
      parent.children.push(department);
    } else {
      roots.push(department);
    }
  });

  departments.forEach((department) => {
    department.children.sort((a, b) => b.people.length - a.people.length || a.name.localeCompare(b.name, "zh-CN"));
  });
  roots.sort((a, b) => b.people.length - a.people.length || a.name.localeCompare(b.name, "zh-CN"));

  function uniquePeopleFor(department, visiting = new Set()) {
    if (department.subtreePeople) return department.subtreePeople;
    if (visiting.has(department.id)) return new Set(department.people);
    visiting.add(department.id);
    const people = new Set(department.people);
    department.children.forEach((child) => {
      uniquePeopleFor(child, visiting).forEach((person) => people.add(person));
    });
    visiting.delete(department.id);
    department.subtreePeople = people;
    return people;
  }

  function initialize() {
    elements.peopleTotal.textContent = numberFormatter.format(data.meta.uniquePeople);
    elements.departmentTotal.textContent = numberFormatter.format(data.meta.departmentCount);
    elements.legalEntityTotal.textContent = numberFormatter.format(data.meta.legalEntityCount);
    elements.snapshotLabel.textContent = `Data as of ${data.meta.snapshotDate}`;

    roots.slice(0, 12).forEach((root) => state.expanded.add(root.id));
    renderTree();
    bindEvents();
    applyDepartmentLink();
  }

  function legalEntitiesFor(department) {
    const counts = new Map();
    uniquePeopleFor(department).forEach((person) => {
      const entity = data.personLegalEntities?.[person] || "Unassigned";
      counts.set(entity, (counts.get(entity) || 0) + 1);
    });
    return [...counts.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "zh-CN"));
  }

  function renderTree() {
    const query = state.query.trim().toLocaleLowerCase("zh-CN");
    const matches = query
      ? [...departments.values()].filter((department) => `${department.name} ${department.path}`.toLocaleLowerCase("zh-CN").includes(query))
      : [];
    const visible = new Set();
    const matchIds = new Set(matches.map((department) => department.id));

    if (query) {
      matches.forEach((department) => {
        let current = department;
        const visited = new Set();
        while (current && !visited.has(current.id)) {
          visible.add(current.id);
          state.expanded.add(current.id);
          visited.add(current.id);
          current = departments.get(current.parentId);
        }
      });
      elements.searchSummary.textContent = `${numberFormatter.format(matches.length)} matching departments`;
    } else {
      elements.searchSummary.textContent = `${numberFormatter.format(roots.length)} top-level structures · select any node for details`;
    }

    const treeRoots = query ? roots.filter((root) => visible.has(root.id)) : roots;
    elements.tree.innerHTML = renderTreeList(treeRoots, visible, matchIds, query);
  }

  function renderTreeList(items, visible, matchIds, query) {
    if (!items.length) {
      return query ? '<div class="empty-state"><p>No department matches this search.</p></div>' : "";
    }

    return `<ul class="tree-list">${items.map((department) => {
      const children = query ? department.children.filter((child) => visible.has(child.id)) : department.children;
      const expanded = state.expanded.has(department.id);
      const hasChildren = children.length > 0;
      return `
        <li class="tree-item" role="treeitem" aria-expanded="${hasChildren ? expanded : false}">
          <div class="tree-row ${state.selectedId === department.id ? "selected" : ""} ${matchIds.has(department.id) ? "search-match" : ""}" data-id="${escapeHtml(department.id)}">
            <button class="tree-toggle ${hasChildren ? "" : "empty"}" type="button" data-toggle-id="${escapeHtml(department.id)}" aria-label="${expanded ? "Collapse" : "Expand"} ${escapeHtml(department.name)}">${hasChildren ? (expanded ? "▾" : "▸") : "·"}</button>
            <span class="tree-name" title="${escapeHtml(department.path)}">${escapeHtml(department.name)}</span>
            <span class="tree-count">${numberFormatter.format(uniquePeopleFor(department).size)}</span>
          </div>
          ${hasChildren ? `<div class="tree-children" ${expanded ? "" : "hidden"}>${renderTreeList(children, visible, matchIds, query)}</div>` : ""}
        </li>
      `;
    }).join("")}</ul>`;
  }

  function renderDetail(department) {
    const subtreePeople = uniquePeopleFor(department).size;
    const childPreview = department.children.slice(0, 10);
    const legalEntities = legalEntitiesFor(department).slice(0, 5);
    elements.detail.innerHTML = `
      <h2 class="detail-title">${escapeHtml(department.name)}</h2>
      <p class="detail-path">${escapeHtml(department.path)}</p>
      <div class="detail-metrics">
        <a class="detail-stat detail-stat-link" href="./employees.html?departmentId=${encodeURIComponent(department.id)}&scope=direct" aria-label="View direct people in ${escapeHtml(department.name)}">
          <span>Direct people</span><strong>${numberFormatter.format(department.people.length)}</strong><small>View employees →</small>
        </a>
        <a class="detail-stat detail-stat-link" href="./employees.html?departmentId=${encodeURIComponent(department.id)}&scope=subtree" aria-label="View people in ${escapeHtml(department.name)} and its subdepartments">
          <span>Subtree people</span><strong>${numberFormatter.format(subtreePeople)}</strong><small>View employees →</small>
        </a>
      </div>
      <div class="entity-section">
        <h3>Legal entities in subtree</h3>
        <div class="entity-list">
          ${legalEntities.length ? legalEntities.map((entity) => `
            <span class="entity-chip" title="${escapeHtml(entity.name)}">
              <span>${escapeHtml(entity.name)}</span>
              <strong>${numberFormatter.format(entity.count)}</strong>
            </span>
          `).join("") : '<span class="detail-path">No legal entity data.</span>'}
        </div>
      </div>
      <div class="child-section">
        <h3>Direct subdepartments</h3>
        <div class="child-list">
          ${childPreview.length ? childPreview.map((child) => `
            <button class="child-chip" type="button" data-child-id="${escapeHtml(child.id)}">
              <span>${escapeHtml(child.name)}</span>
              <span>${numberFormatter.format(uniquePeopleFor(child).size)} people</span>
            </button>
          `).join("") : '<p class="detail-path">No direct subdepartments.</p>'}
        </div>
      </div>
    `;
  }

  function selectDepartment(id) {
    const department = departments.get(id);
    if (!department) return;
    state.selectedId = id;
    renderDetail(department);
    renderTree();
    document.querySelector(`[data-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: "nearest" });
  }

  function bindEvents() {
    elements.tree.addEventListener("click", (event) => {
      const toggle = event.target.closest("[data-toggle-id]");
      if (toggle && !toggle.classList.contains("empty")) {
        event.stopPropagation();
        const id = toggle.dataset.toggleId;
        state.expanded.has(id) ? state.expanded.delete(id) : state.expanded.add(id);
        renderTree();
        return;
      }
      const row = event.target.closest("[data-id]");
      if (row) {
        const department = departments.get(row.dataset.id);
        if (department?.children.length) state.expanded.add(department.id);
        selectDepartment(row.dataset.id);
      }
    });

    elements.detail.addEventListener("click", (event) => {
      const child = event.target.closest("[data-child-id]");
      if (!child) return;
      state.expanded.add(state.selectedId);
      selectDepartment(child.dataset.childId);
    });

    elements.search.addEventListener("input", () => {
      state.query = elements.search.value;
      renderTree();
    });

    elements.collapseAll.addEventListener("click", () => {
      state.expanded.clear();
      renderTree();
    });

    document.addEventListener("keydown", (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        elements.search.focus();
      }
    });
  }

  function applyDepartmentLink() {
    const departmentName = new URLSearchParams(window.location.search).get("department")?.trim();
    if (!departmentName) return;
    elements.search.value = departmentName;
    state.query = departmentName;
    renderTree();
    const exactMatches = [...departments.values()].filter((department) => department.name === departmentName);
    if (exactMatches.length === 1) selectDepartment(exactMatches[0].id);
  }

  function showFatalError(message) {
    elements.tree.innerHTML = `<div class="error-banner">${escapeHtml(message)}</div>`;
    elements.snapshotLabel.textContent = "Snapshot unavailable";
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  initialize();
})();
