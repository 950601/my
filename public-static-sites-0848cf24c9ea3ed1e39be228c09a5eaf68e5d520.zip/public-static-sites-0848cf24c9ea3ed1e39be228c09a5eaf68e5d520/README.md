# Public Static Sites

This repository packages multiple pre-built frontend projects into one Nginx image.

## Project layout

Each site lives in an isolated directory:

```text
projects/{project-name}/
├── index.html
└── assets/
```

After deployment, a project is available at:

```text
https://{content-domain}/sites/{project-name}/
```

## Add or update a site

1. Build the frontend locally.
2. Ensure all assets use relative URLs.
3. Copy the complete build output to `projects/{project-name}/`.
4. Run validation:

   ```bash
   python3 scripts/validate_sites.py projects
   ```

5. Commit and push the full project replacement.

Vite projects should use `base: "./"`. SPAs should use hash-based routing in the initial platform version.

## Run locally

```bash
docker build -t public-static-sites .
docker run --rm -p 8080:8080 public-static-sites
```

Open `http://localhost:8080/sites/demo/`.

## Deployment model

GitLab validates every change and publishes an immutable image tagged with the commit SHA for the default branch. Configure the shared CCloud application to deploy that image through a protected deployment integration or an authorized CCloud build template. The public content domain must not share cookies or origin credentials with the management application.

The repository intentionally does not contain CCloud credentials. Automatic CCloud rollout requires protected CI variables or a platform-side repository integration.
