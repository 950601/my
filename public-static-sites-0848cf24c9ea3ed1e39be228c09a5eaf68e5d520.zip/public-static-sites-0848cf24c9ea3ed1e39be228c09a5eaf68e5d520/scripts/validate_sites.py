#!/usr/bin/env python3

import re
import sys
from pathlib import Path

MAX_PROJECT_BYTES = 50 * 1024 * 1024
MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_FILES = 1_000
MAX_DEPTH = 10
MAX_PATH_BYTES = 240
MAX_NAME_BYTES = 100

PROJECT_PATTERN = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,46}[a-z0-9])$")
PATH_PATTERN = re.compile(r"^[A-Za-z0-9._/-]+$")
RESERVED_PROJECTS = {"admin", "api", "assets", "health", "login", "static", "system"}
ALLOWED_SUFFIXES = {
    ".avif", ".css", ".gif", ".htm", ".html", ".ico", ".jpeg", ".jpg",
    ".js", ".json", ".map", ".mjs", ".mp3", ".mp4", ".ogg",
    ".otf", ".png", ".svg", ".ttf", ".txt", ".wasm", ".webm", ".webmanifest",
    ".webp", ".woff", ".woff2", ".xml",
}


def validate_project(project: Path) -> list[str]:
    errors = []
    if not PROJECT_PATTERN.fullmatch(project.name) or project.name in RESERVED_PROJECTS:
        errors.append(f"{project}: invalid project name")
    if not (project / "index.html").is_file():
        errors.append(f"{project}: root index.html is required")

    seen_casefolded_paths = set()
    file_count = 0
    total_bytes = 0

    for path in project.rglob("*"):
        relative = path.relative_to(project)
        relative_text = relative.as_posix()

        if path.is_symlink():
            errors.append(f"{path}: symbolic links are not allowed")
            continue
        if any(part.startswith(".") for part in relative.parts):
            errors.append(f"{path}: hidden paths are not allowed")
        if not PATH_PATTERN.fullmatch(relative_text):
            errors.append(f"{path}: path contains unsupported characters")
        if len(relative.parts) > MAX_DEPTH:
            errors.append(f"{path}: directory depth exceeds {MAX_DEPTH}")
        if len(relative_text.encode("utf-8")) > MAX_PATH_BYTES:
            errors.append(f"{path}: relative path exceeds {MAX_PATH_BYTES} bytes")
        if any(len(part.encode("utf-8")) > MAX_NAME_BYTES for part in relative.parts):
            errors.append(f"{path}: file or directory name exceeds {MAX_NAME_BYTES} bytes")

        casefolded_path = relative_text.casefold()
        if casefolded_path in seen_casefolded_paths:
            errors.append(f"{path}: path conflicts by letter case")
        seen_casefolded_paths.add(casefolded_path)

        if path.is_file():
            file_count += 1
            size = path.stat().st_size
            total_bytes += size
            if path.suffix.lower() not in ALLOWED_SUFFIXES:
                errors.append(f"{path}: file type is not allowed")
            if size > MAX_FILE_BYTES:
                errors.append(f"{path}: file exceeds {MAX_FILE_BYTES} bytes")

    if file_count > MAX_FILES:
        errors.append(f"{project}: file count exceeds {MAX_FILES}")
    if total_bytes > MAX_PROJECT_BYTES:
        errors.append(f"{project}: project size exceeds {MAX_PROJECT_BYTES} bytes")
    return errors


def main() -> int:
    projects_root = Path(sys.argv[1] if len(sys.argv) > 1 else "projects")
    if not projects_root.is_dir():
        print(f"Projects directory not found: {projects_root}", file=sys.stderr)
        return 1

    root_entries = sorted(projects_root.iterdir())
    invalid_entries = [path for path in root_entries if path.is_symlink() or not path.is_dir()]
    if invalid_entries:
        print("Only project directories are allowed under the projects root:", file=sys.stderr)
        for path in invalid_entries:
            print(f"- {path}", file=sys.stderr)
        return 1

    projects = root_entries
    if not projects:
        print("At least one project is required", file=sys.stderr)
        return 1

    errors = [error for project in projects for error in validate_project(project)]
    if errors:
        print("Static site validation failed:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1

    print(f"Validated {len(projects)} static site project(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
